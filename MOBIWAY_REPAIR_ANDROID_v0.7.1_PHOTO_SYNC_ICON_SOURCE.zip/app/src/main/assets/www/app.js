
/* ===== v0.4 animated startup ===== */
(function(){
  const splash=document.getElementById('introSplash');
  if(!splash)return;
  const finish=()=>{
    splash.classList.add('out');
    setTimeout(()=>splash.remove(),300);
    setTimeout(()=>document.getElementById('unlockPassword')?.focus(),340);
  };
  setTimeout(finish,4700);
  splash.addEventListener('click',()=>{ /* intentionally not skippable: consistent branded launch */ });
})();

/* MOBIWAY REPAIR v0.3 */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

/* ===== Launch authentication ===== */
const SECURITY = { hash: '7d82573f', failed: 0, lockedUntil: 0 };
function gateHash(str){
  let h=0x811c9dc5;
  for(let i=0;i<str.length;i++){ h^=str.charCodeAt(i); h=Math.imul(h,0x01000193); }
  return (h>>>0).toString(16).padStart(8,'0');
}
function lockApplication(){
  document.body.classList.add('locked');
  $('#securityGate')?.classList.remove('unlocked');
  if($('#unlockPassword')){ $('#unlockPassword').value=''; setTimeout(()=>$('#unlockPassword')?.focus(),180); }
}
function unlockApplication(){
  document.body.classList.remove('locked');
  $('#securityGate')?.classList.add('unlocked');
  SECURITY.failed=0;
}
document.body.classList.add('locked');
$('#unlockForm')?.addEventListener('submit',e=>{
  e.preventDefault();
  const err=$('#unlockError'), now=Date.now();
  if(now<SECURITY.lockedUntil){
    err.textContent=`Acesso temporariamente bloqueado. Aguarde ${Math.ceil((SECURITY.lockedUntil-now)/1000)}s.`;
    return;
  }
  if(gateHash($('#unlockPassword').value)===SECURITY.hash){ err.textContent=''; unlockApplication(); return; }
  SECURITY.failed++; $('#unlockPassword').value='';
  if(SECURITY.failed>=5){ SECURITY.lockedUntil=Date.now()+30000; SECURITY.failed=0; err.textContent='5 tentativas incorretas. Acesso bloqueado durante 30 segundos.'; }
  else err.textContent=`Palavra-passe incorreta. Tentativa ${SECURITY.failed} de 5.`;
});
window.addEventListener('pageshow',()=>lockApplication());

/* ===== Data / settings ===== */
const DEFAULT_SETTINGS = {
  shopName:'MOBIWAY', legalName:'', laborRate:45, diagnosticFee:35,
  partsMarginPct:20, consumablesPct:4, vatPct:23, warrantyMonths:18,
  researchEndpoint:'https://mobiway-avalia-api.vercel.app/api/repair',
  terms:'Orçamento sujeito a confirmação após diagnóstico/desmontagem. Qualquer trabalho adicional carece de autorização do cliente.'
};
const state = { step:1, photos:[], lines:[], editing:null, aiResearch:null, currentOrderId:null };
const STEP_TITLES = ['Cliente','Viatura','Fotografias','Pedido e diagnóstico','Orçamento','Autorização','Abrir ordem'];
const STATUS_FLOW = ['Rececionado','Em diagnóstico','A aguardar orçamento','Aguardar autorização','Autorizado','Em reparação','Aguardar peças','Teste final','Pronto','Entregue'];

function loadSettings(){ try{return {...DEFAULT_SETTINGS,...JSON.parse(localStorage.getItem('mobiwayRepairSettings')||'{}')}}catch{return {...DEFAULT_SETTINGS}} }
function saveSettingsData(s){ localStorage.setItem('mobiwayRepairSettings',JSON.stringify(s)); }
function orders(){ try{return JSON.parse(localStorage.getItem('mobiwayRepairOrders')||'[]')}catch{return []} }
function saveOrders(a){ localStorage.setItem('mobiwayRepairOrders',JSON.stringify(a)); }
function money(v){ return new Intl.NumberFormat('pt-PT',{style:'currency',currency:'EUR'}).format(Number(v||0)); }
function now(){ return new Date().toLocaleString('pt-PT'); }
function num(v,f=0){ const n=Number(String(v??'').replace(',','.')); return Number.isFinite(n)?n:f; }
function esc(s){ return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function fd(){ return Object.fromEntries(new FormData($('#repairForm')).entries()); }
function show(id){ $$('.view').forEach(v=>v.classList.remove('active')); $('#'+id)?.classList.add('active'); window.scrollTo(0,0); }
function toast(msg){ const x=document.createElement('div'); x.className='toast'; x.textContent=msg; document.body.appendChild(x); setTimeout(()=>x.remove(),2400); }

/* ===== Home ===== */
function updateHome(filter=''){
  const arr=orders(), q=String(filter||'').toLowerCase();
  $('#statOpen').textContent=arr.filter(o=>!['Entregue'].includes(o.status)).length;
  $('#statWaiting').textContent=arr.filter(o=>/aguardar|autoriza/i.test(o.status||'')).length;
  $('#statDone').textContent=arr.filter(o=>['Pronto','Entregue'].includes(o.status)).length;
  const list=arr.filter(o=>!q||[o.orderNo,o.customerName,o.plate,o.make,o.model,o.customerRequest].join(' ').toLowerCase().includes(q));
  $('#ordersList').innerHTML=list.length?list.slice(0,50).map(o=>{
    const supplementPending=(o.supplements||[]).filter(s=>s.status==='A aguardar autorização').length;
    return `<div class="order" onclick="openOrder('${o.id}')">
      <div class="orderTop"><div><h3>${esc(o.plate||'Sem matrícula')} · ${esc(o.make||'')} ${esc(o.model||'')}</h3>
      <p>${esc(o.customerName||'Cliente')} · ${esc(o.customerRequest||'Sem descrição')}</p></div>
      <span class="status">${esc(o.status||'Rececionado')}</span></div>
      <div class="orderFoot"><span>${esc(o.orderNo)}${supplementPending?` · ${supplementPending} adit. pendente`:''}</span><b>${money(orderTotal(o))}</b></div>
    </div>`;
  }).join(''):'<div class="order"><p>Ainda não existem ordens de reparação.</p></div>';
}
$('#newReceptionBtn').onclick=()=>{ resetForm(); show('reception'); };
$('#searchInput').oninput=e=>updateHome(e.target.value);
$('#showAllBtn').onclick=()=>{ $('#searchInput').value=''; updateHome(''); };
$$('[data-back]').forEach(b=>b.onclick=()=>{ show(b.dataset.back); updateHome(); });

/* ===== Wizard ===== */
function resetForm(){
  $('#repairForm').reset(); state.step=1; state.photos=[]; state.lines=[]; state.editing=null; state.aiResearch=null;
  $('#photoGrid').innerHTML=''; $('#aiBox').classList.add('hidden'); $('#aiResult').innerHTML='';
  const s=loadSettings(); addEstimateLine('Diagnóstico inicial',1,s.diagnosticFee);
  goStep(1);
}
function goStep(n){
  state.step=Math.max(1,Math.min(7,n));
  $$('.step').forEach(s=>s.classList.toggle('active',Number(s.dataset.step)===state.step));
  $('#stepTitle').textContent=STEP_TITLES[state.step-1]; $('#stepCounter').textContent=`${state.step}/7`;
  $('#progressBar').style.width=`${state.step/7*100}%`; $('#prevBtn').style.visibility=state.step===1?'hidden':'visible';
  $('#nextBtn').textContent=state.step===7?'Criar ordem':'Continuar'; if(state.step===7) buildReview(); updateReceptionContext(); window.scrollTo(0,0);
}
function updateReceptionContext(){
  const el=$('#receptionContext'); if(!el)return;
  const f=fd(); const name=[f.make,f.model].filter(Boolean).join(' ')||'Nova receção';
  const meta=[f.plate||'',f.year||'',f.mileage?`${f.mileage} km`:'' ].filter(Boolean).join(' · ')||'Identificação da viatura em curso';
  el.innerHTML=`<div><small>ORDEM EM PREPARAÇÃO</small><strong>${esc(name)}</strong><span>${esc(meta)}</span></div><span class="linkedChip neutral">REPAIR</span>`;
}
$('#prevBtn').onclick=()=>goStep(state.step-1);
$('#nextBtn').onclick=()=>{ if(state.step<7) goStep(state.step+1); else createOrder(); };

/* ===== Photos ===== */
async function ingestPhotos(files){
  for(const f of [...files].slice(0,20-state.photos.length)) state.photos.push(await compressImage(f));
  renderPhotos();
}
$('#photosInput').onchange=async e=>{ await ingestPhotos(e.target.files); e.target.value=''; };
$('#cameraInput').onchange=async e=>{ await ingestPhotos(e.target.files); e.target.value=''; };
function compressImage(file){
  return new Promise(resolve=>{
    const reader=new FileReader(); reader.onload=()=>{
      const img=new Image(); img.onload=()=>{
        const max=1280, scale=Math.min(1,max/Math.max(img.width,img.height));
        const c=document.createElement('canvas'); c.width=Math.round(img.width*scale); c.height=Math.round(img.height*scale);
        c.getContext('2d').drawImage(img,0,0,c.width,c.height); resolve(c.toDataURL('image/jpeg',.78));
      }; img.src=reader.result;
    }; reader.readAsDataURL(file);
  });
}
function renderPhotos(){ $('#photoGrid').innerHTML=state.photos.map((p,i)=>`<div class="photoTile"><img src="${p}"><button type="button" onclick="removePhoto(${i})">×</button></div>`).join(''); }
window.removePhoto=i=>{state.photos.splice(i,1);renderPhotos();};

/* ===== Estimate ===== */
function addEstimateLine(desc='',qty=1,price=0,meta={}){ state.lines.push({desc,qty:num(qty,1),price:num(price),meta}); renderLines(); }
function renderLines(){
  $('#estimateLines').innerHTML=state.lines.map((l,i)=>`<div class="lineRow">
    <input value="${esc(l.desc)}" placeholder="Descrição" oninput="updateLine(${i},'desc',this.value)">
    <input value="${l.qty}" inputmode="decimal" oninput="updateLine(${i},'qty',this.value)">
    <input value="${Number(l.price).toFixed(2)}" inputmode="decimal" oninput="updateLine(${i},'price',this.value)">
    <button class="deleteLine" type="button" onclick="delLine(${i})">×</button>
  </div>`).join(''); calcTotal();
}
window.updateLine=(i,k,v)=>{ state.lines[i][k]=k==='desc'?v:num(v); calcTotal(); };
window.delLine=i=>{ state.lines.splice(i,1); renderLines(); };
$('#addLineBtn').onclick=()=>addEstimateLine('',1,0);
function calcTotal(){
  const s=loadSettings(), sub=state.lines.reduce((sum,l)=>sum+num(l.qty)*num(l.price),0), vat=sub*(num(s.vatPct)/100), total=sub+vat;
  $('#subtotal').textContent=money(sub); $('#vatTotal').textContent=money(vat); $('#grandTotal').textContent=money(total); return {sub,vat,total};
}

/* ===== AI + web technical research ===== */
async function fetchWithTimeout(url,options={},ms=50000){
  const ctl=new AbortController(), t=setTimeout(()=>ctl.abort(),ms);
  try{return await fetch(url,{...options,signal:ctl.signal})}finally{clearTimeout(t)}
}
$('#aiResearchBtn').onclick=async()=>{
  const d=fd(), s=loadSettings(), btn=$('#aiResearchBtn');
  if(!d.make||!d.model||!d.customerRequest){ toast('Preenche marca, modelo e pedido do cliente.'); return; }
  btn.disabled=true; btn.textContent='✦ A pesquisar fontes técnicas…'; $('#aiBox').classList.remove('hidden');
  $('#aiResult').innerHTML='<div class="researchLoading">Pesquisa técnica em curso. Pode demorar alguns segundos…</div>';
  try{
    const r=await fetchWithTimeout(s.researchEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      make:d.make,model:d.model,year:d.year,engine:d.engine,fuel:d.fuel,transmission:d.transmission,mileage:d.mileage,
      request:d.customerRequest,workshopNotes:d.workshopNotes
    })},55000);
    const raw=await r.text(); let data; try{data=JSON.parse(raw)}catch{data=null}
    if(!r.ok||!data) throw new Error(data?.error||raw.slice(0,300)||`HTTP ${r.status}`);
    state.aiResearch=data; renderAIResearch(data);
  }catch(e){
    state.aiResearch=null;
    $('#aiResult').innerHTML=`<div class="researchError"><b>Pesquisa indisponível</b><p>${esc(e?.name==='AbortError'?'A pesquisa excedeu o tempo limite.':e?.message||'Erro desconhecido')}</p><p class="muted">O orçamento pode continuar manualmente.</p></div>`;
  }finally{ btn.disabled=false; btn.textContent='✦ Atualizar pesquisa técnica e mercado'; }
};
function renderAIResearch(a){
  const lh=a.laborHours||{}, mp=a.marketWorkshopPriceGross||{};
  const parts=(a.parts||[]).map(p=>`<li>${esc(p.description)} · ${p.qty||1}× · ref. ${money(p.recommendedGross||0)} c/IVA</li>`).join('');
  const sources=(a.sources||[]).slice(0,6).map(x=>`<li><span>${esc(x.title)}</span><small>${esc(x.url)}</small></li>`).join('');
  const risks=(a.risks||[]).map(x=>`<li>${esc(x)}</li>`).join('');
  const confirms=(a.confirmations||[]).map(x=>`<li>${esc(x)}</li>`).join('');
  $('#aiResult').innerHTML=`
    <div class="researchHeader"><div><b>${esc(a.repairTitle||'Pesquisa técnica')}</b><p>${esc(a.vehicleSummary||'')}</p></div><span class="confidence">${num(a.confidence)}%</span></div>
    <p>${esc(a.summary||'')}</p>
    ${a.technicalAssessment?`<div class="researchBlock"><b>Avaliação técnica</b><p>${esc(a.technicalAssessment)}</p></div>`:''}
    <div class="researchNumbers">
      <div><span>Mão de obra</span><b>${num(lh.low)}–${num(lh.high)} h</b><small>Sugestão ${num(lh.recommended)} h</small></div>
      <div><span>Mercado oficina</span><b>${mp.low?money(mp.low):'—'}</b><small>${mp.high?`até ${money(mp.high)} c/IVA`:'referência insuficiente'}</small></div>
    </div>
    ${parts?`<div class="researchBlock"><b>Peças prováveis</b><ul>${parts}</ul></div>`:''}
    ${confirms?`<div class="researchBlock warning"><b>Confirmar antes de orçamentar</b><ul>${confirms}</ul></div>`:''}
    ${risks?`<div class="researchBlock"><b>Riscos / trabalhos associados</b><ul>${risks}</ul></div>`:''}
    <button type="button" class="primary full" onclick="applyResearchToEstimate()">Usar sugestão no orçamento</button>
    ${sources?`<details class="sources"><summary>Fontes consultadas</summary><ul>${sources}</ul></details>`:''}
    <p class="aiDisclaimer">Referência assistida por IA e pesquisa web. Confirmar diagnóstico, referências de peças e tempos antes da aprovação final.</p>`;
}
window.applyResearchToEstimate=()=>{
  const a=state.aiResearch; if(!a) return;
  const s=loadSettings(), vat=1+num(s.vatPct)/100, margin=1+num(s.partsMarginPct)/100;
  state.lines=[];
  if(num(s.diagnosticFee)>0) state.lines.push({desc:'Diagnóstico / verificação inicial',qty:1,price:num(s.diagnosticFee),meta:{type:'diagnostic'}});
  for(const p of (a.parts||[])){
    const gross=num(p.recommendedGross), netReference=gross>0?gross/vat:0, sellNet=netReference*margin;
    state.lines.push({desc:p.description,qty:num(p.qty,1),price:Math.round(sellNet*100)/100,meta:{type:'part',referenceGross:gross}});
  }
  const hours=num(a?.laborHours?.recommended);
  if(hours>0) state.lines.push({desc:`Mão de obra — ${a.repairTitle||'reparação'}`,qty:hours,price:num(s.laborRate),meta:{type:'labor'}});
  const aiConsumablesNet=num(a.consumablesGross)/vat;
  const calculatedConsumables=hours*num(s.laborRate)*(num(s.consumablesPct)/100);
  const consumables=Math.max(aiConsumablesNet,calculatedConsumables);
  if(consumables>0) state.lines.push({desc:'Consumíveis / materiais auxiliares',qty:1,price:Math.round(consumables*100)/100,meta:{type:'consumables'}});
  renderLines(); goStep(5); toast('Sugestão transferida para o orçamento. Confirma os valores.');
};

/* ===== Review / create order ===== */
function buildReview(){
  const d=fd(),t=calcTotal();
  $('#finalReview').innerHTML=`<b>${esc(d.plate||'Sem matrícula')} · ${esc(d.make||'')} ${esc(d.model||'')}</b><br>
  Cliente: ${esc(d.customerName||'—')}<br>Pedido: ${esc(d.customerRequest||'—')}<br>Fotos: ${state.photos.length}<br>
  Orçamento: <b>${money(t.total)}</b><br>Estado: ${esc(d.status||'Rececionado')}`;
}
function createOrder(){
  const d=fd(),t=calcTotal(),arr=orders(),s=loadSettings(),seq=String(Date.now()).slice(-6),id='OR'+Date.now();
  const sig=$('#signature').toDataURL('image/png');
  const order={ id,orderNo:`MR-${new Date().getFullYear()}-${seq}`,createdAt:now(),updatedAt:now(),...d,
    authorizationAccepted:!!d.authorizationAccepted, photos:[...state.photos], lines:JSON.parse(JSON.stringify(state.lines)), subtotal:t.sub,vat:t.vat,total:t.total,
    signature:sig, aiResearch:state.aiResearch, supplements:[], statusHistory:[{status:d.status||'Rececionado',at:now()}], finalNotes:'', kmOut:'', settingsSnapshot:s };
  arr.unshift(order); saveOrders(arr); updateHome(); show('home'); toast(`Ordem ${order.orderNo} criada.`);
}


/* ===== MOBIWAY Avalia integration ===== */
function avaliaPayload(o){
  if(!o) return {};
  return {
    source:'MOBIWAY REPAIR',
    sourcePackage:'pt.mobiway.repair',
    repairOrderId:o.id||'',
    orderNo:o.orderNo||'',
    plate:o.plate||'',
    vin:o.vin||'',
    make:o.make||'',
    model:o.model||'',
    year:o.year||'',
    engine:o.engine||'',
    fuel:o.fuel||'',
    transmission:o.transmission||'',
    mileage:o.mileage||'',
    repairEstimateGross:orderTotal(o),
    workshopNotes:o.workshopNotes||'',
    customerRequest:o.customerRequest||'',
    photos:Array.isArray(o.photos)?o.photos:[],
    photoCount:Array.isArray(o.photos)?o.photos.length:0
  };
}
function openMobiwayAvalia(order){
  const payload=JSON.stringify(avaliaPayload(order));
  if(window.AndroidBridge && typeof window.AndroidBridge.openAvalia==='function'){
    try{
      const ok=window.AndroidBridge.openAvalia(payload);
      if(!ok) toast('MOBIWAY Avalia não está instalada neste equipamento.');
      return;
    }catch(e){ toast('Não foi possível abrir a MOBIWAY Avalia.'); return; }
  }
  toast('Integração MOBIWAY Avalia disponível na app Android.');
}
window.openMobiwayAvaliaForOrder=id=>{
  const o=orders().find(x=>x.id===id);
  if(o) openMobiwayAvalia(o);
};
document.getElementById('openAvaliaHomeBtn')?.addEventListener('click',()=>openMobiwayAvalia(null));
document.getElementById('openAvaliaTopBtn')?.addEventListener('click',()=>openMobiwayAvalia(null));
document.getElementById('repairForm')?.addEventListener('input',updateReceptionContext);

/* ===== AVALIA -> REPAIR result import ===== */
function importAvaliaResult(){
  try{
    if(!window.AndroidBridge || typeof AndroidBridge.getAvaliaResultPayload!=='function') return null;
    const raw=AndroidBridge.getAvaliaResultPayload();
    if(!raw) return null;
    const p=JSON.parse(raw);
    if(!p) return null;
    const arr=orders();
    let i=-1;
    if(p.repairOrderId) i=arr.findIndex(o=>o.id===p.repairOrderId);
    if(i<0 && p.orderNo) i=arr.findIndex(o=>o.orderNo===p.orderNo);
    if(i<0 && p.vin) i=arr.findIndex(o=>String(o.vin||'').toUpperCase()===String(p.vin).toUpperCase());
    if(i<0 && p.plate) i=arr.findIndex(o=>String(o.plate||'').replace(/\s/g,'').toUpperCase()===String(p.plate).replace(/\s/g,'').toUpperCase());
    try{ if(typeof AndroidBridge.clearAvaliaResultPayload==='function') AndroidBridge.clearAvaliaResultPayload(); }catch{}
    if(i<0){ setTimeout(()=>toast('Avaliação recebida, mas não foi encontrada a ordem REPAIR correspondente.'),150); return null; }

    const received={...p,receivedAt:now()};
    const o=arr[i];
    if(Array.isArray(received.photos) && received.photos.length){
      o.photos=Array.isArray(o.photos)?o.photos:[];
      const seen=new Set(o.photos.map(x=>typeof x==='string'?x:(x?.data||'')));
      for(const ph of received.photos){
        const data=typeof ph==='string'?ph:(ph?.data||'');
        if(data && !seen.has(data)){ o.photos.push(data); seen.add(data); }
      }
    }
    o.avaliaResults=Array.isArray(o.avaliaResults)?o.avaliaResults:[];
    const existing=o.avaliaResults.findIndex(x=>x.evaluationId && x.evaluationId===received.evaluationId);
    if(existing>=0) o.avaliaResults[existing]=received; else o.avaliaResults.unshift(received);
    o.avaliaResult=received;
    o.updatedAt=now();
    o.statusHistory=o.statusHistory||[];
    o.statusHistory.push({status:`Avaliação MOBIWAY recebida · compra ${money(received.recommendedBuy)}`,at:now()});
    saveOrders(arr);
    setTimeout(()=>toast('Avaliação recebida e associada à ordem.'),180);
    return o.id;
  }catch(e){ return null; }
}

/* ===== Order detail / lifecycle ===== */
function orderTotal(o){
  const accepted=(o.supplements||[]).filter(x=>x.status==='Autorizado').reduce((s,x)=>s+num(x.amountGross),0);
  return num(o.total)+accepted;
}
window.openOrder=id=>{
  const o=orders().find(x=>x.id===id); if(!o)return; state.currentOrderId=id;
  $('#detailTitle').textContent=`${o.orderNo} · ${o.plate||''}`;
  renderOrderDetail(o); show('detail');
};
function renderOrderDetail(o){
  const photos=(o.photos||[]).map(p=>`<img src="${p}" class="reportPhoto">`).join('');
  const lines=(o.lines||[]).map(l=>`<tr><td>${esc(l.desc)}</td><td>${l.qty}</td><td>${money(l.price)}</td><td>${money(num(l.qty)*num(l.price))}</td></tr>`).join('');
  const supp=(o.supplements||[]).map(s=>`<div class="supplement"><div><b>${esc(s.description)}</b><p>${esc(s.reason||'')}</p><small>${esc(s.createdAt)} · ${esc(s.status)}</small></div><b>${money(s.amountGross)}</b>
    ${s.status==='A aguardar autorização'?`<div class="suppActions noPrint"><button onclick="setSupplementStatus('${o.id}','${s.id}','Autorizado')">Autorizar</button><button onclick="setSupplementStatus('${o.id}','${s.id}','Recusado')">Recusar</button></div>`:''}</div>`).join('');
  const hist=(o.statusHistory||[]).map(h=>`<div class="historyRow"><span>${esc(h.status)}</span><small>${esc(h.at)}</small></div>`).join('');
  const ai=o.aiResearch;
  const aiInternal=ai?`<div class="detailCard internalOnly noPrint"><h3>Pesquisa técnica interna</h3><p><b>${esc(ai.repairTitle||'')}</b> · confiança ${num(ai.confidence)}%</p><p>${esc(ai.technicalAssessment||ai.summary||'')}</p>${(ai.confirmations||[]).length?`<ul>${ai.confirmations.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}</div>`:'';
  const finalGross=orderTotal(o);
  const av=o.avaliaResult||null;
  const avHistory=Array.isArray(o.avaliaResults)?o.avaliaResults:[];
  const avaliaReceived=av?`<div class="detailCard integrationCard internalOnly noPrint">
    <div class="integrationTitle"><span class="avaliaBadge">✓</span><div><h3 style="margin:0">MOBIWAY Avalia · resultado recebido</h3><p class="muted" style="margin:3px 0 0">${esc(av.evaluatedAt||av.receivedAt||'')} · ${avHistory.length} avaliação(ões) associada(s)</p></div></div>
    <div class="kv" style="margin-top:14px">
      <span>Venda provável</span><b>${money(av.expectedSale)}</b><span>Compra aconselhada</span><b>${money(av.recommendedBuy)}</b>
      <span>Oferta inicial</span><b>${money(av.openingOffer)}</b><span>Máximo absoluto</span><b>${money(av.maximumBuy)}</b>
      <span>Margem alvo</span><b>${money(av.targetProfit)}</b><span>Custos observados</span><b>${money(av.observedRepairs)}</b>
      <span>Risco</span><b>${esc(av.riskLabel||'—')} · ${num(av.riskScore)}/100</b><span>Confiança</span><b>${num(av.confidence)}% · ${esc(av.confidenceLabel||'')}</b>
    </div>
    <button class="secondary integrationBtn" type="button" onclick="openMobiwayAvaliaForOrder('${o.id}')">Reabrir / atualizar avaliação</button>
  </div>`:'';
  $('#detailBody').innerHTML=`
    <div class="detailCard reportHero"><div><span class="reportLabel">ORDEM DE REPARAÇÃO</span><h3>${esc(o.orderNo)}</h3><p>${esc(o.createdAt)}</p></div><span class="status">${esc(o.status||'Rececionado')}</span></div>
    <div class="detailCard"><h3>Cliente e viatura</h3><div class="kv">
      <span>Cliente</span><b>${esc(o.customerName||'—')}</b><span>Telefone</span><b>${esc(o.phone||'—')}</b>
      <span>Matrícula</span><b>${esc(o.plate||'—')}</b><span>VIN</span><b>${esc(o.vin||'—')}</b>
      <span>Viatura</span><b>${esc([o.make,o.model,o.engine,o.year].filter(Boolean).join(' ')||'—')}</b><span>Km entrada</span><b>${esc(o.mileage||'—')}</b>
    </div></div>
    <div class="detailCard"><h3>Pedido e diagnóstico</h3><p><b>Pedido do cliente:</b> ${esc(o.customerRequest||'—')}</p><p>${esc(o.workshopNotes||'')}</p>${o.entryDamage?`<p><b>Estado à entrada:</b> ${esc(o.entryDamage)}</p>`:''}</div>
    ${photos?`<div class="detailCard"><h3>Registo fotográfico de entrada</h3><div class="reportPhotos">${photos}</div></div>`:''}
    <div class="detailCard"><h3>Orçamento autorizado</h3><table class="reportTable"><tr><th align="left">Descrição</th><th>Qtd.</th><th>Unit.</th><th>Total</th></tr>${lines}</table>
      <div class="reportTotals"><span>Base</span><b>${money(o.subtotal)}</b><span>IVA</span><b>${money(o.vat)}</b><span>Total inicial</span><b>${money(o.total)}</b></div></div>
    ${supp?`<div class="detailCard"><h3>Aditamentos</h3>${supp}<div class="reportGrand"><span>Total atual autorizado</span><b>${money(finalGross)}</b></div></div>`:''}
    <div class="detailCard"><h3>Autorização do cliente</h3><p>Valor máximo registado: <b>${esc(o.authorizedMax||'—')}</b></p><p>${o.authorizationAccepted?'✓ Autorização assinalada pelo cliente':'⚠ Autorização não assinalada'}</p>
      ${o.signature?`<img src="${o.signature}" class="signatureImage">`:''}<p class="muted">${esc(o.settingsSnapshot?.terms||loadSettings().terms)}</p></div>
    ${o.finalNotes?`<div class="detailCard"><h3>Conclusão / entrega</h3><p>${esc(o.finalNotes)}</p>${o.kmOut?`<p><b>Km saída:</b> ${esc(o.kmOut)}</p>`:''}</div>`:''}
    ${aiInternal}
    ${avaliaReceived}
    <div class="detailCard integrationCard internalOnly noPrint">
      <div class="integrationTitle"><span class="avaliaBadge">↗</span><div><h3 style="margin:0">MOBIWAY Avalia</h3><p class="muted" style="margin:3px 0 0">Enviar ou atualizar esta viatura na avaliação e compra de usados.</p></div></div>
      <button class="secondary integrationBtn" type="button" onclick="openMobiwayAvaliaForOrder('${o.id}')">Abrir MOBIWAY Avalia com esta viatura</button>
    </div>
    <div class="detailCard internalOnly noPrint"><h3>Gestão da reparação</h3>
      <label>Estado<select id="orderStatusSelect">${STATUS_FLOW.map(x=>`<option ${x===o.status?'selected':''}>${x}</option>`).join('')}</select></label>
      <div class="actionGrid"><button class="secondary" onclick="saveOrderStatus('${o.id}')">Guardar estado</button><button class="secondary" onclick="newSupplement('${o.id}')">+ Aditamento</button><button class="secondary" onclick="setFinalNotes('${o.id}')">Conclusão</button><button class="primary" onclick="markDelivered('${o.id}')">Marcar entregue</button></div>
      <div class="historyList">${hist}</div></div>
    <div class="printOnly reportDocFooter"><b>MOBIWAY REPAIR · ${esc(o.orderNo)}</b><span>Documento emitido a partir da ordem de reparação. Valores, autorizações e trabalhos adicionais correspondem ao registo guardado na aplicação.</span><span>Impresso em ${esc(now())}</span></div>`;
}
function mutateOrder(id,fn){ const arr=orders(),i=arr.findIndex(x=>x.id===id); if(i<0)return; fn(arr[i]); arr[i].updatedAt=now(); saveOrders(arr); renderOrderDetail(arr[i]); updateHome(); }
window.saveOrderStatus=id=>{ const st=$('#orderStatusSelect').value; mutateOrder(id,o=>{ if(o.status!==st){o.status=st;(o.statusHistory||=[]).push({status:st,at:now()});} }); toast('Estado atualizado.'); };
window.newSupplement=id=>{
  const description=prompt('Descrição do trabalho adicional:'); if(!description)return;
  const amount=num(prompt('Valor adicional TOTAL com IVA (€):')); if(amount<=0)return;
  const reason=prompt('Motivo / observação (opcional):')||'';
  mutateOrder(id,o=>{ (o.supplements||=[]).push({id:'AD'+Date.now(),description,reason,amountGross:amount,status:'A aguardar autorização',createdAt:now()}); o.status='Aguardar autorização'; (o.statusHistory||=[]).push({status:'Aguardar autorização — aditamento',at:now()}); });
  toast('Aditamento criado. Aguarda autorização.');
};
window.setSupplementStatus=(id,sid,status)=>{ mutateOrder(id,o=>{ const s=(o.supplements||[]).find(x=>x.id===sid); if(s){s.status=status;s.decidedAt=now();} }); toast(`Aditamento: ${status}.`); };
window.setFinalNotes=id=>{
  const arr=orders(),o=arr.find(x=>x.id===id); if(!o)return;
  const notes=prompt('Resumo dos trabalhos realizados / recomendações:',o.finalNotes||''); if(notes===null)return;
  const km=prompt('Quilómetros à saída:',o.kmOut||'');
  mutateOrder(id,x=>{x.finalNotes=notes;x.kmOut=km||x.kmOut;x.status='Pronto';(x.statusHistory||=[]).push({status:'Pronto',at:now()});}); toast('Conclusão registada.');
};
window.markDelivered=id=>{ if(!confirm('Confirmar entrega da viatura ao cliente?'))return; mutateOrder(id,o=>{o.status='Entregue';o.deliveredAt=now();(o.statusHistory||=[]).push({status:'Entregue',at:now()});}); toast('Viatura marcada como entregue.'); };

/* ===== Settings ===== */
$('#settingsBtn').onclick=()=>{ fillSettings(); refreshRepairBackupSummary(); show('settings'); };
function fillSettings(){
  const s=loadSettings(); $('#setShopName').value=s.shopName; $('#setLegalName').value=s.legalName; $('#setLaborRate').value=s.laborRate;
  $('#setDiagnosticFee').value=s.diagnosticFee; $('#setPartsMargin').value=s.partsMarginPct; $('#setConsumablesPct').value=s.consumablesPct;
  $('#setVatPct').value=s.vatPct; $('#setWarrantyMonths').value=s.warrantyMonths; $('#setResearchEndpoint').value=s.researchEndpoint; $('#setTerms').value=s.terms;
}
$('#saveSettingsBtn').onclick=()=>{
  saveSettingsData({shopName:$('#setShopName').value||'MOBIWAY',legalName:$('#setLegalName').value,laborRate:num($('#setLaborRate').value),diagnosticFee:num($('#setDiagnosticFee').value),
    partsMarginPct:num($('#setPartsMargin').value),consumablesPct:num($('#setConsumablesPct').value),vatPct:num($('#setVatPct').value,23),warrantyMonths:num($('#setWarrantyMonths').value),
    researchEndpoint:$('#setResearchEndpoint').value.trim()||DEFAULT_SETTINGS.researchEndpoint,terms:$('#setTerms').value}); toast('Configurações guardadas.'); calcTotal();
};

/* ===== Native backup / restore ===== */
function repairBackupPayload(){ return {app:'MOBIWAY REPAIR',version:2,exportedAt:new Date().toISOString(),settings:loadSettings(),orders:orders()}; }
function refreshRepairBackupSummary(){
  const el=$('#repairBackupSummary'); if(!el)return;
  const arr=orders(), photos=arr.reduce((n,o)=>n+(o.photos||[]).length,0), av=arr.reduce((n,o)=>n+(o.avaliaResults||[]).length,0);
  el.innerHTML=`<span><b>${arr.length}</b> ordens</span><span><b>${photos}</b> fotos</span><span><b>${av}</b> avaliações</span>`;
}
function exportRepairBackup(){
  const payload=JSON.stringify(repairBackupPayload(),null,2), name=`mobiway-repair-backup-${new Date().toISOString().slice(0,10)}.json`;
  if(window.AndroidBridge&&typeof AndroidBridge.exportBackup==='function'){AndroidBridge.exportBackup(name,payload);toast('Escolhe onde guardar o backup.');return;}
  toast('Backup disponível na aplicação Android.');
}
function importRepairBackup(){
  if(window.AndroidBridge&&typeof AndroidBridge.importBackup==='function'){AndroidBridge.importBackup();return;}
  toast('Importação disponível na aplicação Android.');
}
window.receiveRepairBackup=raw=>{
  try{
    const data=typeof raw==='string'?JSON.parse(raw):raw;
    if(!data||!Array.isArray(data.orders)) throw new Error('invalid');
    if(data.settings) saveSettingsData({...DEFAULT_SETTINGS,...data.settings});
    saveOrders(data.orders);
    fillSettings();refreshRepairBackupSummary();updateHome();show('home');
    toast(`Backup importado · ${data.orders.length} ordens.`);
  }catch(e){toast('Ficheiro de backup inválido ou incompatível.')}
};
document.getElementById('exportRepairBackupBtn')?.addEventListener('click',exportRepairBackup);
document.getElementById('importRepairBackupBtn')?.addEventListener('click',importRepairBackup);

/* ===== A4 print ===== */
$('#printBtn').onclick=()=>{
  if(window.AndroidBridge && typeof window.AndroidBridge.printA4==='function') window.AndroidBridge.printA4(); else window.print();
};

/* ===== Signature ===== */
const canvas=$('#signature'),ctx=canvas.getContext('2d'); ctx.lineWidth=4;ctx.lineCap='round';ctx.strokeStyle='#111'; let drawing=false;
function pos(e){const r=canvas.getBoundingClientRect(),p=e.touches?e.touches[0]:e;return{x:(p.clientX-r.left)*canvas.width/r.width,y:(p.clientY-r.top)*canvas.height/r.height}}
function start(e){drawing=true;const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);e.preventDefault()}
function move(e){if(!drawing)return;const p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();e.preventDefault()}
function end(){drawing=false}
canvas.addEventListener('pointerdown',start);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',end);canvas.addEventListener('pointerleave',end);
canvas.addEventListener('touchstart',start,{passive:false});canvas.addEventListener('touchmove',move,{passive:false});canvas.addEventListener('touchend',end);
$('#clearSignature').onclick=()=>ctx.clearRect(0,0,canvas.width,canvas.height);

/* ===== Startup ===== */
addEstimateLine('Diagnóstico inicial',1,loadSettings().diagnosticFee);
const returnedOrderId=importAvaliaResult();
updateHome();
if(returnedOrderId) setTimeout(()=>window.openOrder(returnedOrderId),120);
