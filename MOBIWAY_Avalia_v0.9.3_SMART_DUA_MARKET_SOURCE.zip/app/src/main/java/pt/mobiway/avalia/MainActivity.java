package pt.mobiway.avalia;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import org.json.JSONArray;

import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_PERMISSION = 2001;
    private static final int BACKUP_EXPORT = 3001;
    private static final int BACKUP_IMPORT = 3002;
    private static final int STORE_EXPORT = 3003;
    private static final String EXTRA_REPAIR_VEHICLE = "MOBIWAY_REPAIR_VEHICLE_JSON";
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";
    private static final String EXTRA_REPAIR_PAYLOAD_URI = "MOBIWAY_REPAIR_PAYLOAD_URI";
    private static final String EXTRA_AVALIA_RESULT_URI = "MOBIWAY_AVALIA_RESULT_URI";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean cameraRequest;
    private String pendingBackupJson = "{}";
    private String pendingBackupFileName = "mobiway-avalia-backup.json";
    private String pendingStorePackageJson = "{}";
    private String pendingStorePackageFileName = "mobiway-shopbuilder.zip";
    private String pendingStoreEditorUrl = "https://www.amen.pt/";

    private static String csvCell(String value) {
        String v = value == null ? "" : value.replace("\r", " ").replace("\n", " ");
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    private static void zipText(ZipOutputStream zip, String name, String text) throws Exception {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        zip.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static byte[] dataUrlBytes(String dataUrl) {
        if (dataUrl == null || dataUrl.trim().isEmpty()) return new byte[0];
        int comma = dataUrl.indexOf(',');
        String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
        return android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
    }

    private void writeStorePackage(OutputStream output, String rawJson) throws Exception {
        JSONObject root = new JSONObject(rawJson == null ? "{}" : rawJson);
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zipText(zip, "listing.json", root.toString(2));
            zipText(zip, "description.txt", root.optString("description", ""));
            zipText(zip, "short-description.txt", root.optString("shortDescription", ""));

            String header = "ProductNumber;Name;ListPrice/EUR/gross;ShortDescription;Description;Manufacturer;StockLevel;Visible;Category\n";
            String row = String.join(";",
                csvCell(root.optString("productNumber", "")),
                csvCell(root.optString("name", "")),
                csvCell(String.valueOf(root.optDouble("price", 0))),
                csvCell(root.optString("shortDescription", "")),
                csvCell(root.optString("description", "")),
                csvCell(root.optString("manufacturer", "")),
                csvCell(String.valueOf(root.optInt("stocklevel", 1))),
                csvCell(root.optBoolean("visible", true) ? "Yes" : "No"),
                csvCell(root.optString("category", "Viaturas"))
            ) + "\n";
            zipText(zip, "products.csv", header + row);

            org.json.JSONArray photos = root.optJSONArray("photos");
            if (photos != null) {
                for (int i = 0; i < photos.length(); i++) {
                    JSONObject ph = photos.optJSONObject(i);
                    if (ph == null) continue;
                    byte[] bytes = dataUrlBytes(ph.optString("data", ""));
                    if (bytes.length == 0) continue;
                    String name = ph.optString("name", "foto-" + (i + 1) + ".jpg").replaceAll("[^A-Za-z0-9._-]", "_");
                    if (!name.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(jpg|jpeg|png)$")) name += ".jpg";
                    ZipEntry entry = new ZipEntry(String.format(java.util.Locale.ROOT, "photos/%02d-%s", i + 1, name));
                    zip.putNextEntry(entry);
                    zip.write(bytes);
                    zip.closeEntry();
                }
            }

            String readme = "MOBIWAY · pacote de anúncio ShopBuilder\n\n" +
                "Conteúdo:\n- products.csv: dados do produto para importação\n- listing.json: cópia estruturada completa\n- description.txt: descrição longa\n- photos/: fotografias selecionadas\n\n" +
                "No ShopBuilder da Amen: Produtos > Importar/Exportar, ou crie um novo produto e use estes dados. Confirme preço, fotografias e visibilidade antes de Publicar.\n";
            zipText(zip, "README.txt", readme);
        }
    }

    private void publishStoreListingNative(String payload, String publisherUrl) {
        new Thread(() -> {
            JSONObject out = new JSONObject();
            try {
                URL url = new URL(publisherUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Accept", "application/json");
                byte[] body = (payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }
                int status = conn.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
                String response = stream == null ? "" : new String(stream.readAllBytes(), StandardCharsets.UTF_8);
                if (status >= 200 && status < 300) {
                    out.put("ok", true);
                    try {
                        JSONObject remote = new JSONObject(response);
                        if (remote.has("productId")) out.put("productId", remote.optString("productId"));
                        if (remote.has("productUrl")) out.put("productUrl", remote.optString("productUrl"));
                    } catch (Exception ignored) { }
                } else {
                    out.put("ok", false);
                    out.put("error", "Publisher respondeu HTTP " + status + (response.isEmpty() ? "" : ": " + response.substring(0, Math.min(240, response.length()))));
                }
                conn.disconnect();
            } catch (Exception e) {
                try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha na publicação." : e.getMessage()); } catch (Exception ignored) { }
            }
            evaluateJavascriptCallback("window.Mobiway.receiveStorePublish", out);
        }).start();
    }

    private Uri writeIntegrationPayload(String prefix, String payload) {
        try {
            File dir = new File(getCacheDir(), "integration");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile(prefix, ".json", dir);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write((payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8));
            }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readIntegrationPayload(Intent intent, String uriKey) {
        if (intent == null) return "";
        try {
            Uri uri = intent.getParcelableExtra(uriKey);
            if (uri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return "";
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            return "";
        }
    }


    private static class PlateCandidate {
        final String plate;
        final int corrections;
        PlateCandidate(String plate, int corrections) {
            this.plate = plate;
            this.corrections = corrections;
        }
    }

    private static Character asLetter(char c) {
        c = Character.toUpperCase(c);
        if (c >= 'A' && c <= 'Z') return c;
        switch (c) {
            case '0': return 'O';
            case '1': return 'I';
            case '2': return 'Z';
            case '4': return 'A';
            case '5': return 'S';
            case '6': return 'G';
            case '8': return 'B';
            default: return null;
        }
    }

    private static Character asDigit(char c) {
        c = Character.toUpperCase(c);
        if (c >= '0' && c <= '9') return c;
        switch (c) {
            case 'O': case 'Q': case 'D': return '0';
            case 'I': case 'L': return '1';
            case 'Z': return '2';
            case 'A': return '4';
            case 'S': return '5';
            case 'G': return '6';
            case 'B': return '8';
            default: return null;
        }
    }

    private static PlateCandidate applyPlateMask(String raw, String mask) {
        if (raw == null || raw.length() != 6 || mask.length() != 6) return null;
        StringBuilder out = new StringBuilder(6);
        int corrections = 0;
        for (int i = 0; i < 6; i++) {
            char source = Character.toUpperCase(raw.charAt(i));
            Character mapped;
            if (mask.charAt(i) == 'L') {
                mapped = asLetter(source);
                if (mapped == null) return null;
                if (!(source >= 'A' && source <= 'Z')) corrections++;
            } else {
                mapped = asDigit(source);
                if (mapped == null) return null;
                if (!(source >= '0' && source <= '9')) corrections++;
            }
            out.append(mapped);
        }
        if (corrections > 2) return null;
        String c = out.toString();
        return new PlateCandidate(c.substring(0,2) + "-" + c.substring(2,4) + "-" + c.substring(4,6), corrections);
    }

    private static PlateCandidate findPortugalPlate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        java.util.regex.Pattern token = java.util.regex.Pattern.compile(
            "(?i)(?<![A-Z0-9])([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})(?![A-Z0-9])"
        );
        java.util.regex.Matcher m = token.matcher(text.toUpperCase(java.util.Locale.ROOT));
        PlateCandidate best = null;
        String[] masks = {"LLDDLL", "LLDDDD", "DDLLDD", "DDDDLL"};
        while (m.find()) {
            String raw = (m.group(1) + m.group(2) + m.group(3)).replaceAll("[^A-Z0-9]", "");
            for (String mask : masks) {
                PlateCandidate c = applyPlateMask(raw, mask);
                if (c != null && (best == null || c.corrections < best.corrections)) best = c;
            }
        }
        return best;
    }

    private void evaluateJavascriptCallback(String functionName, JSONObject payload) {
        final String js = "if(typeof " + functionName + "==='function'){" + functionName + "(" + JSONObject.quote(payload.toString()) + ");}";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void recognizePlateNative(String dataUrl, String callbackFunction) {
        try {
            if (dataUrl == null || dataUrl.trim().isEmpty()) throw new IllegalArgumentException("Imagem vazia");
            int comma = dataUrl.indexOf(',');
            String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível abrir a fotografia");
            com.google.mlkit.vision.common.InputImage image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.TextRecognizer recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
            );
            recognizer.process(image)
                .addOnSuccessListener(result -> {
                    JSONObject out = new JSONObject();
                    try {
                        PlateCandidate candidate = findPortugalPlate(result.getText());
                        if (candidate == null) {
                            out.put("ok", false);
                            out.put("error", "Não foi possível reconhecer uma matrícula portuguesa na fotografia.");
                        } else {
                            out.put("ok", true);
                            out.put("plate", candidate.plate);
                            out.put("confidence", Math.max(75, 99 - candidate.corrections * 9));
                            out.put("corrections", candidate.corrections);
                        }
                    } catch (Exception e) {
                        try { out.put("ok", false); out.put("error", "Erro ao interpretar a matrícula."); } catch (Exception ignored) { }
                    }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                })
                .addOnFailureListener(e -> {
                    JSONObject out = new JSONObject();
                    try { out.put("ok", false); out.put("error", "Falha na leitura OCR: " + (e.getMessage() == null ? "erro desconhecido" : e.getMessage())); } catch (Exception ignored) { }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                });
        } catch (Exception e) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha ao preparar a fotografia." : e.getMessage()); } catch (Exception ignored) { }
            evaluateJavascriptCallback(callbackFunction, out);
        }
    }

    private boolean openCheckViaturaNative(String plate) {
        final String cleanPlate = plate == null ? "" : plate.trim().toUpperCase(java.util.Locale.ROOT);
        if (cleanPlate.isEmpty()) return false;
        try {
            runOnUiThread(() -> {
                try {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Matrícula", cleanPlate));
                    openExternal(Uri.parse("https://checkviatura.pt/"));
                } catch (Exception ignored) { }
            });
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }


    private static String cleanOcrValue(String value) {
        if (value == null) return "";
        String v = value.trim().replaceAll("\\s+", " ");
        return v.replaceAll("^[\\s:;,.\\-]+|[\\s:;,.]+$", "").trim();
    }

    private static boolean looksLikeDuaDescriptor(String value) {
        String v = value == null ? "" : value.toLowerCase(java.util.Locale.ROOT);
        return v.isEmpty() || v.equals("marca") || v.startsWith("tipo") || v.startsWith("modelo") ||
            v.startsWith("designa") || v.startsWith("cilindrada") || v.startsWith("potência") ||
            v.startsWith("potencia") || v.startsWith("combust") || v.equals("cor") ||
            v.startsWith("lugares") || v.startsWith("matrícula") || v.startsWith("matricula") ||
            v.startsWith("número") || v.startsWith("numero") || v.startsWith("data");
    }

    private static String duaField(String text, String codeRegex) {
        if (text == null) return "";
        String[] lines = text.replace("\\r", "").split("\\n");
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("(?i)^\\s*" + codeRegex + "\\s*[:;\\-]?\\s*(.*)$");
        for (int i = 0; i < lines.length; i++) {
            java.util.regex.Matcher m = p.matcher(lines[i].trim());
            if (!m.find()) continue;
            String rest = cleanOcrValue(m.group(1));
            if (!looksLikeDuaDescriptor(rest)) return rest;
            for (int j = i + 1; j < Math.min(lines.length, i + 4); j++) {
                String next = cleanOcrValue(lines[j]);
                if (!next.isEmpty() && !looksLikeDuaDescriptor(next) && !next.matches("(?i)^[A-Z]\\s*\\.?\\s*\\d?(?:\\.\\d+)?$")) return next;
            }
        }
        return "";
    }

    private static String firstRegex(String text, String regex) {
        if (text == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.MULTILINE).matcher(text);
        return m.find() ? cleanOcrValue(m.group(1)) : "";
    }

    private static int parseFirstInt(String value) {
        if (value == null) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,7})").matcher(value.replace(" ", ""));
        if (!m.find()) return 0;
        try { return Integer.parseInt(m.group(1)); } catch (Exception ignored) { return 0; }
    }

    private static double parseFirstDouble(String value) {
        if (value == null) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,5}(?:[.,]\\d{1,3})?)").matcher(value.replace(" ", ""));
        if (!m.find()) return 0;
        try { return Double.parseDouble(m.group(1).replace(',', '.')); } catch (Exception ignored) { return 0; }
    }

    private static JSONObject parseDuaText(String text) throws Exception {
        JSONObject out = new JSONObject();
        PlateCandidate pc = findPortugalPlate(text);
        if (pc != null) out.put("plate", pc.plate);

        String vin = firstRegex(text, "(?<![A-Z0-9])([A-HJ-NPR-Z0-9]{17})(?![A-Z0-9])");
        if (vin.isEmpty()) vin = duaField(text, "E");
        vin = vin.toUpperCase(java.util.Locale.ROOT).replaceAll("[^A-HJ-NPR-Z0-9]", "");
        if (vin.length() == 17) out.put("vin", vin);

        String brand = duaField(text, "D\\s*\\.\\s*1");
        String typeVersion = duaField(text, "D\\s*\\.\\s*2");
        String model = duaField(text, "D\\s*\\.\\s*3");
        if (!brand.isEmpty()) out.put("brand", brand);
        if (!model.isEmpty()) out.put("model", model);
        if (!typeVersion.isEmpty()) out.put("version", typeVersion);

        String date = duaField(text, "B");
        if (date.isEmpty()) date = firstRegex(text, "(\\d{1,2}[./-]\\d{1,2}[./-]\\d{4})");
        java.util.regex.Matcher dm = java.util.regex.Pattern.compile("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").matcher(date);
        if (dm.find()) {
            out.put("month", Integer.parseInt(dm.group(2)));
            out.put("year", Integer.parseInt(dm.group(3)));
        } else {
            java.util.regex.Matcher ym = java.util.regex.Pattern.compile("(\\d{4})[./-](\\d{1,2})[./-](\\d{1,2})").matcher(date);
            if (ym.find()) { out.put("year", Integer.parseInt(ym.group(1))); out.put("month", Integer.parseInt(ym.group(2))); }
        }

        int cc = parseFirstInt(duaField(text, "P\\s*\\.\\s*1"));
        double kw = parseFirstDouble(duaField(text, "P\\s*\\.\\s*2"));
        String fuel = duaField(text, "P\\s*\\.\\s*3");
        String color = duaField(text, "R");
        int seats = parseFirstInt(duaField(text, "S\\s*\\.\\s*1"));
        int co2 = parseFirstInt(duaField(text, "V\\s*\\.\\s*7"));
        if (cc > 0) out.put("engineCc", cc);
        if (kw > 0) { out.put("powerKw", kw); out.put("powerHp", Math.round(kw * 1.359621617)); }
        if (!fuel.isEmpty()) out.put("fuel", fuel);
        if (!color.isEmpty()) out.put("color", color);
        if (seats > 0 && seats < 100) out.put("seats", seats);
        if (co2 > 0 && co2 < 1000) out.put("co2", co2);
        return out;
    }

    private void recognizeDuaNative(String dataUrl) {
        try {
            if (dataUrl == null || dataUrl.trim().isEmpty()) throw new IllegalArgumentException("Imagem vazia");
            int comma = dataUrl.indexOf(',');
            String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível abrir a fotografia do DUA");
            com.google.mlkit.vision.common.InputImage image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.TextRecognizer recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
            );
            recognizer.process(image).addOnSuccessListener(result -> {
                JSONObject out = new JSONObject();
                try {
                    out = parseDuaText(result.getText());
                    boolean useful = out.has("vin") || out.has("brand") || out.has("model") || out.has("engineCc") || out.has("plate");
                    out.put("ok", useful);
                    out.put("confidence", useful ? 88 : 0);
                    if (!useful) out.put("error", "O DUA foi lido, mas não foi possível identificar campos técnicos. Fotografa o documento completo e sem reflexos.");
                } catch (Exception e) {
                    try { out.put("ok", false); out.put("error", "Erro ao interpretar o DUA."); } catch (Exception ignored) { }
                }
                evaluateJavascriptCallback("window.Mobiway.receiveDuaScan", out);
                recognizer.close();
                bitmap.recycle();
            }).addOnFailureListener(e -> {
                JSONObject out = new JSONObject();
                try { out.put("ok", false); out.put("error", "Falha OCR do DUA: " + (e.getMessage() == null ? "erro desconhecido" : e.getMessage())); } catch (Exception ignored) { }
                evaluateJavascriptCallback("window.Mobiway.receiveDuaScan", out);
                recognizer.close();
                bitmap.recycle();
            });
        } catch (Exception e) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha ao preparar a fotografia do DUA." : e.getMessage()); } catch (Exception ignored) { }
            evaluateJavascriptCallback("window.Mobiway.receiveDuaScan", out);
        }
    }

    private static String httpGetJson(String urlString) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(25000);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "MOBIWAY-Avalia/0.9.3");
        int status = conn.getResponseCode();
        InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = stream == null ? "" : new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        conn.disconnect();
        if (status < 200 || status >= 300) throw new IllegalStateException("HTTP " + status + (response.isEmpty() ? "" : ": " + response.substring(0, Math.min(180, response.length()))));
        return response;
    }

    private void lookupVinNative(String vin, String year) {
        final String cleanVin = vin == null ? "" : vin.trim().toUpperCase(java.util.Locale.ROOT).replaceAll("[^A-HJ-NPR-Z0-9]", "");
        if (cleanVin.length() != 17) return;
        new Thread(() -> {
            JSONObject out = new JSONObject();
            try {
                String url = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/" + URLEncoder.encode(cleanVin, "UTF-8") + "?format=json";
                if (year != null && year.matches("\\d{4}")) url += "&modelyear=" + year;
                JSONObject root = new JSONObject(httpGetJson(url));
                JSONArray arr = root.optJSONArray("Results");
                JSONObject r = arr != null && arr.length() > 0 ? arr.optJSONObject(0) : null;
                if (r == null) throw new IllegalStateException("Sem resultado VIN");
                out.put("ok", true);
                out.put("make", r.optString("Make", ""));
                out.put("model", r.optString("Model", ""));
                out.put("year", r.optString("ModelYear", ""));
                int cc = (int) Math.round(r.optDouble("DisplacementCC", 0));
                if (cc <= 0) { double l = r.optDouble("DisplacementL", 0); if (l > 0) cc = (int)Math.round(l * 1000); }
                out.put("engineCc", cc);
                out.put("powerHp", r.optString("EngineHP", ""));
                out.put("fuel", r.optString("FuelTypePrimary", ""));
                out.put("transmission", r.optString("TransmissionStyle", ""));
                out.put("bodyClass", r.optString("BodyClass", ""));
                out.put("plantCountry", r.optString("PlantCountry", ""));
            } catch (Exception e) {
                try { out.put("ok", false); out.put("error", e.getMessage() == null ? "VIN sem dados adicionais." : e.getMessage()); } catch (Exception ignored) { }
            }
            evaluateJavascriptCallback("window.Mobiway.receiveVinLookup", out);
        }).start();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(9, 10, 12));
        getWindow().setNavigationBarColor(Color.rgb(9, 10, 12));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 10, 12));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void recognizePlate(String dataUrl) {
                recognizePlateNative(dataUrl, "window.Mobiway.receivePlateScan");
            }

            @JavascriptInterface
            public void recognizeDua(String dataUrl) {
                recognizeDuaNative(dataUrl);
            }

            @JavascriptInterface
            public void lookupVin(String vin, String year) {
                lookupVinNative(vin, year);
            }


            @JavascriptInterface
            public boolean openCheckViatura(String plate) {
                return openCheckViaturaNative(plate);
            }

            @JavascriptInterface
            public void printPdf() {
                runOnUiThread(() -> createPrintJob());
            }

            @JavascriptInterface
            public void exportBackup(String fileName, String json) {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupFileName = (fileName == null || fileName.trim().isEmpty())
                    ? "mobiway-avalia-backup.json" : fileName;
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFileName);
                        startActivityForResult(intent, BACKUP_EXPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void importBackup() {
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        startActivityForResult(intent, BACKUP_IMPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void exportStorePackage(String fileName, String json, String editorUrl) {
                pendingStorePackageJson = json == null ? "{}" : json;
                pendingStorePackageFileName = (fileName == null || fileName.trim().isEmpty()) ? "mobiway-shopbuilder.zip" : fileName;
                pendingStoreEditorUrl = (editorUrl == null || editorUrl.trim().isEmpty()) ? "https://www.amen.pt/" : editorUrl.trim();
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/zip");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingStorePackageFileName);
                        startActivityForResult(intent, STORE_EXPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void publishStoreListing(String json, String publisherUrl) {
                if (publisherUrl == null || publisherUrl.trim().isEmpty()) {
                    JSONObject out = new JSONObject();
                    try { out.put("ok", false); out.put("error", "Publisher/API não configurado."); } catch (Exception ignored) { }
                    evaluateJavascriptCallback("window.Mobiway.receiveStorePublish", out);
                    return;
                }
                publishStoreListingNative(json == null ? "{}" : json, publisherUrl.trim());
            }

            @JavascriptInterface
            public boolean openStoreEditor(String url) {
                try {
                    String target = (url == null || url.trim().isEmpty()) ? "https://www.amen.pt/" : url.trim();
                    openExternal(Uri.parse(target));
                    return true;
                } catch (Exception ignored) { return false; }
            }

            @JavascriptInterface
            public String getRepairPayload() {
                Intent intent = getIntent();
                if (intent == null) return "";
                String payload = intent.getStringExtra(EXTRA_REPAIR_VEHICLE);
                if (payload != null && !payload.isEmpty()) return payload;
                return readIntegrationPayload(intent, EXTRA_REPAIR_PAYLOAD_URI);
            }

            @JavascriptInterface
            public void clearRepairPayload() {
                Intent intent = getIntent();
                if (intent != null) {
                    intent.removeExtra(EXTRA_REPAIR_VEHICLE);
                    intent.removeExtra(EXTRA_REPAIR_PAYLOAD_URI);
                }
            }

            @JavascriptInterface
            public boolean openRepair() {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                    if (launch == null) return false;
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }

            @JavascriptInterface
            public boolean returnToRepair(String resultJson) {
                final String payload = resultJson == null ? "{}" : resultJson;
                final Uri payloadUri = writeIntegrationPayload("avalia_to_repair_", payload);
                try {
                    Intent launch = new Intent();
                    launch.setClassName("pt.mobiway.repair", "pt.mobiway.repair.MainActivity");
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (payloadUri != null) {
                        launch.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                        launch.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                        launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else if (payload.length() < 300000) {
                        launch.putExtra(EXTRA_AVALIA_RESULT, payload);
                    }
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                        if (fallback == null) return false;
                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        if (payloadUri != null) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                            fallback.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } else if (payload.length() < 300000) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT, payload);
                        }
                        fallback.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                        startActivity(fallback);
                        return true;
                    } catch (Exception ignored) {
                        return false;
                    }
                }
            }
        }, "AndroidBridge");
        webView.addJavascriptInterface(new MobiwayCloudBridge(this, webView, "avalia"), "MobiwayCloud");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                    "window.print=function(){if(window.AndroidBridge&&AndroidBridge.printPdf){AndroidBridge.printPdf();}};",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }

                fileCallback = callback;

                boolean capturePreferred =
                    params != null && params.isCaptureEnabled();

                launchChooser(capturePreferred);
                return true;
            }

            @Override
            public boolean onCreateWindow(
                    WebView view,
                    boolean isDialog,
                    boolean isUserGesture,
                    android.os.Message resultMsg) {

                WebView temp = new WebView(MainActivity.this);

                temp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView v,
                            WebResourceRequest req) {
                        openExternal(req.getUrl());
                        return true;
                    }
                });

                WebView.WebViewTransport transport =
                    (WebView.WebViewTransport) resultMsg.obj;

                transport.setWebView(temp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                new String[]{Manifest.permission.CAMERA},
                CAMERA_PERMISSION
            );
        }

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void launchChooser(boolean capturePreferred) {
        cameraRequest = capturePreferred;

        if (capturePreferred) {
            launchCamera();
            return;
        }

        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        gallery.addCategory(Intent.CATEGORY_OPENABLE);
        gallery.setType("image/*");
        gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        gallery.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(gallery, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {

            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType("image/*");
            fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

            try {
                startActivityForResult(
                    Intent.createChooser(
                        fallback,
                        "Fotografias da viatura"
                    ),
                    FILE_CHOOSER
                );

            } catch (ActivityNotFoundException ignored) {
                finishFileChooser(null);
            }
        }
    }

    private void launchCamera() {
        Intent camera =
            new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        ContentValues values = new ContentValues();

        values.put(
            MediaStore.Images.Media.DISPLAY_NAME,
            "mobiway_" + System.currentTimeMillis() + ".jpg"
        );

        values.put(
            MediaStore.Images.Media.MIME_TYPE,
            "image/jpeg"
        );

        cameraUri =
            getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            );

        if (cameraUri != null) {
            camera.putExtra(
                MediaStore.EXTRA_OUTPUT,
                cameraUri
            );

            camera.addFlags(
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        }

        try {
            startActivityForResult(camera, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {
            finishFileChooser(null);
        }
    }

    private void createPrintJob() {
        if (webView == null) return;

        PrintManager printManager =
            (PrintManager) getSystemService(PRINT_SERVICE);

        if (printManager == null) return;

        PrintDocumentAdapter adapter =
            webView.createPrintDocumentAdapter(
                "MOBIWAY Avalia"
            );

        printManager.print(
            "MOBIWAY Avalia",
            adapter,
            new PrintAttributes.Builder().build()
        );
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(
                new Intent(Intent.ACTION_VIEW, uri)
            );
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
            requestCode,
            resultCode,
            data
        );

        if (requestCode == STORE_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out != null) writeStorePackage(out, pendingStorePackageJson);
                } catch (Exception ignored) { }
                final String editor = pendingStoreEditorUrl;
                if (editor != null && !editor.trim().isEmpty()) runOnUiThread(() -> openExternal(Uri.parse(editor)));
            }
            return;
        }

        if (requestCode == BACKUP_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out != null) out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode == BACKUP_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in != null) {
                        byte[] bytes = in.readAllBytes();
                        String json = new String(bytes, StandardCharsets.UTF_8);
                        String js = "if(window.Mobiway&&Mobiway.receiveNativeBackup){Mobiway.receiveNativeBackup(" + JSONObject.quote(json) + ");}";
                        webView.post(() -> webView.evaluateJavascript(js, null));
                    }
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode != FILE_CHOOSER ||
                fileCallback == null) {
            return;
        }

        if (resultCode != RESULT_OK) {
            finishFileChooser(null);
            return;
        }

        List<Uri> uris = new ArrayList<>();

        if (data != null) {

            ClipData clipData = data.getClipData();

            if (clipData != null) {

                for (int i = 0;
                     i < clipData.getItemCount();
                     i++) {

                    Uri uri =
                        clipData.getItemAt(i).getUri();

                    if (uri != null) {
                        uris.add(uri);
                    }
                }

            } else if (data.getData() != null) {

                uris.add(data.getData());
            }
        }

        if (uris.isEmpty() &&
                cameraRequest &&
                cameraUri != null) {

            uris.add(cameraUri);
        }

        finishFileChooser(
            uris.isEmpty()
                ? null
                : uris.toArray(new Uri[0])
        );
    }

    private void finishFileChooser(Uri[] result) {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }

        cameraUri = null;
        cameraRequest = false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        if (webView != null) {
            webView.post(() -> webView.reload());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null &&
                webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
