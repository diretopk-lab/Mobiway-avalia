// Public project identifier; no secret or privileged credential belongs here.
window.MOBIWAY_PORTAL_PROJECT = 'mobiway-cloud';
