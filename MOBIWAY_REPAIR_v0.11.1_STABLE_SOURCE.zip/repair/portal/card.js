(function(){
  'use strict';
  const el=document.getElementById('card');
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const km=v=>v==null?'Km por registar':Number(v).toLocaleString('pt-PT')+' km';
  const date=v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v))?new Date(v+'T12:00:00Z').toLocaleDateString('pt-PT',{timeZone:'UTC'}):'';
  async function load(){
    const token=location.hash.slice(1),project=window.MOBIWAY_PORTAL_PROJECT;
    if(!/^[a-f0-9]{32}$/.test(token)||!/^[a-z0-9-]{6,60}$/.test(project)){unavailable('A ligação do cartão é inválida.');return;}
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
    try{
      const response=await fetch('https://firestore.googleapis.com/v1/projects/'+project+'/databases/(default)/documents/publicCards/'+token,{cache:'no-store',referrerPolicy:'no-referrer',signal:controller.signal});
      if(!response.ok){unavailable(response.status===403||response.status===404?'Este cartão não está disponível. A ligação pode ter expirado ou ter sido revogada pela oficina.':'Não foi possível consultar o cartão. Tente novamente.');return;}
      const doc=await response.json(),card=JSON.parse(doc.fields?.payload?.stringValue||'{}');
      if(card.schema!==1||!card.vehicle||!Array.isArray(card.services)||!Array.isArray(card.plans))throw new Error('Invalid card');
      el.innerHTML='<div class="brand">'+esc(card.shopName)+' · REPAIR</div><h1>O cuidado continua.</h1><p>Histórico autorizado da sua viatura</p><span class="plate">'+esc(card.vehicle.plate)+'</span><h3>'+esc([card.vehicle.make,card.vehicle.model,card.vehicle.year].filter(Boolean).join(' '))+'</h3><p>'+esc(km(card.vehicle.mileage))+' · último registo</p><h2>Próximas manutenções</h2>'+
        (card.plans.length?card.plans.map(p=>'<div class="entry"><h3>'+esc(p.title)+'</h3><p>'+esc([date(p.dueDate),p.dueKm==null?'':km(p.dueKm)].filter(Boolean).join(' ou '))+'</p></div>').join(''):'<p>Sem manutenção programada.</p>')+
        '<h2>Histórico de intervenções</h2>'+(card.services.length?card.services.map(s=>'<div class="entry"><span class="date">'+esc(date(s.date))+' · '+esc(km(s.mileage))+'</span><h3>'+esc(s.title)+'</h3>'+(s.oil?'<p>Óleo: '+esc([s.oil.brand,s.oil.viscosity,s.oil.specification,s.oil.litres==null?'':s.oil.litres+' L'].filter(Boolean).join(' · '))+'</p>':'')+(Array.isArray(s.filters)&&s.filters.length?'<p>Filtros: '+esc(s.filters.join(', '))+'</p>':'')+'</div>').join(''):'<p>Sem intervenções autorizadas para consulta.</p>')+
        '<p class="note">Atualizado em '+esc(new Date(card.updatedAt).toLocaleString('pt-PT'))+'. Os prazos e quilómetros são definidos pela oficina. Este cartão é de consulta e não permite alterar os registos.</p>';
    }catch(error){unavailable('Sem ligação ou cartão indisponível. Tente novamente.');}finally{clearTimeout(timer);}
  }
  function unavailable(message){el.innerHTML='<div class="brand">MOBIWAY · REPAIR</div><h1>Cartão da viatura</h1><p>'+esc(message)+'</p><button class="retry" type="button" id="retry">Tentar novamente</button>';document.getElementById('retry').onclick=load;}
  window.addEventListener('hashchange',load);load();
})();
