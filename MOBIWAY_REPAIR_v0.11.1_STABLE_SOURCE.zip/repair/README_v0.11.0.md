# MOBIWAY Repair 0.11.0 — manutenção e acompanhamento do cliente

Código atualizado sobre a Repair 0.10.2 Smart Scan Fix, recuperada de 24/09/2026. A aplicação conserva `pt.mobiway.repair`, as ordens, os registos fotográficos, assinaturas, orçamentos, aditamentos, Smart Scan e a ligação à Avalia. A versão Android passa de código 17 para 18.

## Funcionalidades implementadas

| Área | Comportamento |
| --- | --- |
| Ficha permanente | Matrícula, marca, modelo, VIN, proprietário, contactos e quilometragem. Recuperação automática das ordens anteriores e prevenção de matrículas duplicadas. |
| Intervenções | Histórico por viatura; tipo de trabalho, data, km, técnico e notas. Ordens entregues criam um registo associado sem o tornar público automaticamente. |
| Óleo e filtros | Viscosidade, norma/aprovação, marca, litros e filtros efetivamente substituídos. Os intervalos são confirmados pela oficina. |
| Manutenção preventiva | Data, quilometragem ou ambos; vence no primeiro limite. Aviso próximo a 30 dias ou 1.000 km. Concluir um lembrete pode gerar o próximo a partir da intervenção real. |
| Agenda | Viatura, serviço, data/hora local, duração e técnico; deteta sobreposição da mesma viatura ou técnico. Cancelamento mantém o registo. |
| Painel | Viaturas registadas, em dia, próximas e com revisões vencidas, além das ordens de oficina. |
| WhatsApp | Consentimento e origem registados. Abre uma mensagem preparada; o utilizador confirma o envio no WhatsApp. A app não envia mensagens sozinha nem afirma que o cliente as recebeu. |
| Cartão QR sem internet | Cartão HTML exportável e impressão PDF/A4. QR com resumo dos dados autorizados; a cópia mostra a data de emissão. |
| Portal QR | Ligação com token aleatório, validade de 90 dias e revogação. Consulta sem edição; apenas intervenções escolhidas pela oficina. Requer publicação do portal, regras e ligação Cloud. |
| Backup | Versão 3 inclui novas fichas, intervenções, planos e agenda. Importa backups versão 2 e junta registos sem apagar as ordens existentes. |
| Cloud | Novas coleções isoladas para a oficina, mesmas permissões de proprietário/administrador/oficina e consulta. Fila local para alterações por sincronizar; versões mais antigas não substituem registos mais recentes. |
| Android | Lembretes locais em segundo plano e após reinício, com permissão de notificações. Não usa envio WhatsApp automático nem alarmes exatos. |

O nome, telefone, email, VIN, notas internas, preços e assinaturas são excluídos do cartão. O QR online é uma ligação de acesso: quem tiver a ligação pode consultar o histórico autorizado durante a validade. Retirar autorização de um cartão publicado exige confirmação da revogação na Cloud. O token é guardado antes da publicação para que um reinício não perca a ligação.

## Verificação realizada em 08/10/2026

- 37 testes automatizados aprovados: lógica de manutenção, execução dos scripts da app num DOM simulado, publicação/revogação simulada, portal com respostas de rede simuladas, compatibilidade de backups, falha de armazenamento, visibilidade dos dados e arranque da pré-visualização autónoma.
- Sintaxe Java verificada nos três ficheiros nativos com o compilador JDK, sem resolução dos tipos Android.
- Sintaxe dos scripts JavaScript e integridade dos ficheiros JSON/XML verificadas.

Não foi produzido um APK nesta execução. O ambiente não tinha SDK Android/Gradle e não conseguiu obter as dependências; também não foi possível instalar o navegador de testes. A validação visual em navegador, compilação Android, lint Android, notificações num equipamento real e sincronização com Firebase em produção estão pendentes. As regras Firestore não foram executadas num emulador nem publicadas. O portal não foi publicado. Nenhum APK já instalado foi alterado.

## Testar o código

Na pasta `repair`:

```bash
node --test tests/maintenance.test.cjs tests/interface.test.mjs tests/portal.test.mjs
java tests/ParseJava.java app/src/main/java/pt/mobiway/repair/MainActivity.java app/src/main/java/pt/mobiway/repair/MobiwayCloudBridge.java app/src/main/java/pt/mobiway/repair/MaintenanceReminderReceiver.java
python3 tools/build_preview.py /caminho/MOBIWAY-Repair-v0.11.0-preview.html
```

Os testes de interface usam uma simulação DOM; não substituem o WebView Android. A pré-visualização usa dados fictícios, armazenamento em memória e não contacta serviços online. Não guarda nem substitui dados de uma app instalada.

## Compilar a atualização Android

Usar Java 17, Gradle 8.9, Android SDK 35 e build-tools 35.0.0. A configuração Firebase recuperada permanece em `app/google-services.json`. É necessário usar a mesma chave de assinatura do APK instalado para preservar uma atualização normal e os dados locais.

Definir `MREPAIR_KEYSTORE`, `MREPAIR_STORE_PASSWORD`, `MREPAIR_KEY_ALIAS` e `MREPAIR_KEY_PASSWORD` no ambiente de compilação e executar:

```bash
gradle --no-daemon :app:assembleRelease :app:lintRelease
```

O APK resulta em `app/build/outputs/apk/release/app-release.apk`. A compilação release falha se não estiver configurada a chave original; não gera uma nova assinatura por omissão. A opção explícita `MREPAIR_ALLOW_UNSIGNED_BUILD=true` permite validar a compilação sem chave, produzindo apenas um APK sem assinatura, que não é instalável.

O repositório anterior foi identificado e lido: `diretopk-lab/Mobiway-avalia`, ramo `main`. A compilação v0.10.2 com GitHub Actions terminou com sucesso em 24/09/2026. A tentativa de carregar as alterações nesta execução devolveu HTTP 403: o conector atual não consegue escrever no repositório, apesar das permissões declaradas. Nenhum commit nem compilação 0.11 foi executado.

São necessários apenas dois ficheiros no repositório: `MOBIWAY_REPAIR_v0.11.0_MAINTENANCE_SOURCE.zip` na raiz, sem o descompactar, e `build-repair-maintenance.yml` em `.github/workflows`. O workflow extrai o código completo para uma pasta temporária, sem substituir a app Avalia nem o backend existentes. Não é necessário carregar o pacote OVERLAY anterior. O commit em `main` inicia a compilação; também é possível executar em Actions → MOBIWAY Repair 0.11 - Android verification and signed upgrade → Run workflow. O ramo `repair-maintenance-0-11` continua disponível como alternativa para verificação isolada.

Sem segredos de assinatura, o workflow verifica os testes, compila Android, executa lint e produz um resultado explicitamente marcado como não instalável. Para produzir a atualização assinada, configurar `MREPAIR_KEYSTORE_BASE64`, `MREPAIR_STORE_PASSWORD`, `MREPAIR_KEY_ALIAS` e `MREPAIR_KEY_PASSWORD` nos segredos do GitHub. Nunca carregar o keystore ou as palavras-passe no repositório público.

O pacote de assinatura permanente existente foi recuperado, mas a compatibilidade com o APK anterior ainda não foi confirmada. O workflow verifica o certificado e compara-o com o APK v0.10.2 antes de publicar um ficheiro como atualização. Se não corresponder, bloqueia a publicação: uma chave diferente não atualiza uma instalação existente. O artefacto anterior usado nessa comparação expira em 24/10/2026; depois disso, será necessário conservar o certificado validado ou disponibilizar novamente o APK anterior. Nenhuma chave privada é incluída neste pacote.

Antes de instalar, exportar um backup da versão existente e validar a atualização num dos equipamentos, incluindo passagem de uma viatura à Avalia e regresso à Repair, fotografias, PDF, manutenção e restauro. O APK de debug usa outra assinatura e serve apenas para teste num ambiente separado.

## Ativar o portal e as novas coleções Cloud

A pasta `portal` contém `card.html`, configuração pública do projeto, estilos e cliente REST. `firebase.json` usa o destino de hosting separado `repair-portal` para não substituir o alojamento do Hub. Associar esse destino a um site Firebase Hosting dedicado, já existente ou criado para este portal.

Comparar as regras atuais de produção com a base recuperada em `FIRESTORE.rules` antes da publicação. Conservar outras regras necessárias a módulos já em produção. Publicar as novas regras e o destino dedicado:

```bash
firebase target:apply hosting repair-portal ID_DO_SITE_DEDICADO --project mobiway-cloud
firebase deploy --only firestore:rules,hosting:repair-portal --project mobiway-cloud
```

Configurar nas definições da Repair o endereço HTTPS real de `card.html`, iniciar sessão na Cloud com acesso à oficina, autorizar o cartão na ficha e selecionar as intervenções para consulta. A ligação só aparece pronta depois da confirmação de publicação. Alterações feitas sem ligação ficam pendentes; o portal mantém a última publicação confirmada até sincronizar. Os quilómetros são sempre o último registo manual, não telemetria em tempo real. Os alarmes Android podem sofrer atrasos impostos pelo sistema e usam os dados guardados no equipamento.

O núcleo Cloud pode ser usado pelos cinco equipamentos previstos. O código do Hub não está neste pacote; o Hub poderá consultar `repairVehicles`, `maintenanceEntries`, `maintenancePlans` e `appointments` com as mesmas permissões.

## Referências de implementação

- [Android: alarmes em segundo plano](https://developer.android.com/develop/background-work/services/alarms)
- [Android: permissão de notificações](https://developer.android.com/develop/ui/views/notifications/notification-permission)
- [Firebase: API REST e regras de autorização](https://firebase.google.com/docs/firestore/use-rest-api)
- [QR Code Generator — Project Nayuki, MIT](https://github.com/nayuki/QR-Code-generator)
- [LinkeDOM — runtime dos testes, ISC](https://github.com/WebReflection/linkedom)

O código QR é gerado localmente e não é enviado para serviços de terceiros. Os textos são escapados antes de entrar na interface e no portal.
