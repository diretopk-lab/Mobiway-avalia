"""Build an offline, isolated demo from the real Repair WebView assets."""
from pathlib import Path
import base64
import json
import sys

project = Path(__file__).resolve().parents[1]
web = project / 'app/src/main/assets/www'
target = Path(sys.argv[1]) if len(sys.argv) > 1 else project / 'MOBIWAY-Repair-v0.11.0-preview.html'
html = (web / 'index.html').read_text()
for name in ['styles.css', 'maintenance.css']:
    html = html.replace(f'<link rel="stylesheet" href="{name}">', '<style>' + (web / name).read_text() + '</style>')
for name in ['mobiway-cloud.js', 'qrcodegen.js', 'maintenance.js', 'app.js', 'maintenance-ui.js']:
    script = (web / name).read_text().replace('</script', '<\\/script')
    html = html.replace(f'<script src="{name}"></script>', '<script>' + script + '</script>')
embedded_images = {}
for file in web.glob('*.png'):
    data = 'data:image/png;base64,' + base64.b64encode(file.read_bytes()).decode()
    if 'src="' + file.name + '"' in html:
        embedded_images[file.name] = data
        html = html.replace('src="' + file.name + '"', 'data-demo-image="' + file.name + '"')
    html = html.replace("url('" + file.name + "')", "url('" + data + "')")
    html = html.replace('url("' + file.name + '")', 'url("' + data + '")')
image_script = '<script>(function(){const images=' + json.dumps(embedded_images) + ';document.querySelectorAll("img[data-demo-image]").forEach(img=>{img.src=images[img.dataset.demoImage];});})();</script>'
html = html.replace('</body>', image_script + '</body>')

isolation = """
<script>
(function(){
  const data=new Map();
  const storage={getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k)};
  Object.defineProperty(window,'localStorage',{value:storage,configurable:true});
  window.fetch=async function(){throw new Error('Esta demonstração funciona sem serviços online.');};
  window.addEventListener('DOMContentLoaded',function(){
    const M=window.RepairMaintenance,day=M.today(),at=new Date().toISOString();
    const dayOffset=n=>M.today(new Date(Date.now()+n*86400000));
    const vehicles=[
      {id:'DEMO_V1',plate:'AA-11-BB',plateKey:'AA11BB',make:'Peugeot',model:'407 SW',year:'2008',mileage:308330,customerName:'Cliente exemplo 1',phone:'',whatsappConsent:false,portalConsent:true,mileageAt:at,createdAt:at,updatedAt:at},
      {id:'DEMO_V2',plate:'CC-22-DD',plateKey:'CC22DD',make:'Toyota',model:'Avensis',year:'2006',mileage:155000,customerName:'Cliente exemplo 2',phone:'',whatsappConsent:false,portalConsent:true,mileageAt:at,createdAt:at,updatedAt:at},
      {id:'DEMO_V3',plate:'EE-33-FF',plateKey:'EE33FF',make:'Mercedes-Benz',model:'C 220 CDI',year:'2010',mileage:198000,customerName:'Cliente exemplo 3',phone:'',whatsappConsent:false,portalConsent:true,mileageAt:at,createdAt:at,updatedAt:at}
    ];
    const plans=[
      {id:'DEMO_P1',vehicleId:'DEMO_V1',title:'Revisão de óleo e filtros',type:'oil',dueDate:dayOffset(20),dueKm:313000,intervalKm:15000,intervalMonths:12,state:'active',createdAt:at,updatedAt:at},
      {id:'DEMO_P2',vehicleId:'DEMO_V2',title:'Manutenção programada',type:'other',dueDate:dayOffset(-10),dueKm:154000,intervalKm:null,intervalMonths:null,state:'active',createdAt:at,updatedAt:at},
      {id:'DEMO_P3',vehicleId:'DEMO_V3',title:'Próxima revisão',type:'oil',dueDate:dayOffset(180),dueKm:212000,intervalKm:15000,intervalMonths:12,state:'active',createdAt:at,updatedAt:at}
    ];
    const services=[{id:'DEMO_S1',vehicleId:'DEMO_V1',date:dayOffset(-180),mileage:298000,type:'oil',title:'Mudança de óleo e filtros',notes:'Registo demonstrativo. Os dados são fictícios.',technician:'Técnico exemplo',oil:{viscosity:'5W-30',specification:'Exemplo — confirmar aprovação para a viatura',brand:'Óleo de exemplo',litres:5.5},filters:['Óleo','Ar'],visibleToCustomer:true,createdAt:at,updatedAt:at}];
    const appointments=[{id:'DEMO_A1',vehicleId:'DEMO_V1',title:'Revisão de óleo e filtros',start:dayOffset(1)+'T09:00:00',duration:60,technician:'Técnico exemplo',notes:'Agendamento fictício.',state:'confirmed',createdAt:at,updatedAt:at}];
    window.MobiwayRepairMaintenance.commit({repairVehicles:vehicles,maintenancePlans:plans,maintenanceEntries:services,appointments});
  });
})();
</script>
"""
banner = '<aside class="demoBanner">PRÉ-VISUALIZAÇÃO · Dados fictícios · Alterações apenas nesta sessão. Android e Cloud requerem o APK compilado.</aside>'
html = html.replace('</head>', '<style>.demoBanner{padding:12px 16px;background:#3b2c13;color:#ffe0a7;text-align:center;font:600 12px system-ui;line-height:1.5}.introSplash{display:none!important}</style>' + isolation + '</head>')
html = html.replace('<body>', '<body>' + banner, 1)
html = html.replace('<title>MOBIWAY REPAIR</title>', '<title>MOBIWAY REPAIR 0.11 · Pré-visualização</title>')
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(html)
print(json.dumps({'file': str(target.resolve()), 'size': target.stat().st_size}))
