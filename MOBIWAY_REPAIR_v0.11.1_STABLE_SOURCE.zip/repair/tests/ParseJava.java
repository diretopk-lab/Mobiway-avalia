import java.util.Arrays;
import javax.tools.*;
import com.sun.source.util.JavacTask;
public class ParseJava {
    public static void main(String[] paths) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager files=compiler.getStandardFileManager(diagnostics,null,null)) {
            JavacTask task=(JavacTask)compiler.getTask(null,files,diagnostics,Arrays.asList("-proc:none"),null,files.getJavaFileObjectsFromStrings(Arrays.asList(paths)));
            for(Object unit:task.parse()) { }
            for(Diagnostic<?> d:diagnostics.getDiagnostics()) if(d.getKind()==Diagnostic.Kind.ERROR) {System.err.println(d);System.exit(1);}
            System.out.println("Java syntax parsed: "+paths.length+" files. Android type checking/build requires the SDK.");
        }
    }
}
