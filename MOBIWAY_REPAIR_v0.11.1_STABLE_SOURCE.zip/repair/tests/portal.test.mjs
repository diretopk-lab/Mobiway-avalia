import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {parseHTML} from './vendor/linkedom.mjs';
const source=fs.readFileSync(new URL('../portal/card.js',import.meta.url),'utf8');
async function portal(hash,response){
  const {window,document}=parseHTML('<html><body><main id="card"></main></body></html>');
  let calls=0;window.MOBIWAY_PORTAL_PROJECT='mobiway-cloud';
  const context=vm.createContext({window,document,location:{hash},console,Date,JSON,Intl,AbortController,setTimeout:()=>1,clearTimeout(){},fetch:async()=>{calls++;return response;}});
  vm.runInContext(source,context);await new Promise(resolve=>setImmediate(resolve));
  return {document,calls};
}
test('public portal loads only a token selected authorised snapshot',async()=>{
  const card={schema:1,shopName:'MOBIWAY',updatedAt:new Date().toISOString(),vehicle:{plate:'AA-11-BB',make:'Toyota',model:'Avensis',mileage:150000},services:[{date:'2026-09-01',mileage:149000,title:'Óleo e filtro',filters:['Óleo'],oil:{viscosity:'5W-30',specification:'Norma de exemplo',brand:'Exemplo',litres:5}}],plans:[{title:'Revisão',dueDate:'2027-09-01',dueKm:159000}]};
  const {document,calls}=await portal('#'+'a'.repeat(32),{ok:true,json:async()=>({fields:{payload:{stringValue:JSON.stringify(card)}}})});
  assert.equal(calls,1);assert.match(document.getElementById('card').textContent,/AA-11-BB/);assert.match(document.getElementById('card').textContent,/Óleo e filtro/);assert.match(document.getElementById('card').textContent,/5W-30/);
});
test('revoked and expired cards have a clear unavailable state',async()=>{const {document}=await portal('#'+'a'.repeat(32),{ok:false,status:403});assert.match(document.getElementById('card').textContent,/expirado ou ter sido revogada/);assert.equal(document.querySelectorAll('.plate').length,0);});
test('malformed tokens make no network request',async()=>{const {document,calls}=await portal('#not-a-card',{});assert.equal(calls,0);assert.match(document.getElementById('card').textContent,/inválida/);});
test('network errors do not expose raw tokens or diagnostics',async()=>{const {document}=await portal('#'+'a'.repeat(32),{ok:true,json:async()=>{throw new Error('private diagnostic');}});assert.match(document.getElementById('card').textContent,/Sem ligação/);assert.equal(document.getElementById('card').textContent.includes('private diagnostic'),false);});
test('public service text is escaped before insertion',async()=>{const card={schema:1,shopName:'<img src=x onerror=alert(1)>',updatedAt:new Date().toISOString(),vehicle:{plate:'AA11BB'},services:[{date:'2026-09-01',title:'<script>attack()</script>'}],plans:[]};const {document}=await portal('#'+'a'.repeat(32),{ok:true,json:async()=>({fields:{payload:{stringValue:JSON.stringify(card)}}})});assert.equal(document.querySelectorAll('img,script').length,0);assert.match(document.getElementById('card').textContent,/<script>attack/);});
