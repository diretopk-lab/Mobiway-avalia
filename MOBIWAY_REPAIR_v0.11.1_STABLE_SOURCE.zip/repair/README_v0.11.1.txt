MOBIWAY Repair 0.11.1
44 testes automatizados aprovados.
Ler INSTALACAO-SEGURA.txt: este pacote é uma migração assinada com a chave permanente, não uma atualização direta da versão debug 0.10.2.
O README_v0.11.0.md é um registo histórico da implementação anterior. O estado atual e limitações estão em INSTALACAO-SEGURA.txt e VERSION_PROVENANCE.json.
