package pt.mobiway.repair;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Inexact local reminders; no network, WhatsApp sending or exact-alarm permission. */
public final class MaintenanceReminderReceiver extends BroadcastReceiver {
    private static final String PREFS = "mobiway_repair_reminders";
    private static final String CHANNEL = "mobiway_maintenance";
    private static final long DAY = 86400000L;
    private static PendingIntent alarm(Context context) {
        return PendingIntent.getBroadcast(context, 1101,
            new Intent(context, MaintenanceReminderReceiver.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void save(Context context, String raw) {
        try {
            JSONObject data = new JSONObject(raw);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("snapshot", data.toString()).apply();
            schedule(context);
        } catch (Exception ignored) { }
    }
    private static JSONObject snapshot(Context context) {
        try { return new JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("snapshot", "{}")); }
        catch (Exception ignored) { return new JSONObject(); }
    }
    public static void schedule(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent pending = alarm(context);
        manager.cancel(pending);
        JSONObject data = snapshot(context);
        if (!data.optBoolean("enabled", false)) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(1100);
            return;
        }
        long now = System.currentTimeMillis();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 9); next.set(Calendar.MINUTE, 0); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= now) next.add(Calendar.DAY_OF_YEAR, 1);
        long trigger = next.getTimeInMillis();
        JSONArray appointments = data.optJSONArray("appointments");
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (appointments != null) for (int i = 0; i < appointments.length(); i++) {
            JSONObject a = appointments.optJSONObject(i);
            if (a == null || prefs.getBoolean("appointment_" + a.optString("id"), false)) continue;
            long when = a.optLong("at", 0) - 3600000L;
            if (a.optLong("at", 0) > now) trigger = Math.min(trigger, Math.max(now + 60000L, when));
        }
        // setAndAllowWhileIdle is inexact and needs no SCHEDULE_EXACT_ALARM.
        manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
    }
    private static boolean allowed(Context context) {
        return Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) { schedule(context); return; }
        JSONObject data = snapshot(context);
        if (!data.optBoolean("enabled", false)) return;
        try {
            if (allowed(context)) notifyDue(context, data);
        } finally { schedule(context); }
    }
    private static void notifyDue(Context context, JSONObject data) {
        long now = System.currentTimeMillis();
        Calendar cal = Calendar.getInstance();
        String today = cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.DAY_OF_YEAR);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor marked = prefs.edit();
        List<String> lines = new ArrayList<>();
        JSONArray plans = data.optJSONArray("plans");
        if (plans != null) for (int i = 0; i < plans.length(); i++) {
            JSONObject p = plans.optJSONObject(i); if (p == null) continue;
            long dueAt = p.optLong("dueAt", 0);
            double remainingKm = p.isNull("dueKm") || p.isNull("mileage") ? Double.POSITIVE_INFINITY : p.optDouble("dueKm", Double.POSITIVE_INFINITY) - p.optDouble("mileage", 0);
            boolean soon = (dueAt > 0 && dueAt - now <= 30L * DAY) || remainingKm <= 1000;
            String key = "plan_" + p.optString("id");
            if (soon && !today.equals(prefs.getString(key, ""))) {
                boolean overdue = (dueAt > 0 && dueAt <= now) || remainingKm <= 0;
                lines.add(p.optString("plate") + " · " + p.optString("title") + (overdue ? " — vencida" : " — próxima"));
                marked.putString(key, today);
            }
        }
        JSONArray appointments = data.optJSONArray("appointments");
        if (appointments != null) for (int i = 0; i < appointments.length(); i++) {
            JSONObject a = appointments.optJSONObject(i); if (a == null) continue;
            String key = "appointment_" + a.optString("id");
            long at = a.optLong("at", 0);
            if (!prefs.getBoolean(key, false) && at > now - 3600000L && at <= now + 3600000L) {
                lines.add(a.optString("plate") + " · agendamento: " + a.optString("title")); marked.putBoolean(key, true);
            }
        }
        if (lines.isEmpty()) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Revisões e agendamentos", NotificationManager.IMPORTANCE_DEFAULT));
        Intent launch = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        launch.putExtra("MOBIWAY_OPEN_VIEW", "reminders");
        PendingIntent open = PendingIntent.getActivity(context, 1102, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.InboxStyle style = new Notification.InboxStyle();
        for (String line : lines) style.addLine(line);
        Notification notification = new Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("MOBIWAY Repair · " + lines.size() + " lembrete(s)")
            .setContentText(lines.get(0)).setStyle(style).setContentIntent(open)
            .setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).build();
        nm.notify(1100, notification); marked.apply();
    }
}
