/* MOBIWAY Repair 0.11 — maintenance domain. No UI, network or Android dependency. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RepairMaintenance = api;
})(typeof globalThis === 'undefined' ? this : globalThis, function () {
  'use strict';
  const COLLECTIONS = {
    repairVehicles: 'mobiwayRepairVehicles',
    maintenanceEntries: 'mobiwayRepairMaintenanceEntries',
    maintenancePlans: 'mobiwayRepairMaintenancePlans',
    appointments: 'mobiwayRepairAppointments'
  };
  const text = v => String(v == null ? '' : v).trim();
  const plateKey = v => text(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const safeId = v => /^[A-Za-z0-9_-]{1,100}$/.test(text(v)) && !['__proto__','constructor','prototype'].includes(text(v));
  const iso = () => new Date().toISOString();
  const copy = v => JSON.parse(JSON.stringify(v));
  function id(prefix = 'R') {
    const bytes = new Uint8Array(16);
    if (!globalThis.crypto || !globalThis.crypto.getRandomValues) throw new Error('Este equipamento não permite gerar identificadores seguros.');
    globalThis.crypto.getRandomValues(bytes);
    return prefix + Array.from(bytes, x => x.toString(16).padStart(2, '0')).join('');
  }
  function number(value, name, optional = false) {
    if (optional && text(value) === '') return null;
    if (text(value) === '') throw new Error('Indica ' + name.toLowerCase() + '.');
    const n = Number(text(value).replace(',', '.'));
    if (!Number.isFinite(n) || n < 0) throw new Error(name + ' deve ser um número igual ou superior a zero.');
    return n;
  }
  function date(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text(value))) return null;
    const d = new Date(value + 'T12:00:00Z');
    return Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === value ? d : null;
  }
  function today(d = new Date()) {
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0')].join('-');
  }
  function addMonths(value, months) {
    const d = date(value);
    if (!d) throw new Error('Data inválida.');
    const day = d.getUTCDate();
    d.setUTCDate(1);
    d.setUTCMonth(d.getUTCMonth() + Number(months));
    const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
    d.setUTCDate(Math.min(day, last));
    return d.toISOString().slice(0, 10);
  }
  function due(plan, vehicle, day = today()) {
    if (plan.state !== 'active') return { status: 'closed', days: null, km: null };
    const days = date(plan.dueDate) && date(day) ? Math.round((date(plan.dueDate) - date(day)) / 86400000) : null;
    const km = plan.dueKm == null || vehicle.mileage == null ? null : plan.dueKm - vehicle.mileage;
    const overdue = (days !== null && days <= 0) || (km !== null && km <= 0);
    const soon = (days !== null && days <= 30) || (km !== null && km <= 1000);
    return { status: overdue ? 'overdue' : soon ? 'soon' : 'ok', days, km };
  }
  function vehicleStatus(vehicle, plans, day) {
    const statuses = plans.filter(p => p.vehicleId === vehicle.id && p.state === 'active').map(p => due(p, vehicle, day).status);
    return statuses.includes('overdue') ? 'overdue' : statuses.includes('soon') ? 'soon' : statuses.length ? 'ok' : 'unplanned';
  }
  function phone(value) {
    const clean = text(value).replace(/[\s().-]/g, '');
    const n = clean.startsWith('00') ? clean.slice(2) : clean.replace(/^\+/, '');
    if (!/^[1-9]\d{7,14}$/.test(n) || (!/^(\+|00)/.test(clean) && n.length < 11)) throw new Error('Indica o telefone com indicativo do país, por exemplo +351912345678.');
    return n;
  }
  function vehicle(input, previous, all = []) {
    const key = plateKey(input.plate);
    if (key.length < 4 || key.length > 12) throw new Error('Indica uma matrícula válida.');
    const duplicate = all.find(v => plateKey(v.plate) === key && v.id !== previous?.id);
    if (duplicate) throw new Error('Esta matrícula já tem uma ficha. Abre a ficha existente.');
    if (!text(input.customerName)) throw new Error('Indica o proprietário/cliente.');
    const mileage = number(input.mileage, 'Quilómetros', true);
    if (mileage !== null && previous?.mileage != null && mileage < previous.mileage) throw new Error('A quilometragem é inferior ao último registo (' + previous.mileage + ' km).');
    const consent = input.whatsappConsent === true;
    if (consent) phone(input.phone);
    const stamp = iso();
    return { ...previous, id: previous?.id || id('V'), plate: text(input.plate).toUpperCase(), plateKey: key,
      make: text(input.make), model: text(input.model), year: text(input.year), vin: text(input.vin).toUpperCase(),
      customerName: text(input.customerName), phone: text(input.phone), email: text(input.email),
      mileage: mileage ?? previous?.mileage ?? null,
      mileageAt: mileage !== null ? stamp : previous?.mileageAt || null,
      whatsappConsent: consent, consentAt: consent ? previous?.consentAt || stamp : null,
      consentSource: consent ? text(input.consentSource) : '',
      portalConsent: input.portalConsent === true, createdAt: previous?.createdAt || stamp, updatedAt: stamp };
  }
  function entry(input, v) {
    if (!v) throw new Error('Escolhe uma viatura.');
    if (!date(input.date) || input.date > today()) throw new Error('A intervenção deve ter uma data válida, até hoje.');
    const mileage = number(input.mileage, 'Quilómetros');
    if (!text(input.title)) throw new Error('Indica o trabalho realizado.');
    const types = ['oil', 'repair', 'inspection', 'tyres', 'other'];
    if (!types.includes(input.type)) throw new Error('Tipo de intervenção inválido.');
    return { id: id('S'), vehicleId: v.id, date: input.date, mileage, type: input.type,
      title: text(input.title), notes: text(input.notes), technician: text(input.technician),
      oil: input.type === 'oil' ? { viscosity: text(input.oilViscosity), specification: text(input.oilSpec), brand: text(input.oilBrand), litres: number(input.oilLitres, 'Litros', true) } : null,
      filters: Array.isArray(input.filters) ? input.filters.filter(x => ['Óleo','Ar','Combustível','Habitáculo'].includes(x)) : [],
      visibleToCustomer: input.visibleToCustomer === true, createdAt: iso(), updatedAt: iso() };
  }
  function plan(input, v) {
    if (!v || !text(input.title)) throw new Error('Indica a viatura e o nome da manutenção.');
    const dueDate = text(input.dueDate), dueKm = number(input.dueKm, 'Quilómetros da próxima manutenção', true);
    if (dueDate && !date(dueDate)) throw new Error('Data da manutenção inválida.');
    if (!dueDate && dueKm === null) throw new Error('Indica uma data ou quilometragem para a manutenção.');
    const intervalKm = number(input.intervalKm, 'Intervalo em quilómetros', true);
    const intervalMonths = number(input.intervalMonths, 'Intervalo em meses', true);
    if (intervalMonths !== null && (!Number.isInteger(intervalMonths) || intervalMonths > 120)) throw new Error('Indica um intervalo entre 1 e 120 meses.');
    return { id: id('P'), vehicleId: v.id, title: text(input.title), type: input.type || 'other', dueDate: dueDate || null, dueKm,
      intervalKm: intervalKm || null, intervalMonths: intervalMonths || null, state: 'active', createdAt: iso(), updatedAt: iso() };
  }
  function nextPlan(p, service) {
    if (!p.intervalKm && !p.intervalMonths) return null;
    return { ...p, id: id('P'), dueKm: p.intervalKm ? service.mileage + p.intervalKm : null,
      dueDate: p.intervalMonths ? addMonths(service.date, p.intervalMonths) : null,
      state: 'active', previousPlanId: p.id, completedBy: null, createdAt: iso(), updatedAt: iso() };
  }
  function appointment(input, v) {
    if (!v || !text(input.title)) throw new Error('Indica a viatura e o serviço a agendar.');
    const start = new Date(input.start);
    if (!Number.isFinite(start.getTime()) || start.getTime() < Date.now() - 60000) throw new Error('Escolhe uma data e hora futuras.');
    const duration = number(input.duration, 'Duração');
    if (duration < 15 || duration > 1440) throw new Error('A duração deve estar entre 15 minutos e 24 horas.');
    return { id: id('A'), vehicleId: v.id, title: text(input.title), start: start.toISOString(), duration,
      technician: text(input.technician), notes: text(input.notes), state: 'confirmed', createdAt: iso(), updatedAt: iso() };
  }
  // Timestamp comparison preserves newer offline changes when old snapshots arrive.
  function merge(local, remote) {
    const map = new Map(local.filter(x => safeId(x.id)).map(x => [x.id, x]));
    for (const r of remote) {
      if (!r || !safeId(r.id)) continue;
      const l = map.get(r.id);
      if (!l || text(r.updatedAt) > text(l.updatedAt)) map.set(r.id, r);
    }
    return Array.from(map.values());
  }
  // Only explicitly visible service fields are allowed to leave the workshop.
  function publicCard(v, entries, plans, shopName) {
    return { schema: 1, shopName: text(shopName) || 'MOBIWAY', updatedAt: iso(),
      vehicle: { plate: text(v.plate), make: text(v.make), model: text(v.model), year: text(v.year), mileage: v.mileage },
      services: entries.filter(s => s.vehicleId === v.id && s.visibleToCustomer).sort((a,b) => b.date.localeCompare(a.date)).map(s => ({ date:s.date, mileage:s.mileage, title:text(s.title), oil:s.oil, filters:s.filters || [] })),
      plans: plans.filter(p => p.vehicleId === v.id && p.state === 'active').map(p => ({ title:text(p.title), dueDate:p.dueDate, dueKm:p.dueKm })) };
  }
  function orderVehicles(existing, orders) {
    const arr = copy(existing);
    const fields = ['make','model','year','vin','customerName','phone','email'];
    for (const o of orders.slice().reverse()) {
      const key = plateKey(o.plate);
      if (key.length < 4 || key.length > 12) continue;
      let v = arr.find(x => x.plateKey === key || plateKey(x.plate) === key);
      if (!v) {
        v = { id:'VO_' + key, plate:text(o.plate).toUpperCase(), plateKey:key, mileage:null, whatsappConsent:false, portalConsent:false, createdAt:iso(), updatedAt:iso() };
        for (const f of fields) v[f] = text(o[f]);
        arr.push(v);
      }
      // A later reception never silently transfers ownership or grants consent.
      for (const f of fields) if (!v[f] && text(o[f])) { v[f] = text(o[f]); v.updatedAt = iso(); }
      const km = Math.max(Number(o.mileage) || 0, Number(o.kmOut) || 0);
      if (km > (v.mileage ?? -1)) { v.mileage = km; v.mileageAt = iso(); v.updatedAt = iso(); }
    }
    return arr;
  }
  function validateBackup(data) {
    if (!data || data.app !== 'MOBIWAY REPAIR' || ![2,3].includes(data.version) || !Array.isArray(data.orders)) throw new Error('Backup incompatível.');
    if (data.orders.some(o => !o || !safeId(o.id))) throw new Error('Ordens inválidas no backup.');
    if(data.settings!=null && (typeof data.settings!=='object'||Array.isArray(data.settings)))throw new Error('Configurações inválidas.');
    if(data.orderConflicts!=null && (!Array.isArray(data.orderConflicts)||data.orderConflicts.some(o=>!o||!safeId(o.id))))throw new Error('Cópias de conflito inválidas.');
    const ids=new Set();for(const o of data.orders){if(ids.has(o.id))throw new Error('Ordens duplicadas no backup.');ids.add(o.id);for(const k of ['photos','lines','supplements','statusHistory','avaliaResults'])if(o[k]!=null&&!Array.isArray(o[k]))throw new Error('Estrutura de ordem inválida.');}
    const result = {};
    for (const c of Object.keys(COLLECTIONS)) {
      const rows = data.maintenance?.[c] || [];
      if (!Array.isArray(rows) || rows.some(x => !x || !safeId(x.id) || (c !== 'repairVehicles' && !safeId(x.vehicleId)))) throw new Error('Dados de manutenção inválidos.');
      result[c] = rows;
    }
    return result;
  }
  return { COLLECTIONS, plateKey, safeId, id, number, date, today, addMonths, due, vehicleStatus, phone, vehicle, entry, plan, nextPlan, appointment, merge, publicCard, orderVehicles, validateBackup };
});
