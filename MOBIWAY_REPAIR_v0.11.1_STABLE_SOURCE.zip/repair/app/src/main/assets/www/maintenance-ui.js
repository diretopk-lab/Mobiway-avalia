/* MOBIWAY Repair 0.11 — workshop maintenance, reminders, appointments and cards. */
(function () {
  'use strict';
  const M = window.RepairMaintenance;
  const D = id => document.getElementById(id);
  const E = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let observedTimestamp=0;
  const stamp = () => {observedTimestamp=Math.max(Date.now(),observedTimestamp+1);return new Date(observedTimestamp).toISOString();};
  const clone = value => JSON.parse(JSON.stringify(value));
  const collections = Object.keys(M.COLLECTIONS);
  const labels = {overdue:'Vencida',soon:'Próxima',ok:'Em dia',unplanned:'Sem plano',closed:'Concluída'};
  const typeNames = {oil:'Óleo e filtros',repair:'Reparação',inspection:'Inspeção',tyres:'Pneus',other:'Outra manutenção'};
  const EMPTY = (title, detail) => '<div class="emptyState"><b>' + E(title) + '</b>' + E(detail) + '</div>';
  let selectedVehicle = null, reminderFilter = 'all', cloudIdentity = '', cardPending = null;
  function cardQueue(){return JSON.parse(localStorage.getItem('mobiwayRepairCardRefreshQueue')||'[]');}
  function saveCardQueue(rows){localStorage.setItem('mobiwayRepairCardRefreshQueue',JSON.stringify([...new Set(rows)]));}
  function read(collection) {
    const raw = localStorage.getItem(M.COLLECTIONS[collection]);
    if (!raw) return [];
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) throw new Error('O registo local está danificado. Importa um backup antes de continuar.');
    value.forEach(x=>{const time=Date.parse(x.updatedAt);if(Number.isFinite(time))observedTimestamp=Math.max(observedTimestamp,time);});
    return value;
  }
  function outbox() { return JSON.parse(localStorage.getItem('mobiwayRepairMaintenanceOutbox') || '{}'); }
  function writable() {
    const c = window.MobiwayCloudClient;
    if (c?.signedIn() && !c.canWrite('maintenanceEntries')) throw new Error('O teu perfil Cloud não permite editar a oficina.');
  }
  function commit(changes, remote = false) {
    if (!remote) writable();
    const old = {}, queue = outbox();
    try {
      for (const [collection, rows] of Object.entries(changes)) {
        if (!collections.includes(collection) || !Array.isArray(rows)) throw new Error('Registo inválido.');
        const key = M.COLLECTIONS[collection]; old[key] = localStorage.getItem(key);
        if (!remote) {
          const prev = new Map(read(collection).map(x => [x.id, JSON.stringify(x)]));
          queue[collection] ||= {};
          rows.forEach(x => { if (prev.get(x.id) !== JSON.stringify(x)) {x.updatedAt=stamp();queue[collection][x.id] = x.updatedAt;} });
        }
        localStorage.setItem(key, JSON.stringify(rows));
      }
      if (!remote) { old.mobiwayRepairMaintenanceOutbox = localStorage.getItem('mobiwayRepairMaintenanceOutbox'); localStorage.setItem('mobiwayRepairMaintenanceOutbox', JSON.stringify(queue)); }
    } catch (error) {
      Object.entries(old).forEach(([key, value]) => { if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value); });
      throw new Error(error.name === 'QuotaExceededError' ? 'O armazenamento está cheio. Exporta um backup antes de continuar.' : error.message);
    }
    render(); syncNativeReminders();
    if (!remote) { flush(); refreshPublishedCards(changes); }
  }
  function upsert(collection, record) {
    const rows = read(collection), index = rows.findIndex(x => x.id === record.id);
    if (index < 0) rows.push(record); else rows[index] = record;
    commit({[collection]:rows});
  }
  function vehicle(id = selectedVehicle) { return read('repairVehicles').find(x => x.id === id); }
  function related(collection, id = selectedVehicle) { return read(collection).filter(x => x.vehicleId === id); }
  const km = value => value == null ? 'Km por registar' : Number(value).toLocaleString('pt-PT') + ' km';
  const day = value => M.date(value) ? new Intl.DateTimeFormat('pt-PT',{timeZone:'UTC'}).format(M.date(value)) : 'Sem data';
  const badge = status => '<span class="maintenanceBadge ' + E(status) + '">' + E(labels[status] || status) + '</span>';
  function targets(plan) { return [plan.dueDate ? day(plan.dueDate) : '', plan.dueKm != null ? km(plan.dueKm) : ''].filter(Boolean).join(' ou '); }
  function dueMessage(plan, v) {
    const d = M.due(plan,v);
    const parts = [];
    if (d.days !== null) parts.push(d.days < 0 ? Math.abs(d.days) + ' dias em atraso' : d.days === 0 ? 'Vence hoje' : 'Dentro de ' + d.days + ' dias');
    if (d.km !== null) parts.push(d.km <= 0 ? km(Math.abs(d.km)) + ' além do limite' : 'Faltam ' + km(d.km));
    return parts.join(' · ');
  }
  function navigate(view) { show(view); if (view === 'home') updateHome(); render(); }
  function openVehicle(id) { if (!vehicle(id)) return; selectedVehicle = id; navigate('vehicleDetail'); }
  function vehicleOptions(id) { return '<option value="">Escolher viatura</option>' + read('repairVehicles').map(v => '<option value="'+E(v.id)+'" '+(v.id === id ? 'selected' : '')+'>'+E(v.plate+' · '+[v.make,v.model].filter(Boolean).join(' '))+'</option>').join(''); }
  function dialog(title, content, onSubmit) {
    D('maintenanceDialogTitle').textContent = title;
    D('maintenanceDialogBody').innerHTML = '<div class="dialogError" id="maintenanceError" role="alert"></div>' + content;
    const form = D('maintenanceDialogBody').querySelector('form');
    if (form && onSubmit) form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      try { writable(); onSubmit(Object.fromEntries(new FormData(form).entries()), form); }
      catch (error) { D('maintenanceError').textContent = error.message; }
    });
    D('maintenanceDialogBody').querySelector('[data-cancel]')?.addEventListener('click', () => D('maintenanceDialog').close());
    if (!D('maintenanceDialog').open) D('maintenanceDialog').showModal();
  }
  const actions = '<div class="dialogActions"><button type="button" class="secondary" data-cancel>Cancelar</button><button type="submit" class="primary">Guardar</button></div>';
  function checkbox(form, name) { return form.elements[name]?.checked === true; }
  function vehicleForm(id) {
    const v = id ? vehicle(id) : {};
    dialog(id ? 'Editar ficha da viatura' : 'Nova viatura', `<form id="maintenanceVehicleForm">
      <div class="grid2"><label>Matrícula<input name="plate" required maxlength="16" autocapitalize="characters" value="${E(v.plate)}"></label><label>Quilómetros atuais<input name="mileage" type="number" min="0" step="1" value="${E(v.mileage)}"></label></div>
      <div class="grid2"><label>Marca<input name="make" maxlength="80" value="${E(v.make)}"></label><label>Modelo<input name="model" maxlength="100" value="${E(v.model)}"></label></div>
      <div class="grid2"><label>Ano<input name="year" type="number" min="1900" max="2100" value="${E(v.year)}"></label><label>VIN<input name="vin" maxlength="30" value="${E(v.vin)}"></label></div>
      <label>Proprietário / cliente<input name="customerName" required maxlength="160" value="${E(v.customerName)}"></label>
      <div class="grid2"><label>Telefone com indicativo<input name="phone" type="tel" value="${E(v.phone)}" placeholder="+351912345678"></label><label>Email<input name="email" type="email" value="${E(v.email)}"></label></div>
      <label class="checkline"><input name="whatsappConsent" type="checkbox" ${v.whatsappConsent?'checked':''}> O cliente autorizou contactos de manutenção por WhatsApp.</label>
      <label>Como foi obtido o consentimento?<input name="consentSource" maxlength="160" value="${E(v.consentSource)}" placeholder="Ex.: autorização presencial registada na receção"></label>
      <label class="checkline"><input name="portalConsent" type="checkbox" ${v.portalConsent?'checked':''}> O cliente autorizou o cartão digital com o histórico selecionado.</label>
      <p class="dialogHelp">Nome, telefone, VIN, notas internas e valores de orçamento ficam na oficina. O cartão contém apenas a viatura, intervenções autorizadas e próximas revisões.</p>${actions}</form>`, (data, form) => {
        const result = M.vehicle({...data, whatsappConsent:checkbox(form,'whatsappConsent'),portalConsent:checkbox(form,'portalConsent')},id?v:null,read('repairVehicles'));
        if (!result.portalConsent && v.portalToken && (v.portalPublished || v.portalPublishPending)) { revokeCard(v,result); return; }
        upsert('repairVehicles',result); D('maintenanceDialog').close(); openVehicle(result.id); toast('Ficha da viatura guardada.');
      });
  }
  function serviceForm(vehicleId, planId) {
    const v = vehicle(vehicleId), p = planId ? read('maintenancePlans').find(x => x.id === planId) : null;
    dialog(p ? 'Concluir manutenção' : 'Registar intervenção', `<form id="maintenanceServiceForm">
      <label>Viatura<select name="vehicleId" required>${vehicleOptions(vehicleId)}</select></label>
      <div class="grid2"><label>Data da intervenção<input name="date" type="date" required max="${M.today()}" value="${M.today()}"></label><label>Quilómetros<input name="mileage" type="number" required min="0" step="1" value="${E(v?.mileage)}"></label></div>
      <label>Tipo de intervenção<select name="type" id="maintenanceServiceType">${Object.entries(typeNames).map(([key,name])=>'<option value="'+key+'" '+(key === (p?.type || 'oil')?'selected':'')+'>'+name+'</option>').join('')}</select></label>
      <label>Trabalho realizado<input name="title" required maxlength="200" value="${E(p?.title || 'Mudança de óleo e filtros')}"></label>
      <div id="maintenanceOilFields"><div class="grid2"><label>Viscosidade<input name="oilViscosity" maxlength="80" placeholder="Ex.: 5W-30"></label><label>Norma / aprovação<input name="oilSpec" maxlength="160" placeholder="Conforme o fabricante"></label></div><div class="grid2"><label>Marca do óleo<input name="oilBrand" maxlength="80"></label><label>Quantidade (litros)<input name="oilLitres" type="number" min="0" step="0.1"></label></div></div>
      <div class="inlineChecks">${['Óleo','Ar','Combustível','Habitáculo'].map(x=>'<label class="checkline"><input type="checkbox" name="filters" value="'+x+'">'+x+'</label>').join('')}</div>
      <label>Técnico<input name="technician" maxlength="160"></label><label>Notas internas<textarea name="notes" rows="3" maxlength="3000"></textarea></label>
      <label class="checkline"><input type="checkbox" name="visibleToCustomer"> Incluir esta intervenção no cartão do cliente.</label>
      ${p?'':`<label class="checkline"><input type="checkbox" name="createPlan" id="createNextPlan"> Programar a próxima manutenção</label><div id="nextPlanIntervals" hidden><div class="grid2"><label>Intervalo em quilómetros<input name="intervalKm" type="number" min="0" value="15000"></label><label>Intervalo em meses<input name="intervalMonths" type="number" min="0" max="120" value="12"></label></div><p class="dialogHelp">Valores iniciais de exemplo. Confirma o intervalo correto para esta viatura, óleo e utilização.</p></div>`}
      ${actions}</form>`, (data, form) => {
        const target = vehicle(data.vehicleId);
        if (p && p.vehicleId !== target?.id) throw new Error('Esta manutenção pertence a outra viatura.');
        const service = M.entry({...data,filters:new FormData(form).getAll('filters'),visibleToCustomer:checkbox(form,'visibleToCustomer')},target);
        const allServices = read('maintenanceEntries'); allServices.push(service);
        const allPlans = read('maintenancePlans');
        if (p) {
          const index = allPlans.findIndex(x=>x.id===p.id);
          if (allPlans[index]?.state !== 'active') throw new Error('Esta manutenção já foi concluída.');
          allPlans[index] = {...p,state:'completed',completedBy:service.id,updatedAt:stamp()};
          const next = M.nextPlan(p,service); if (next) allPlans.push(next);
        } else if (checkbox(form,'createPlan')) {
          const intervalKm = M.number(data.intervalKm,'Intervalo em quilómetros',true), intervalMonths = M.number(data.intervalMonths,'Intervalo em meses',true);
          if (!intervalKm && !intervalMonths) throw new Error('Indica pelo menos um intervalo.');
          allPlans.push(M.plan({title:data.title,type:data.type,intervalKm,intervalMonths,dueKm:intervalKm?service.mileage+intervalKm:null,dueDate:intervalMonths?M.addMonths(service.date,intervalMonths):''},target));
        }
        const allVehicles = read('repairVehicles').map(x=>x.id===target.id?{...x,mileage:Math.max(x.mileage??0,service.mileage),mileageAt:service.mileage>=(x.mileage??0)?stamp():x.mileageAt,updatedAt:stamp()}:x);
        commit({maintenanceEntries:allServices,maintenancePlans:allPlans,repairVehicles:allVehicles}); D('maintenanceDialog').close(); openVehicle(target.id); toast('Intervenção registada.');
      });
    const toggleOil = () => { D('maintenanceOilFields').hidden = D('maintenanceServiceType').value !== 'oil'; };
    D('maintenanceServiceType').addEventListener('change',toggleOil); toggleOil();
    D('createNextPlan')?.addEventListener('change',e=>{D('nextPlanIntervals').hidden=!e.target.checked;});
  }
  function planForm(vehicleId) {
    dialog('Próxima manutenção', `<form id="maintenancePlanForm"><label>Viatura<select name="vehicleId" required>${vehicleOptions(vehicleId)}</select></label>
      <label>Manutenção<input name="title" required maxlength="200" placeholder="Ex.: Revisão / inspeção / distribuição"></label><label>Tipo<select name="type">${Object.entries(typeNames).map(([k,v])=>'<option value="'+k+'">'+v+'</option>').join('')}</select></label>
      <div class="grid2"><label>Data limite<input name="dueDate" type="date"></label><label>Quilómetros limite<input name="dueKm" type="number" min="0" step="1"></label></div>
      <p class="dialogHelp">Podes indicar um ou ambos. Com dois limites, vence no primeiro. Não são calculados prazos legais de inspeção automaticamente.</p>
      <div class="grid2"><label>Repetir após (km)<input name="intervalKm" type="number" min="0" step="1"></label><label>Repetir após (meses)<input name="intervalMonths" type="number" min="0" max="120" step="1"></label></div>${actions}</form>`,data=>{
        const p=M.plan(data,vehicle(data.vehicleId));upsert('maintenancePlans',p);D('maintenanceDialog').close();toast('Lembrete de manutenção criado.');
      });
  }
  function appointmentForm(vehicleId) {
    const tomorrow = new Date(Date.now()+86400000); tomorrow.setHours(9,0,0,0);
    const initial = M.today(tomorrow)+'T09:00';
    dialog('Agendar intervenção',`<form id="maintenanceAppointmentForm"><label>Viatura<select name="vehicleId" required>${vehicleOptions(vehicleId)}</select></label>
      <label>Serviço<input name="title" required maxlength="200" placeholder="Ex.: Revisão de óleo e filtros"></label><div class="grid2"><label>Data e hora<input name="start" type="datetime-local" required value="${initial}"></label><label>Duração (minutos)<input name="duration" type="number" required min="15" max="1440" step="15" value="60"></label></div>
      <label>Técnico<input name="technician" maxlength="160"></label><label>Notas internas<textarea name="notes" maxlength="3000" rows="3"></textarea></label><p class="dialogHelp">A hora corresponde à hora local do equipamento.</p>${actions}</form>`,data=>{
        const a=M.appointment(data,vehicle(data.vehicleId));
        const end=new Date(a.start).getTime()+a.duration*60000;
        const overlap=read('appointments').some(x=>x.state==='confirmed' && ((a.technician && x.technician===a.technician)||x.vehicleId===a.vehicleId) && new Date(x.start).getTime()<end && new Date(x.start).getTime()+x.duration*60000>new Date(a.start).getTime());
        if (overlap) throw new Error('Já existe um agendamento neste horário para esta viatura ou técnico.');
        upsert('appointments',a);D('maintenanceDialog').close();navigate('appointments');toast('Intervenção agendada.');
      });
  }
  function newReception(id) {
    const v=vehicle(id);if(!v)return;resetForm();
    for(const key of ['customerName','phone','email','plate','make','model','year','vin','mileage']){const el=document.querySelector('#repairForm [name="'+key+'"]');if(el)el.value=v[key]??'';}
    updateReceptionContext();show('reception');
  }
  function setState(collection,id,value) {
    const record=read(collection).find(x=>x.id===id);if(!record)return;
    upsert(collection,{...record,state:value,updatedAt:stamp()});toast('Registo atualizado.');
  }
  function sendReminder(planId) {
    const p=read('maintenancePlans').find(x=>x.id===planId),v=p?vehicle(p.vehicleId):null;
    if(!v)return;
    if(!v.whatsappConsent){toast('Regista primeiro a autorização do cliente na ficha.');return;}
    try{
      const recipient=M.phone(v.phone);
      const message='Olá '+v.customerName+'. A '+loadSettings().shopName+' recorda a manutenção da viatura '+v.plate+': '+p.title+'. Próximo limite: '+targets(p)+'. Podemos ajudar a agendar?';
      const url='https://wa.me/'+recipient+'?text='+encodeURIComponent(message);
      if(window.AndroidBridge?.openExternal)AndroidBridge.openExternal(url);else window.open(url,'_blank','noopener,noreferrer');
      const rows=read('maintenancePlans').map(x=>x.id===p.id?{...x,lastDraftAt:stamp(),updatedAt:stamp()}:x);commit({maintenancePlans:rows});
      toast('Mensagem preparada. Confirma o envio no WhatsApp.');
    }catch(error){toast(error.message);}
  }
  function renderDashboard() {
    const vs=read('repairVehicles'),ps=read('maintenancePlans'),counts={overdue:0,soon:0,ok:0,unplanned:0};
    vs.forEach(v=>counts[M.vehicleStatus(v,ps)]++);
    D('reminderCount').textContent=ps.filter(p=>p.state==='active' && ['overdue','soon'].includes(M.due(p,vehicle(p.vehicleId)||{}).status)).length;
    D('maintenanceDashboard').innerHTML='<div class="sectionTitle"><div><p class="eyebrow">ACOMPANHAMENTO DA VIATURA</p><h2>Depois da entrega, continuamos perto.</h2></div></div><div class="maintenanceStats">'+
      [['vehicles',vs.length,'Viaturas registadas',''],['reminders',counts.ok,'Em dia','ok'],['reminders',counts.soon,'Próximas revisões','soon'],['reminders',counts.overdue,'Revisões vencidas','overdue']].map(([view,count,label,tone])=>'<button type="button" data-action="dashboard" data-view="'+view+'" data-tone="'+tone+'"><b>'+count+'</b><span>'+label+'</span></button>').join('')+'</div>';
  }
  function renderVehicles() {
    const query=D('vehicleSearch').value.toLocaleLowerCase('pt-PT'),ps=read('maintenancePlans');
    const vs=read('repairVehicles').filter(v=>[v.plate,v.make,v.model,v.customerName].join(' ').toLocaleLowerCase('pt-PT').includes(query));
    D('vehiclesList').innerHTML=vs.length?vs.map(v=>`<button type="button" class="vehicleCard" data-action="open-vehicle" data-id="${E(v.id)}"><span class="plateTag">${E(v.plate)}</span><h3>${E([v.make,v.model,v.year].filter(Boolean).join(' ')||'Viatura')}</h3><p>${E(v.customerName||'Cliente por identificar')}</p><div class="vehicleMeta"><span>${E(km(v.mileage))}</span>${badge(M.vehicleStatus(v,ps))}</div></button>`).join(''):EMPTY('Ainda sem viaturas','Adiciona uma ficha ou cria uma receção. As ordens existentes são recuperadas automaticamente.');
  }
  function planRow(p) {
    const v=vehicle(p.vehicleId);if(!v)return '';
    const status=M.due(p,v).status;
    return `<article class="maintenanceRow"><div class="rowHeading"><div><h3>${E(p.title)}</h3><p>${E(v.plate+' · '+v.make+' '+v.model)}</p></div>${badge(status)}</div><p><b>${E(targets(p))}</b></p><p>${E(dueMessage(p,v))}</p>${p.lastDraftAt?'<p class="muted small">Última mensagem preparada: '+E(new Date(p.lastDraftAt).toLocaleString('pt-PT'))+' · envio não confirmado pela app</p>':''}<div class="rowActions"><button class="primary" type="button" data-action="complete-plan" data-id="${E(p.id)}">Registar intervenção</button><button class="secondary" type="button" data-action="whatsapp" data-id="${E(p.id)}" ${v.whatsappConsent?'':'disabled'}>Preparar WhatsApp</button><button class="secondary" type="button" data-action="open-vehicle" data-id="${E(v.id)}">Ficha</button><button class="linkbtn" type="button" data-action="cancel-plan" data-id="${E(p.id)}">Cancelar lembrete</button></div></article>`;
  }
  function renderReminders() {
    const priority={overdue:0,soon:1,ok:2};
    const ps=read('maintenancePlans').filter(p=>p.state==='active'&&vehicle(p.vehicleId)).filter(p=>reminderFilter==='all'||M.due(p,vehicle(p.vehicleId)).status===reminderFilter).sort((a,b)=>priority[M.due(a,vehicle(a.vehicleId)).status]-priority[M.due(b,vehicle(b.vehicleId)).status]||String(a.dueDate||'9999').localeCompare(String(b.dueDate||'9999')));
    D('remindersList').innerHTML=ps.length?ps.map(planRow).join(''):EMPTY('Sem lembretes nesta seleção','Cria uma próxima revisão por data, quilómetros ou ambos.');
    D('reminderFilters').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filter===reminderFilter)));
  }
  function renderAppointments() {
    const arr=read('appointments').slice().sort((a,b)=>a.start.localeCompare(b.start));
    D('appointmentsList').innerHTML=arr.length?arr.map(a=>{const v=vehicle(a.vehicleId);return `<article class="maintenanceRow"><div class="rowHeading"><div><span class="historyDate">${E(new Date(a.start).toLocaleString('pt-PT',{dateStyle:'medium',timeStyle:'short'}))} · ${a.duration} min</span><h3>${E(a.title)}</h3><p>${E(v?.plate||'Viatura')} · ${E(v?.customerName||'')}</p></div><span class="maintenanceBadge">${E({confirmed:'Confirmado',completed:'Concluído',cancelled:'Cancelado'}[a.state])}</span></div>${a.technician?'<p>Técnico: '+E(a.technician)+'</p>':''}${a.notes?'<p>'+E(a.notes)+'</p>':''}${a.state==='confirmed'?`<div class="rowActions"><button class="primary" data-action="appointment-reception" data-id="${E(a.id)}" type="button">Abrir receção</button><button class="secondary" data-action="appointment-done" data-id="${E(a.id)}" type="button">Concluir agendamento</button><button class="linkbtn" data-action="appointment-cancel" data-id="${E(a.id)}" type="button">Cancelar</button></div>`:''}</article>`;}).join(''):EMPTY('A agenda está livre','Marca a próxima intervenção e associa a viatura e o técnico.');
  }
  function renderVehicle() {
    const v=vehicle();if(!v)return;
    const services=related('maintenanceEntries').sort((a,b)=>b.date.localeCompare(a.date));
    const ps=related('maintenancePlans').filter(p=>p.state==='active');
    const os=orders().filter(o=>M.plateKey(o.plate)===v.plateKey);
    D('vehicleDetailBody').innerHTML=`<button class="linkbtn" type="button" data-action="back-vehicles">← Todas as viaturas</button><div class="vehicleHero"><span class="plateTag">${E(v.plate)}</span><h2>${E([v.make,v.model,v.year].filter(Boolean).join(' ')||'Ficha da viatura')}</h2><p>${E(v.customerName||'Cliente')} · ${E(v.phone||'Telefone por registar')}</p><div class="vehicleMeta"><span>${E(km(v.mileage))}</span>${badge(M.vehicleStatus(v,read('maintenancePlans')))}<button class="linkbtn" type="button" data-action="edit-vehicle" data-id="${E(v.id)}">Editar ficha</button></div><p class="muted small">Quilometragem registada ${v.mileageAt?E(new Date(v.mileageAt).toLocaleDateString('pt-PT')):'sem data'}. WhatsApp: ${v.whatsappConsent?'autorizado':'sem autorização'}.</p></div>
      <div class="maintenanceActions"><button class="primary" type="button" data-action="service" data-id="${E(v.id)}">+ Intervenção</button><button class="secondary" type="button" data-action="plan" data-id="${E(v.id)}">+ Manutenção</button><button class="secondary" type="button" data-action="appointment" data-id="${E(v.id)}">Agendar</button><button class="secondary" type="button" data-action="card" data-id="${E(v.id)}">Cartão e QR</button><button class="secondary" type="button" data-action="reception" data-id="${E(v.id)}">Nova receção</button></div>
      <div class="sectionTitle"><h3>Próximas manutenções</h3></div><div class="maintenanceList">${ps.length?ps.map(planRow).join(''):EMPTY('Sem manutenção programada','Define os próximos limites de tempo ou quilómetros.')}</div>
      <div class="sectionTitle"><h3>Histórico de intervenções</h3></div><div class="maintenanceList">${services.length?services.map(s=>`<article class="maintenanceRow"><span class="historyDate">${E(day(s.date))} · ${E(km(s.mileage))}</span><h3>${E(s.title)}</h3>${s.oil?'<p>Óleo: '+E([s.oil.brand,s.oil.viscosity,s.oil.specification,s.oil.litres==null?'':s.oil.litres+' L'].filter(Boolean).join(' · '))+'</p>':''}${s.filters?.length?'<p>Filtros: '+E(s.filters.join(', '))+'</p>':''}${s.notes?'<p>'+E(s.notes)+'</p>':''}${s.technician?'<p class="muted small">Técnico: '+E(s.technician)+'</p>':''}<div class="rowActions"><button class="secondary" type="button" data-action="entry-visibility" data-id="${E(s.id)}">${s.visibleToCustomer?'Retirar do cartão':'Autorizar no cartão'}</button>${s.orderId?'<button class="linkbtn" type="button" data-action="open-order" data-id="'+E(s.orderId)+'">Ordem original</button>':''}</div></article>`).join(''):EMPTY('Sem intervenções registadas','As ordens entregues são associadas automaticamente. Regista também serviços anteriores.')}</div>
      <div class="sectionTitle"><h3>Ordens de reparação · ${os.length}</h3></div><div class="maintenanceList">${os.map(o=>`<article class="maintenanceRow"><h3>${E(o.orderNo)} · ${E(o.status)}</h3><p>${E(o.customerRequest||'')}</p><button class="linkbtn" type="button" data-action="open-order" data-id="${E(o.id)}">Abrir ordem</button></article>`).join('')||EMPTY('Sem ordens','Usa Nova receção para iniciar uma ordem para esta viatura.')}</div>`;
  }
  function render() {
    renderDashboard(); renderVehicles(); renderReminders(); renderAppointments();
    if(D('vehicleDetail').classList.contains('active'))renderVehicle();
    const active=document.querySelector('.view.active')?.id;
    document.querySelectorAll('[data-maint-view]').forEach(b=>{if(b.dataset.maintView===active || (active==='vehicleDetail'&&b.dataset.maintView==='vehicles'))b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  }
  function qrSvg(value) {
    const qr=window.qrcodegen.QrCode.encodeText(value,window.qrcodegen.QrCode.Ecc.MEDIUM),border=4,size=qr.size+border*2;
    const path=[];for(let y=0;y<qr.size;y++)for(let x=0;x<qr.size;x++)if(qr.getModule(x,y))path.push('M'+(x+border)+','+(y+border)+'h1v1h-1z');
    return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Código QR do cartão da viatura" viewBox="0 0 '+size+' '+size+'"><rect width="100%" height="100%" fill="white"/><path d="'+path.join(' ')+'" fill="#111"/></svg>';
  }
  function snapshot(v) { return M.publicCard(v,read('maintenanceEntries'),read('maintenancePlans'),loadSettings().shopName); }
  function portalUrl(v) {
    const base=String(loadSettings().portalUrl||'').trim();
    const expiry=Date.parse(v.portalExpiresAt);
    if(!base || !v.portalToken || !v.portalPublished || !v.portalConsent || !Number.isFinite(expiry) || expiry<=Date.now())return '';
    try{const u=new URL(base);if(u.protocol!=='https:' || u.username || u.password)return '';u.hash=v.portalToken;return u.href;}catch{return '';}
  }
  function cardText(card) {
    return [card.shopName+' · Cartão de manutenção',card.vehicle.plate+' · '+[card.vehicle.make,card.vehicle.model,card.vehicle.year].filter(Boolean).join(' '),km(card.vehicle.mileage),
      ...card.services.slice(0,3).map(s=>day(s.date)+' · '+s.title.slice(0,140)+' · '+km(s.mileage)),
      ...card.plans.slice(0,3).map(p=>'Próxima: '+p.title.slice(0,100)+' · '+targets(p))].join('\n').slice(0,1200);
  }
  function cardMarkup(card,url) {
    return `<div class="cardPreview"><div class="cardBrand">${E(card.shopName)} · REPAIR</div><h3>O cuidado continua.</h3><p>Histórico de manutenção da sua viatura</p><span class="plateTag">${E(card.vehicle.plate)}</span><p>${E([card.vehicle.make,card.vehicle.model,card.vehicle.year].filter(Boolean).join(' '))}<br>${E(km(card.vehicle.mileage))} · último registo</p>
      <div class="cardQr">${qrSvg(url||cardText(card))}</div><p>${url?'Leia o QR para consultar o histórico autorizado atualizado.':'O QR contém um resumo desta viatura. Este cartão é uma cópia dos registos na data de emissão.'}</p>
      <h4>Próximas manutenções</h4>${card.plans.length?'<ul>'+card.plans.map(p=>'<li><b>'+E(p.title)+'</b><br>'+E(targets(p))+'</li>').join('')+'</ul>':'<p>Sem manutenção programada.</p>'}
      <h4>Intervenções autorizadas</h4>${card.services.length?card.services.map(s=>'<div class="recordItem"><small>'+E(day(s.date))+' · '+E(km(s.mileage))+'</small><b>'+E(s.title)+'</b>'+ (s.oil?'<p>Óleo: '+E([s.oil.brand,s.oil.viscosity,s.oil.specification,s.oil.litres==null?'':s.oil.litres+' L'].filter(Boolean).join(' · '))+'</p>':'')+(s.filters?.length?'<small>Filtros: '+E(s.filters.join(', '))+'</small>':'')+'</div>').join(''):'<p>A oficina ainda não autorizou intervenções para este cartão.</p>'}
      <p class="cardNote">Emitido em ${E(new Date(card.updatedAt).toLocaleString('pt-PT'))}. Os limites de manutenção são definidos pela oficina para esta viatura.</p></div>`;
  }
  function cardHtml(v) {
    const body=cardMarkup(snapshot(v),portalUrl(v));
    return '<!doctype html><html lang="pt"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(v.plate)+' · MOBIWAY Repair</title><style>body{margin:0;padding:22px;background:#eef1f5;font-family:system-ui;color:#1d2632}.cardPreview{max-width:680px;background:white;margin:auto;padding:28px;border-radius:20px}.cardBrand{color:#955207;font-size:14px;font-weight:800}.plateTag{display:inline-block;background:#eef0f4;padding:8px 14px;border-left:5px solid #225ba7;border-radius:6px;font-weight:800}.cardQr{text-align:center;margin:20px}svg{width:190px;background:white}h3{font-size:28px;margin-bottom:5px}p{color:#596578;font-size:13px;line-height:1.7}.recordItem{border-top:1px solid #d7dce4;padding:14px 0}.recordItem b{display:block}small{color:#596578}.cardNote{font-size:11px;border-top:1px solid #ddd;padding-top:15px}li{margin:12px 0;font-size:14px}@media print{body{background:white;padding:0}.cardPreview{padding:0}.recordItem{break-inside:avoid}}</style>'+body+'</html>';
  }
  function download(name,content,mime) {
    const blob=new Blob([content],{type:mime}),url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  function openCard(id) {
    const v=vehicle(id);if(!v)return;
    if(!v.portalConsent){toast('Regista a autorização para o cartão digital na ficha.');vehicleForm(id);return;}
    const url=portalUrl(v);
    dialog('Cartão digital · '+v.plate,cardMarkup(snapshot(v),url)+(url?'<p class="cardLink">'+E(url)+'</p>':'')+
      `<div class="dialogActions"><button type="button" class="secondary" id="exportCustomerCard">Exportar cartão</button><button type="button" class="secondary" id="printCustomerCard">PDF / A4</button></div>
      <div class="dialogActions"><button type="button" class="primary" id="publishCustomerCard">${v.portalPublishPending?'Publicação pendente — tentar novamente':v.portalPublished?'Atualizar portal':'Publicar no portal'}</button>${v.portalToken?'<button type="button" class="secondary" id="revokeCustomerCard">Revogar ligação</button>':''}</div>
      <p class="dialogHelp">A exportação cria uma cópia. A ligação online tem validade de 90 dias e pode ser revogada. Qualquer pessoa com a ligação ou o QR pode consultar os dados autorizados.</p>`);
    D('exportCustomerCard').onclick=()=>{const html=cardHtml(v),name='MOBIWAY-Repair-'+M.plateKey(v.plate)+'.html';if(window.AndroidBridge?.shareDocument)AndroidBridge.shareDocument(name,html,'text/html');else download(name,html,'text/html');};
    D('printCustomerCard').onclick=()=>{D('maintenancePrintArea').innerHTML=cardMarkup(snapshot(v),url);document.body.classList.add('printingCard');if(window.AndroidBridge?.printA4)AndroidBridge.printA4();else window.print();};
    D('publishCustomerCard').onclick=()=>publishCard(v,true);
    D('revokeCustomerCard')?.addEventListener('click',()=>{try{revokeCard(v);}catch(error){D('maintenanceError').textContent=error.message;}});
  }
  function publishCard(v,interactive=false) {
    if(!v.portalConsent || !window.MobiwayCloudClient?.ready() || !window.MobiwayCloud?.publishCustomerCard){if(interactive)D('maintenanceError').textContent='Liga a MOBIWAY Cloud na app Android para publicar o cartão.';return;}
    const base=loadSettings().portalUrl;
    try{const u=new URL(base);if(u.protocol!=='https:' || u.username || u.password)throw new Error();}catch{if(interactive)D('maintenanceError').textContent='Configura nas definições o endereço HTTPS do portal publicado.';return;}
    if(cardPending){if(interactive)toast('Aguarda a publicação em curso.');return;}
    const token=v.portalToken||M.id(''),expires=interactive?Date.now()+90*86400000:Date.parse(v.portalExpiresAt)||Date.now()+90*86400000;
    if(expires<=Date.now())return;
    const card=snapshot(v);
    cardPending={vehicleId:v.id,token,expires,interactive,action:'publish',signature:cardSignature(card)};
    // Retain the token before a network write so a restart cannot orphan a link.
    saveCardQueue([...cardQueue(),v.id]);
    upsert('repairVehicles',{...v,portalToken:token,portalPublishPending:true,portalExpiresAt:new Date(expires).toISOString(),updatedAt:stamp()});
    window.MobiwayCloud.publishCustomerCard(token,JSON.stringify(card),expires);
  }
  function revokeCard(v,vehicleChange=null) {
    if(!v.portalToken || !window.MobiwayCloudClient?.ready() || !window.MobiwayCloud?.revokeCustomerCard)throw new Error('Liga a Cloud para revogar a ligação já publicada.');
    if(cardPending)throw new Error('Aguarda a publicação em curso.');
    cardPending={vehicleId:v.id,token:v.portalToken,action:'revoke',interactive:true,vehicleChange};
    window.MobiwayCloud.revokeCustomerCard(v.portalToken);
  }
  window.receiveRepairCardPublish=raw=>{
    const result=typeof raw==='string'?JSON.parse(raw):raw, pending=cardPending;
    if(!pending || result.token!==pending.token)return;
    cardPending=null;
    if(!result.ok){const error=result.error||'Não foi possível publicar. Tenta novamente com ligação à internet.';if(pending.interactive && D('maintenanceDialog').open)D('maintenanceError').textContent=error;else toast(error);return;}
    const v=vehicle(pending.vehicleId);if(!v)return;
    upsert('repairVehicles',{...(pending.vehicleChange||v),portalToken:pending.token,portalPublished:pending.action==='publish',portalPublishPending:false,portalExpiresAt:pending.action==='publish'?new Date(pending.expires).toISOString():null,portalSnapshotSignature:pending.signature||null,updatedAt:stamp()});
    if(pending.action==='revoke'||pending.signature===cardSignature(snapshot(vehicle(v.id))))saveCardQueue(cardQueue().filter(id=>id!==v.id));
    if(pending.vehicleChange){D('maintenanceDialog').close();openVehicle(v.id);toast('Autorização retirada e ligação revogada.');}
    else if(pending.interactive){toast(pending.action==='publish'?'Cartão publicado. A ligação fica pronta para partilhar.':'Ligação do cartão revogada.');if(D('maintenanceDialog').open && D('publishCustomerCard'))openCard(v.id);}
    processCardQueue();
  };
  function cardSignature(card){return JSON.stringify({shopName:card.shopName,vehicle:card.vehicle,services:card.services,plans:card.plans});}
  function processCardQueue(){if(cardPending)return;for(const id of cardQueue()){const v=vehicle(id);if((!v?.portalPublished&&!v?.portalPublishPending)||!v.portalConsent||Date.parse(v.portalExpiresAt)<=Date.now()||(!v.portalPublishPending&&v.portalSnapshotSignature===cardSignature(snapshot(v)))){saveCardQueue(cardQueue().filter(x=>x!==id));continue;}publishCard(v);if(cardPending)return;}}
  function refreshPublishedCards(changes) {
    // Public snapshots are refreshed after changes to authorised history and plans.
    if(!changes.maintenanceEntries && !changes.maintenancePlans && !changes.repairVehicles)return;
    const affected=new Set([...(changes.maintenanceEntries||[]),...(changes.maintenancePlans||[])].map(x=>x.vehicleId));
    (changes.repairVehicles||[]).forEach(v=>affected.add(v.id));
    const queue=cardQueue();
    for(const id of affected){const v=vehicle(id);if((v?.portalPublished||v?.portalPublishPending) && v.portalConsent && (v.portalPublishPending||v.portalSnapshotSignature!==cardSignature(snapshot(v))))queue.push(id);}
    saveCardQueue(queue);processCardQueue();
  }
  function flush() {
    const cloud=window.MobiwayCloudClient;if(!cloud?.ready())return;
    const q=outbox();
    for(const collection of collections){if(!cloud.canWrite(collection))continue;const pending=q[collection]||{};for(const record of read(collection))if(pending[record.id])cloud.upsert(collection,record);}
    processCardQueue();
  }
  function connectCloud() {
    const cloud=window.MobiwayCloudClient;if(!cloud?.ready()){cloudIdentity='';return;}
    const s=cloud.status(),identity=s.companyId+'|'+s.email;
    if(identity!==cloudIdentity){cloudIdentity=identity;collections.forEach(collection=>cloud.listen(collection));}
    flush();
  }
  document.addEventListener('mobiway-cloud-collection',event=>{
    const {collection,records,fromCache,hasPendingWrites}=event.detail||{};if(!collections.includes(collection)||!Array.isArray(records))return;
    const local=read(collection),merged=M.merge(local,records);commit({[collection]:merged},true);
    if(!fromCache&&!hasPendingWrites){
      const q=outbox();q[collection]||={};
      for(const record of records){const own=local.find(x=>x.id===record.id);if(own && String(record.updatedAt)>=String(own.updatedAt))delete q[collection][record.id];}
      localStorage.setItem('mobiwayRepairMaintenanceOutbox',JSON.stringify(q));
    }
  });
  function syncNativeReminders() {
    if(!window.AndroidBridge?.setMaintenanceReminders)return;
    const plans=read('maintenancePlans').filter(p=>p.state==='active').map(p=>{const v=vehicle(p.vehicleId)||{};return {id:p.id,title:p.title,plate:v.plate||'',dueAt:p.dueDate?new Date(p.dueDate+'T09:00:00').getTime():0,dueKm:p.dueKm,mileage:v.mileage};});
    const appointments=read('appointments').filter(a=>a.state==='confirmed').map(a=>({id:a.id,title:a.title,plate:vehicle(a.vehicleId)?.plate||'',at:new Date(a.start).getTime()}));
    AndroidBridge.setMaintenanceReminders(JSON.stringify({enabled:loadSettings().backgroundReminders===true,plans,appointments}));
  }
  function legacyDay(value) {const m=String(value||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);return m?m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0'):String(value||'').slice(0,10);}
  function recoverOrders() {
    const vs=M.orderVehicles(read('repairVehicles'),orders()),ss=read('maintenanceEntries');
    for(const o of orders()){
      if(o.status!=='Entregue' || ss.some(s=>s.orderId===o.id))continue;
      const v=vs.find(x=>x.plateKey===M.plateKey(o.plate)),date=legacyDay(o.deliveredAtIso||o.deliveredAt||o.createdAt);
      if(!v || !M.date(date))continue;
      ss.push({id:'SO_'+o.id,vehicleId:v.id,orderId:o.id,date,mileage:Math.max(Number(o.mileage)||0,Number(o.kmOut)||0),type:'repair',title:'Reparação · '+o.orderNo,notes:o.finalNotes||o.customerRequest||'',technician:o.technician||'',oil:null,filters:[],visibleToCustomer:false,createdAt:stamp(),updatedAt:stamp()});
    }
    const changes={};if(JSON.stringify(vs)!==JSON.stringify(read('repairVehicles')))changes.repairVehicles=vs;if(JSON.stringify(ss)!==JSON.stringify(read('maintenanceEntries')))changes.maintenanceEntries=ss;
    if(Object.keys(changes).length){try{commit(changes);}catch(error){toast(error.message);}}
  }
  function exportState(){return Object.fromEntries(collections.map(c=>[c,read(c)]));}
  function prepareImport(data){
    writable();const validated=M.validateBackup(data),changes={},queue=outbox();
    for(const c of collections){
      // Keep existing records, including their card publication and consent state.
      const rows=read(c),ids=new Set(rows.map(x=>x.id));queue[c]||={};
      for(const record of validated[c])if(!ids.has(record.id)){rows.push(record);ids.add(record.id);queue[c][record.id]=record.updatedAt||'legacy';}
      changes[M.COLLECTIONS[c]]=rows;
    }
    changes.mobiwayRepairMaintenanceOutbox=queue;return changes;
  }
  function afterImport(){render();syncNativeReminders();try{flush();}catch{toast('Dados guardados. Sincronização pendente.');}}
  function importState(data){writeRepairStorage(prepareImport(data));afterImport();}
  document.addEventListener('click',event=>{
    const nav=event.target.closest('[data-maint-view]');if(nav){navigate(nav.dataset.maintView);return;}
    const b=event.target.closest('[data-action]');if(!b)return;const id=b.dataset.id;
    try{
      switch(b.dataset.action){
        case 'open-vehicle':openVehicle(id);break;
        case 'back-vehicles':navigate('vehicles');break;
        case 'edit-vehicle':vehicleForm(id);break;
        case 'service':serviceForm(id);break;
        case 'plan':planForm(id);break;
        case 'appointment':appointmentForm(id);break;
        case 'card':openCard(id);break;
        case 'reception':newReception(id);break;
        case 'open-order':window.openOrder(id);break;
        case 'complete-plan':{const p=read('maintenancePlans').find(x=>x.id===id);if(p)serviceForm(p.vehicleId,p.id);break;}
        case 'cancel-plan':if(confirm('Cancelar este lembrete? O histórico será mantido.'))setState('maintenancePlans',id,'cancelled');break;
        case 'whatsapp':sendReminder(id);break;
        case 'entry-visibility':{const s=read('maintenanceEntries').find(x=>x.id===id);if(s)upsert('maintenanceEntries',{...s,visibleToCustomer:!s.visibleToCustomer,updatedAt:stamp()});break;}
        case 'appointment-reception':{const a=read('appointments').find(x=>x.id===id);if(a)newReception(a.vehicleId);break;}
        case 'appointment-done':setState('appointments',id,'completed');break;
        case 'appointment-cancel':if(confirm('Cancelar o agendamento?'))setState('appointments',id,'cancelled');break;
        case 'dashboard':reminderFilter=['soon','overdue'].includes(b.dataset.tone)?b.dataset.tone:'all';navigate(b.dataset.view);break;
      }
    }catch(error){toast(error.message);}
  });
  D('vehicleSearch').addEventListener('input',renderVehicles);
  D('addVehicleBtn').onclick=()=>vehicleForm();D('addPlanBtn').onclick=()=>planForm();D('addAppointmentBtn').onclick=()=>appointmentForm();
  D('reminderFilters').addEventListener('click',event=>{const b=event.target.closest('[data-filter]');if(b){reminderFilter=b.dataset.filter;renderReminders();}});
  D('closeMaintenanceDialog').onclick=()=>D('maintenanceDialog').close();
  D('enableReminderNotifications').onclick=()=>{if(window.AndroidBridge?.requestReminderPermission)AndroidBridge.requestReminderPermission();else toast('As notificações de fundo estão disponíveis na app Android.');};
  document.addEventListener('repair-orders-changed',recoverOrders);
  document.addEventListener('repair-view-changed',render);
  document.addEventListener('repair-settings-changed',()=>{render();syncNativeReminders();});
  document.addEventListener('mobiway-cloud-status',connectCloud);
  window.addEventListener('online',flush);
  window.addEventListener('afterprint',()=>document.body.classList.remove('printingCard'));
  D('maintenanceDialog').addEventListener('close',()=>document.body.classList.remove('printingCard'));
  window.MobiwayRepairMaintenance = {read,commit,openVehicle,serviceForm,render,exportState,importState,prepareImport,afterImport,syncNativeReminders,download,snapshot,cardHtml};
  try{recoverOrders();render();syncNativeReminders();connectCloud();}catch(error){toast(error.message);console.error('Repair maintenance startup',error);}
})();
