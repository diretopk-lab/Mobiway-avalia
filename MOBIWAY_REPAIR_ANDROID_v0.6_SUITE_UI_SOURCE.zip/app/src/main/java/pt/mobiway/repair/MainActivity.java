package pt.mobiway.repair;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri cameraUri;
    private static final int FILE_CHOOSER = 1001;
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                Intent camera = buildCameraIntent();
                if (params != null && params.isCaptureEnabled() && camera != null) {
                    startActivityForResult(camera, FILE_CHOOSER);
                    return true;
                }

                Intent chooser = Intent.createChooser(gallery, "Fotografias da viatura");
                if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                startActivityForResult(chooser, FILE_CHOOSER);
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Intent buildCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) return null;
        try {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MobiwayRepair");
            if (!dir.exists()) dir.mkdirs();
            File image = File.createTempFile("repair_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", image);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return camera;
        } catch (IOException e) {
            cameraUri = null;
            return null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER || uploadCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                results = new Uri[n];
                for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                results = new Uri[]{cameraUri};
            }
        }
        uploadCallback.onReceiveValue(results);
        uploadCallback = null;
        cameraUri = null;
    }

    public class Bridge {
        @JavascriptInterface public void printA4() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("MOBIWAY REPAIR - Folha de Obra");
                PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
                pm.print("MOBIWAY REPAIR - A4", adapter, attrs);
            });
        }

        @JavascriptInterface public boolean openAvalia(String vehicleJson) {
            final String payload = vehicleJson == null ? "{}" : vehicleJson;
            try {
                // Explicit launch avoids Android 11+ package-visibility false negatives.
                Intent launch = new Intent();
                launch.setClassName("pt.mobiway.avalia", "pt.mobiway.avalia.MainActivity");
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                launch.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                launch.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                startActivity(launch);
                return true;
            } catch (Exception first) {
                try {
                    Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.avalia");
                    if (fallback == null) return false;
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    fallback.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                    fallback.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                    startActivity(fallback);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        }

        @JavascriptInterface public boolean isAvaliaInstalled() {
            try {
                getPackageManager().getPackageInfo("pt.mobiway.avalia", 0);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface public String getAvaliaResultPayload() {
            Intent intent = getIntent();
            if (intent == null) return "";
            String payload = intent.getStringExtra(EXTRA_AVALIA_RESULT);
            return payload == null ? "" : payload;
        }

        @JavascriptInterface public void clearAvaliaResultPayload() {
            Intent intent = getIntent();
            if (intent != null) intent.removeExtra(EXTRA_AVALIA_RESULT);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) webView.post(() -> webView.reload());
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
