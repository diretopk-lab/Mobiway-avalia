import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {parseHTML} from './vendor/linkedom.mjs';
const require=createRequire(import.meta.url);
const M=require('../app/src/main/assets/www/maintenance.js');
const root=new URL('../app/src/main/assets/www/',import.meta.url);

function environment(seed=[],preview=null){
  const {window,document}=parseHTML(preview||fs.readFileSync(new URL('index.html',root),'utf8'));
  const values=new Map([['mobiwayRepairOrders',JSON.stringify(seed)]]);
  const storage={getItem:key=>values.has(key)?values.get(key):null,setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)};
  Object.defineProperty(window.HTMLSelectElement.prototype,'value',{configurable:true,get(){return this.querySelector('option[selected]')?.value??this.querySelector('option')?.value??'';},set(value){this.querySelectorAll('option').forEach(o=>{if(o.value===String(value))o.setAttribute('selected','');else o.removeAttribute('selected');});}});
  Object.defineProperty(window.HTMLElement.prototype,'elements',{configurable:true,get(){return new Proxy({}, {get:(_,name)=>this.querySelector('[name="'+String(name)+'"]')});}});
  window.HTMLElement.prototype.reportValidity=function(){return Array.from(this.querySelectorAll('[required]')).every(e=>e.type==='checkbox'?e.checked:!!e.value);};
  window.HTMLElement.prototype.reset=function(){this.querySelectorAll('input,select,textarea').forEach(e=>{if(e.type==='checkbox')e.checked=e.hasAttribute('checked');else if(e.tagName!=='SELECT')e.value=e.getAttribute('value')||'';});};
  window.HTMLElement.prototype.showModal=function(){this.open=true;};window.HTMLElement.prototype.close=function(){this.open=false;this.dispatchEvent(new window.Event('close'));};
  window.HTMLCanvasElement.prototype.getContext=()=>({clearRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},drawImage(){}});
  window.HTMLCanvasElement.prototype.toDataURL=()=> 'data:image/png;base64,AA==';
  class FormDataShim{
    constructor(form){this.data=[];for(const e of form.querySelectorAll('input,select,textarea')){const name=e.getAttribute('name');if(!name||e.hasAttribute('disabled'))continue;if(['checkbox','radio'].includes(e.type)&&!(e.checked??e.hasAttribute('checked')))continue;this.data.push([name,e.value||'']);}}
    entries(){return this.data[Symbol.iterator]();}getAll(name){return this.data.filter(x=>x[0]===name).map(x=>x[1]);}
  }
  const nativeReminders=[],externalLinks=[],published=[];
  window.RepairMaintenance=M;window.localStorage=storage;window.scrollTo=()=>{};window.open=url=>externalLinks.push(url);window.print=()=>{};
  window.AndroidBridge={setMaintenanceReminders:raw=>nativeReminders.push(JSON.parse(raw)),openExternal:url=>externalLinks.push(url)};
  let cloudStatus={configured:true,signedIn:false,memberActive:false,deviceActive:false,companyId:'mobiway',email:'',role:''};
  window.MobiwayCloud={getStatus:()=>JSON.stringify(cloudStatus),upsertRecord:(c,id,json)=>published.push({c,id,json}),listen(){}};
  const sandbox={window,document,localStorage:storage,console,FormData:FormDataShim,Event:window.Event,CustomEvent:window.CustomEvent,Date,Intl,URL,Blob,Map,Set,Uint8Array,crypto:globalThis.crypto,
    setTimeout:()=>1,clearTimeout(){},confirm:()=>true,prompt:()=>null,AndroidBridge:window.AndroidBridge,MobiwayCloud:window.MobiwayCloud};
  const context=vm.createContext(sandbox);
  Object.defineProperty(sandbox,'localStorage',{configurable:true,get:()=>window.localStorage});
  const scripts=preview?Array.from(document.querySelectorAll('script')).map((s,i)=>({name:'preview-'+i,source:s.textContent})):['mobiway-cloud.js','qrcodegen.js','app.js','maintenance-ui.js'].map(name=>({name,source:fs.readFileSync(new URL(name,root),'utf8')}));
  for(const {name,source} of scripts){
    vm.runInContext(source,context,{filename:name});
    if(context.qrcodegen)window.qrcodegen=context.qrcodegen;
    if(context.RepairMaintenance)window.RepairMaintenance=context.RepairMaintenance;
    if(window.MobiwayCloudClient)context.MobiwayCloudClient=window.MobiwayCloudClient;
  }
  if(preview){document.dispatchEvent(new window.Event('DOMContentLoaded'));window.dispatchEvent(new window.Event('DOMContentLoaded'));}
  document.getElementById('introSplash')?.remove();
  const field=(name,value)=>{const e=document.querySelector('#maintenanceDialogBody [name="'+name+'"]');assert.ok(e,'field '+name);if(e.type==='checkbox')e.checked=!!value;else e.value=String(value);return e;};
  const click=selector=>{const e=document.querySelector(selector);assert.ok(e,selector);e.click();};
  const submit=()=>{const form=document.querySelector('#maintenanceDialogBody form');assert.ok(form);form.dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));};
  return {window,document,storage,values,context,field,click,submit,nativeReminders,externalLinks,published,setCloud:s=>{cloudStatus=s;document.dispatchEvent(new window.CustomEvent('mobiway-cloud-status',{detail:s}));}};
}

test('actual app and maintenance scripts: reception, service, deadline, card, agenda and backup',()=>{
  const env=environment([{id:'OR101',orderNo:'MR-2026-101',plate:'AA-11-BB',make:'Renault',model:'Clio',customerName:'Cliente antigo',mileage:100000,kmOut:100010,status:'Entregue',createdAt:'01/09/2026, 09:00',deliveredAt:'02/09/2026, 17:00',lines:[],statusHistory:[]}]);
  const {window:w,document:d,field,click,submit,context}=env;const api=w.MobiwayRepairMaintenance;
  assert.equal(api.read('repairVehicles').length,1);assert.equal(api.read('maintenanceEntries').length,1);assert.equal(api.read('maintenanceEntries')[0].visibleToCustomer,false);
  click('[data-maint-view="vehicles"]');assert.equal(d.querySelector('.view.active').id,'vehicles');
  click('#addVehicleBtn');field('plate','CC-22-DD');field('make','Toyota');field('model','Avensis');field('customerName','Cliente demonstração');field('mileage',150000);field('phone','+351912345678');field('whatsappConsent',true);field('portalConsent',true);submit();
  assert.equal(d.getElementById('maintenanceError').textContent,'');assert.equal(api.read('repairVehicles').length,2);const v=api.read('repairVehicles').find(x=>x.plate==='CC-22-DD');assert.ok(v);assert.equal(d.querySelector('.view.active').id,'vehicleDetail');
  click('[data-action="service"][data-id="'+v.id+'"]');field('mileage',150100);field('title','Mudança de óleo e filtro');field('oilViscosity','5W-30');field('oilSpec','Norma de exemplo');field('oilBrand','Marca de exemplo');field('oilLitres','5.5');field('notes','NOTA INTERNA CONFIDENCIAL');field('visibleToCustomer',true);field('createPlan',true);field('intervalKm',10000);field('intervalMonths',12);d.querySelector('[name="filters"][value="Óleo"]').checked=true;submit();
  assert.equal(d.getElementById('maintenanceError').textContent,'');const entry=api.read('maintenanceEntries').find(x=>x.vehicleId===v.id);assert.equal(entry.oil.viscosity,'5W-30');assert.equal(entry.filters[0],'Óleo');const p=api.read('maintenancePlans').find(x=>x.vehicleId===v.id);assert.equal(p.dueKm,160100);
  let fresh=api.read('repairVehicles').find(x=>x.id===v.id);api.commit({repairVehicles:api.read('repairVehicles').map(x=>x.id===v.id?{...x,mileage:160101,updatedAt:new Date().toISOString()}:x)});
  click('[data-maint-view="reminders"]');assert.match(d.getElementById('remindersList').textContent,/Vencida/);
  click('[data-action="whatsapp"][data-id="'+p.id+'"]');assert.match(env.externalLinks[0],/^https:\/\/wa.me\/351912345678\?text=/);assert.ok(api.read('maintenancePlans').find(x=>x.id===p.id).lastDraftAt);
  api.openVehicle(v.id);click('[data-action="card"][data-id="'+v.id+'"]');assert.ok(d.querySelector('.cardQr svg'));assert.match(d.getElementById('maintenanceDialogBody').textContent,/Mudança de óleo e filtro/);assert.equal(d.getElementById('maintenanceDialogBody').textContent.includes('NOTA INTERNA CONFIDENCIAL'),false);assert.equal(d.getElementById('maintenanceDialogBody').textContent.includes('Cliente demonstração'),false);
  const html=api.cardHtml(api.read('repairVehicles').find(x=>x.id===v.id));assert.equal(html.includes('NOTA INTERNA CONFIDENCIAL'),false);assert.ok(html.includes('<svg'));d.getElementById('maintenanceDialog').close();
  click('[data-action="entry-visibility"][data-id="'+entry.id+'"]');assert.equal(api.snapshot(api.read('repairVehicles').find(x=>x.id===v.id)).services.length,0);
  click('[data-action="complete-plan"][data-id="'+p.id+'"]');field('mileage',161000);field('title','Revisão seguinte');submit();assert.equal(api.read('maintenancePlans').find(x=>x.id===p.id).state,'completed');const next=api.read('maintenancePlans').find(x=>x.previousPlanId===p.id);assert.equal(next.dueKm,171000);
  const before=api.read('maintenanceEntries').length;api.serviceForm(v.id,p.id);field('mileage',161000);submit();assert.match(d.getElementById('maintenanceError').textContent,/já foi concluída/);assert.equal(api.read('maintenanceEntries').length,before);d.getElementById('maintenanceDialog').close();
  click('[data-action="appointment"][data-id="'+v.id+'"]');field('title','Inspeção de exemplo');field('technician','Técnico exemplo');const appointmentTime=d.querySelector('[name="start"]').value;submit();assert.equal(api.read('appointments').length,1);
  click('#addAppointmentBtn');field('vehicleId',v.id);field('title','Revisão no mesmo horário');field('start',appointmentTime);field('technician','Técnico exemplo');submit();assert.match(d.getElementById('maintenanceError').textContent,/Já existe um agendamento/);assert.equal(api.read('appointments').length,1);d.getElementById('maintenanceDialog').close();
  const backup=vm.runInContext('repairBackupPayload()',context);assert.equal(backup.version,3);assert.equal(backup.maintenance.repairVehicles.length,2);assert.equal(backup.maintenance.appointments.length,1);
  const originalCount=api.read('maintenanceEntries').length;api.importState({app:'MOBIWAY REPAIR',version:2,orders:[]});assert.equal(api.read('maintenanceEntries').length,originalCount);
  assert.ok(env.nativeReminders.length>0);assert.ok(env.nativeReminders.at(-1).plans.some(x=>x.id===next.id));
  click('[data-action="reception"][data-id="'+v.id+'"]');assert.equal(d.querySelector('.view.active').id,'reception');assert.equal(d.querySelector('#repairForm [name="plate"]').value,'CC-22-DD');
});

test('storage failure rolls back every changed collection',()=>{
  const {window:w,storage}=environment();const api=w.MobiwayRepairMaintenance;const before=api.exportState();const real=storage.setItem;let failed=false;
  storage.setItem=(key,value)=>{if(key==='mobiwayRepairMaintenancePlans'&&!failed){failed=true;const e=new Error('full');e.name='QuotaExceededError';throw e;}return real(key,value);};
  assert.throws(()=>api.commit({repairVehicles:[{id:'V1',plate:'CC22DD',updatedAt:'2026'}],maintenancePlans:[]}),/armazenamento está cheio/);
  assert.deepEqual(api.exportState(),before);
});

test('cloud keeps offline edits, only server snapshots acknowledge writes, and viewer cannot edit',()=>{
  const env=environment();const api=env.window.MobiwayRepairMaintenance;
  const v=M.vehicle({plate:'CC-22-DD',mileage:123000,customerName:'Teste'},null,[]);api.commit({repairVehicles:[v]});
  env.setCloud({configured:true,signedIn:true,memberActive:true,deviceActive:true,companyId:'mobiway',email:'test@example.invalid',role:'workshop'});assert.ok(env.published.some(x=>x.id===v.id));
  const deliver=(records,fromCache)=>env.document.dispatchEvent(new env.window.CustomEvent('mobiway-cloud-collection',{detail:{collection:'repairVehicles',records,fromCache}}));
  deliver([{...v,mileage:1,updatedAt:'2020-01-01T00:00:00.000Z'}],false);assert.equal(api.read('repairVehicles')[0].mileage,123000);
  deliver([v],true);assert.ok(JSON.parse(env.storage.getItem('mobiwayRepairMaintenanceOutbox')).repairVehicles[v.id]);
  deliver([v],false);assert.equal(JSON.parse(env.storage.getItem('mobiwayRepairMaintenanceOutbox')).repairVehicles[v.id],undefined);
  env.setCloud({configured:true,signedIn:true,memberActive:true,deviceActive:true,companyId:'mobiway',email:'viewer@example.invalid',role:'viewer'});assert.throws(()=>api.commit({maintenancePlans:[]}),/não permite editar/);
});

test('escaping prevents customer controlled text from becoming markup',()=>{
  const env=environment();const api=env.window.MobiwayRepairMaintenance;const v=M.vehicle({plate:'CC22DD',make:'<img src=x onerror=alert(1)>',customerName:'<script>bad()</script>'},null,[]);api.commit({repairVehicles:[v]});
  assert.equal(env.document.querySelectorAll('#vehiclesList img').length,0);assert.equal(env.document.querySelectorAll('#vehiclesList script').length,0);assert.match(env.document.getElementById('vehiclesList').textContent,/<img src=x/);
});

test('publication and revocation are acknowledged before a live link or consent change is committed',()=>{
  const env=environment(),w=env.window,api=w.MobiwayRepairMaintenance;
  const requests=[],revocations=[];
  w.MobiwayCloud.publishCustomerCard=(token,raw,expires)=>requests.push({token,card:JSON.parse(raw),expires});
  w.MobiwayCloud.revokeCustomerCard=token=>revocations.push(token);
  vm.runInContext("saveSettingsData({...loadSettings(),portalUrl:'https://example.invalid/card.html'})",env.context);
  env.setCloud({configured:true,signedIn:true,memberActive:true,deviceActive:true,companyId:'mobiway',email:'test@example.invalid',role:'workshop'});
  const v=M.vehicle({plate:'CC22DD',customerName:'Cliente privado',portalConsent:true},null,[]);api.commit({repairVehicles:[v]});api.openVehicle(v.id);
  env.click('[data-action="card"]');env.click('#publishCustomerCard');assert.equal(requests.length,1);assert.equal(api.read('repairVehicles')[0].portalPublished,undefined);
  w.receiveRepairCardPublish({token:requests[0].token,ok:true});assert.equal(api.read('repairVehicles')[0].portalPublished,true);assert.match(env.document.getElementById('maintenanceDialogBody').textContent,/https:\/\/example.invalid\/card.html#/);assert.equal(requests.length,1);
  env.document.getElementById('maintenanceDialog').close();env.click('[data-action="edit-vehicle"]');env.field('portalConsent',false);env.submit();assert.equal(revocations.length,1);assert.equal(api.read('repairVehicles')[0].portalConsent,true);
  w.receiveRepairCardPublish({token:revocations[0],ok:false,error:'Revogação não confirmada'});assert.equal(api.read('repairVehicles')[0].portalConsent,true);assert.match(env.document.getElementById('maintenanceError').textContent,/não confirmada/);
  env.submit();w.receiveRepairCardPublish({token:revocations[1],ok:true});assert.equal(api.read('repairVehicles')[0].portalConsent,false);assert.equal(api.read('repairVehicles')[0].portalPublished,false);
});

test('multiple live customer cards refresh in order without dropping queued updates',()=>{
  const env=environment(),w=env.window,api=w.MobiwayRepairMaintenance,requests=[];
  w.MobiwayCloud.publishCustomerCard=(token,raw,expires)=>requests.push({token,raw,expires});
  vm.runInContext("saveSettingsData({...loadSettings(),portalUrl:'https://example.invalid/card.html'})",env.context);
  env.setCloud({configured:true,signedIn:true,memberActive:true,deviceActive:true,companyId:'mobiway',email:'test@example.invalid',role:'workshop'});
  const a={...M.vehicle({plate:'CC22DD',customerName:'A',portalConsent:true},null,[]),portalPublished:true,portalToken:'a'.repeat(32),portalExpiresAt:new Date(Date.now()+86400000).toISOString()};
  const b={...M.vehicle({plate:'EE33FF',customerName:'B',portalConsent:true},null,[]),portalPublished:true,portalToken:'b'.repeat(32),portalExpiresAt:new Date(Date.now()+86400000).toISOString()};
  api.commit({repairVehicles:[a,b]});assert.equal(requests.length,1);w.receiveRepairCardPublish({token:requests[0].token,ok:true});assert.equal(requests.length,2);w.receiveRepairCardPublish({token:requests[1].token,ok:true});assert.equal(JSON.parse(env.storage.getItem('mobiwayRepairCardRefreshQueue')).length,0);assert.equal(requests.length,2);
});

test('self contained offline preview boots, seeds three demo vehicles and isolates session data',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'repair-preview-')),file=path.join(dir,'preview.html');
  try{
    execFileSync('python3',[new URL('../tools/build_preview.py',import.meta.url).pathname,file]);
    const html=fs.readFileSync(file,'utf8');assert.equal(/<script\s+src=/.test(html),false);assert.equal(/<link\s+rel="stylesheet"/.test(html),false);
    const env=environment([],html),api=env.window.MobiwayRepairMaintenance;
    assert.equal(api.read('repairVehicles').length,3);assert.equal(api.read('maintenancePlans').length,3);assert.equal(api.read('appointments').length,1);assert.match(env.document.querySelector('.demoBanner').textContent,/Dados fictícios/);
    assert.equal(env.values.get('mobiwayRepairVehicles'),undefined);assert.equal(env.document.querySelectorAll('#vehiclesList .vehicleCard').length,3);
    env.click('[data-action="open-vehicle"][data-id="DEMO_V1"]');env.click('[data-action="card"][data-id="DEMO_V1"]');assert.ok(env.document.querySelector('.cardQr svg'));assert.match(env.document.getElementById('maintenanceDialogBody').textContent,/Mudança de óleo e filtros/);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
