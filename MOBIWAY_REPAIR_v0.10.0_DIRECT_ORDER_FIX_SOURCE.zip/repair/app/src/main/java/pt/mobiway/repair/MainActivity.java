package pt.mobiway.repair;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri cameraUri;
    private static final int FILE_CHOOSER = 1001;
    private static final int BACKUP_EXPORT = 3001;
    private static final int BACKUP_IMPORT = 3002;
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";
    private static final String EXTRA_REPAIR_PAYLOAD_URI = "MOBIWAY_REPAIR_PAYLOAD_URI";
    private static final String EXTRA_AVALIA_RESULT_URI = "MOBIWAY_AVALIA_RESULT_URI";
    private static final String PREFS_INTEGRATION = "mobiway_repair_integration";
    private static final String PREF_PENDING_AVALIA = "pending_avalia_result";
    private String pendingBackupJson = "{}";
    private String pendingAvaliaResultPayload = "";


    private static class PlateCandidate {
        final String plate;
        final int corrections;
        PlateCandidate(String plate, int corrections) {
            this.plate = plate;
            this.corrections = corrections;
        }
    }

    private static Character asLetter(char c) {
        c = Character.toUpperCase(c);
        if (c >= 'A' && c <= 'Z') return c;
        switch (c) {
            case '0': return 'O';
            case '1': return 'I';
            case '2': return 'Z';
            case '4': return 'A';
            case '5': return 'S';
            case '6': return 'G';
            case '8': return 'B';
            default: return null;
        }
    }

    private static Character asDigit(char c) {
        c = Character.toUpperCase(c);
        if (c >= '0' && c <= '9') return c;
        switch (c) {
            case 'O': case 'Q': case 'D': return '0';
            case 'I': case 'L': return '1';
            case 'Z': return '2';
            case 'A': return '4';
            case 'S': return '5';
            case 'G': return '6';
            case 'B': return '8';
            default: return null;
        }
    }

    private static PlateCandidate applyPlateMask(String raw, String mask) {
        if (raw == null || raw.length() != 6 || mask.length() != 6) return null;
        StringBuilder out = new StringBuilder(6);
        int corrections = 0;
        for (int i = 0; i < 6; i++) {
            char source = Character.toUpperCase(raw.charAt(i));
            Character mapped;
            if (mask.charAt(i) == 'L') {
                mapped = asLetter(source);
                if (mapped == null) return null;
                if (!(source >= 'A' && source <= 'Z')) corrections++;
            } else {
                mapped = asDigit(source);
                if (mapped == null) return null;
                if (!(source >= '0' && source <= '9')) corrections++;
            }
            out.append(mapped);
        }
        if (corrections > 2) return null;
        String c = out.toString();
        return new PlateCandidate(c.substring(0,2) + "-" + c.substring(2,4) + "-" + c.substring(4,6), corrections);
    }

    private static PlateCandidate findPortugalPlate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        java.util.regex.Pattern token = java.util.regex.Pattern.compile(
            "(?i)(?<![A-Z0-9])([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})(?![A-Z0-9])"
        );
        java.util.regex.Matcher m = token.matcher(text.toUpperCase(java.util.Locale.ROOT));
        PlateCandidate best = null;
        String[] masks = {"LLDDLL", "LLDDDD", "DDLLDD", "DDDDLL"};
        while (m.find()) {
            String raw = (m.group(1) + m.group(2) + m.group(3)).replaceAll("[^A-Z0-9]", "");
            for (String mask : masks) {
                PlateCandidate c = applyPlateMask(raw, mask);
                if (c != null && (best == null || c.corrections < best.corrections)) best = c;
            }
        }
        return best;
    }

    private void evaluateJavascriptCallback(String functionName, JSONObject payload) {
        final String js = "if(typeof " + functionName + "==='function'){" + functionName + "(" + JSONObject.quote(payload.toString()) + ");}";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void recognizePlateNative(String dataUrl, String callbackFunction) {
        try {
            if (dataUrl == null || dataUrl.trim().isEmpty()) throw new IllegalArgumentException("Imagem vazia");
            int comma = dataUrl.indexOf(',');
            String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível abrir a fotografia");
            com.google.mlkit.vision.common.InputImage image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.TextRecognizer recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
            );
            recognizer.process(image)
                .addOnSuccessListener(result -> {
                    JSONObject out = new JSONObject();
                    try {
                        PlateCandidate candidate = findPortugalPlate(result.getText());
                        if (candidate == null) {
                            out.put("ok", false);
                            out.put("error", "Não foi possível reconhecer uma matrícula portuguesa na fotografia.");
                        } else {
                            out.put("ok", true);
                            out.put("plate", candidate.plate);
                            out.put("confidence", Math.max(75, 99 - candidate.corrections * 9));
                            out.put("corrections", candidate.corrections);
                        }
                    } catch (Exception e) {
                        try { out.put("ok", false); out.put("error", "Erro ao interpretar a matrícula."); } catch (Exception ignored) { }
                    }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                })
                .addOnFailureListener(e -> {
                    JSONObject out = new JSONObject();
                    try { out.put("ok", false); out.put("error", "Falha na leitura OCR: " + (e.getMessage() == null ? "erro desconhecido" : e.getMessage())); } catch (Exception ignored) { }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                });
        } catch (Exception e) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha ao preparar a fotografia." : e.getMessage()); } catch (Exception ignored) { }
            evaluateJavascriptCallback(callbackFunction, out);
        }
    }

    private static String nodeText(org.w3c.dom.Document doc, String localName) {
        org.w3c.dom.NodeList nodes = doc.getElementsByTagNameNS("*", localName);
        if (nodes.getLength() == 0) nodes = doc.getElementsByTagName(localName);
        if (nodes.getLength() == 0 || nodes.item(0) == null) return "";
        return nodes.item(0).getTextContent() == null ? "" : nodes.item(0).getTextContent().trim();
    }

    private void lookupPortugalVehicleNative(String plate, String username, String callbackFunction) {
        final String cleanPlate = plate == null ? "" : plate.trim().toUpperCase(java.util.Locale.ROOT);
        final String cleanUser = username == null ? "" : username.trim();
        new Thread(() -> {
            JSONObject out = new JSONObject();
            java.net.HttpURLConnection conn = null;
            try {
                if (cleanPlate.isEmpty()) throw new IllegalArgumentException("Indica uma matrícula.");
                if (cleanUser.isEmpty()) throw new IllegalArgumentException("Configura o utilizador Matricula/RegCheck nas definições.");
                java.net.URL url = new java.net.URL("https://www.matricula.co.pt/api/reg.asmx/CheckPortugal");
                conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(20000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setRequestProperty("Accept", "application/xml,text/xml,*/*");
                String body = "RegistrationNumber=" + java.net.URLEncoder.encode(cleanPlate.replace("-", ""), "UTF-8") +
                    "&username=" + java.net.URLEncoder.encode(cleanUser, "UTF-8");
                byte[] bodyBytes = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(bodyBytes.length);
                try (java.io.OutputStream os = conn.getOutputStream()) { os.write(bodyBytes); }
                int status = conn.getResponseCode();
                java.io.InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
                if (stream == null) throw new java.io.IOException("Resposta vazia do serviço de matrícula.");
                javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                factory.setNamespaceAware(true);
                try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) { }
                try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) { }
                try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) { }
                org.w3c.dom.Document doc = factory.newDocumentBuilder().parse(stream);
                String vehicleJson = nodeText(doc, "vehicleJson");
                if (status < 200 || status >= 300) throw new java.io.IOException("Serviço de matrícula respondeu HTTP " + status + ".");
                if (vehicleJson.isEmpty()) throw new java.io.IOException("O serviço não devolveu dados para esta matrícula.");
                JSONObject vehicle = new JSONObject(vehicleJson);
                String providerError = vehicle.optString("Error", vehicle.optString("error", "")).trim();
                if (!providerError.isEmpty()) throw new java.io.IOException(providerError);
                out.put("ok", true);
                out.put("plate", cleanPlate);
                out.put("provider", "Matricula.co.pt / RegCheck");
                out.put("data", vehicle);
            } catch (Exception e) {
                try {
                    out.put("ok", false);
                    out.put("plate", cleanPlate);
                    out.put("error", e.getMessage() == null ? "Falha na consulta da matrícula." : e.getMessage());
                } catch (Exception ignored) { }
            } finally {
                if (conn != null) conn.disconnect();
            }
            evaluateJavascriptCallback(callbackFunction, out);
        }, "MobiwayPlateLookup").start();
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        captureAvaliaResult(getIntent());
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.addJavascriptInterface(new MobiwayCloudBridge(this, webView, "repair"), "MobiwayCloud");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!storedPendingAvalia().isEmpty()) triggerAvaliaImport();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                Intent camera = buildCameraIntent();
                if (params != null && params.isCaptureEnabled() && camera != null) {
                    startActivityForResult(camera, FILE_CHOOSER);
                    return true;
                }

                Intent chooser = Intent.createChooser(gallery, "Fotografias da viatura");
                if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                startActivityForResult(chooser, FILE_CHOOSER);
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Intent buildCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) return null;
        try {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MobiwayRepair");
            if (!dir.exists()) dir.mkdirs();
            File image = File.createTempFile("repair_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", image);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return camera;
        } catch (IOException e) {
            cameraUri = null;
            return null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == BACKUP_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out != null) out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode == BACKUP_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in != null) {
                        String json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                        String js = "if(window.receiveRepairBackup){window.receiveRepairBackup(" + JSONObject.quote(json) + ");}";
                        webView.post(() -> webView.evaluateJavascript(js, null));
                    }
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode != FILE_CHOOSER || uploadCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                results = new Uri[n];
                for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                results = new Uri[]{cameraUri};
            }
        }
        uploadCallback.onReceiveValue(results);
        uploadCallback = null;
        cameraUri = null;
    }

    private Uri writeIntegrationPayload(String prefix, String payload) {
        try {
            File dir = new File(getCacheDir(), "integration");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile(prefix, ".json", dir);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write((payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8));
            }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readIntegrationPayload(Intent intent, String uriKey) {
        if (intent == null) return "";
        try {
            Uri uri = intent.getParcelableExtra(uriKey);
            if (uri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return "";
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            return "";
        }
    }

    private void persistPendingAvalia(String payload) {
        pendingAvaliaResultPayload = payload == null ? "" : payload.trim();
        SharedPreferences prefs = getSharedPreferences(PREFS_INTEGRATION, MODE_PRIVATE);
        if (pendingAvaliaResultPayload.isEmpty()) prefs.edit().remove(PREF_PENDING_AVALIA).apply();
        else prefs.edit().putString(PREF_PENDING_AVALIA, pendingAvaliaResultPayload).apply();
    }

    private String storedPendingAvalia() {
        if (pendingAvaliaResultPayload != null && !pendingAvaliaResultPayload.isEmpty()) return pendingAvaliaResultPayload;
        return getSharedPreferences(PREFS_INTEGRATION, MODE_PRIVATE).getString(PREF_PENDING_AVALIA, "");
    }

    private void captureAvaliaResult(Intent intent) {
        if (intent == null) return;
        String payload = intent.getStringExtra(EXTRA_AVALIA_RESULT);
        if (payload == null || payload.trim().isEmpty()) payload = readIntegrationPayload(intent, EXTRA_AVALIA_RESULT_URI);
        if (payload != null && !payload.trim().isEmpty()) persistPendingAvalia(payload);
    }

    private void triggerAvaliaImport() {
        if (webView == null) return;
        webView.postDelayed(() -> webView.evaluateJavascript(
            "if(typeof importAvaliaResult==='function'){importAvaliaResult();}", null
        ), 250);
    }

    public class Bridge {
        @JavascriptInterface public void recognizePlate(String dataUrl) {
            recognizePlateNative(dataUrl, "window.receiveRepairPlateScan");
        }

        @JavascriptInterface public void lookupPortugalVehicle(String plate, String username) {
            lookupPortugalVehicleNative(plate, username, "window.receiveRepairVehicleLookup");
        }

        @JavascriptInterface public void printA4() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("MOBIWAY REPAIR - Folha de Obra");
                PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
                pm.print("MOBIWAY REPAIR - A4", adapter, attrs);
            });
        }

        @JavascriptInterface public void exportBackup(String fileName, String json) {
            pendingBackupJson = json == null ? "{}" : json;
            final String safeName = (fileName == null || fileName.trim().isEmpty()) ? "mobiway-repair-backup.json" : fileName;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(intent, BACKUP_EXPORT);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, BACKUP_IMPORT);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public boolean openAvalia(String vehicleJson) {
            final String payload = vehicleJson == null ? "{}" : vehicleJson;
            final Uri payloadUri = writeIntegrationPayload("repair_to_avalia_", payload);
            try {
                Intent launch = new Intent();
                launch.setClassName("pt.mobiway.avalia", "pt.mobiway.avalia.MainActivity");
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (payloadUri != null) {
                    launch.putExtra(EXTRA_REPAIR_PAYLOAD_URI, payloadUri);
                    launch.setClipData(ClipData.newRawUri("MOBIWAY REPAIR", payloadUri));
                    launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else if (payload.length() < 300000) {
                    launch.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                }
                launch.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                startActivity(launch);
                return true;
            } catch (Exception first) {
                try {
                    Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.avalia");
                    if (fallback == null) return false;
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (payloadUri != null) {
                        fallback.putExtra(EXTRA_REPAIR_PAYLOAD_URI, payloadUri);
                        fallback.setClipData(ClipData.newRawUri("MOBIWAY REPAIR", payloadUri));
                        fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else if (payload.length() < 300000) {
                        fallback.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                    }
                    fallback.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                    startActivity(fallback);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        }

        @JavascriptInterface public boolean isAvaliaInstalled() {
            try {
                getPackageManager().getPackageInfo("pt.mobiway.avalia", 0);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface public String getAvaliaResultPayload() {
            String payload = storedPendingAvalia();
            if (payload != null && !payload.isEmpty()) return payload;
            Intent intent = getIntent();
            if (intent == null) return "";
            payload = intent.getStringExtra(EXTRA_AVALIA_RESULT);
            if (payload == null || payload.isEmpty()) payload = readIntegrationPayload(intent, EXTRA_AVALIA_RESULT_URI);
            if (payload != null && !payload.isEmpty()) persistPendingAvalia(payload);
            return payload == null ? "" : payload;
        }

        @JavascriptInterface public void clearAvaliaResultPayload() {
            persistPendingAvalia("");
            Intent intent = getIntent();
            if (intent != null) {
                intent.removeExtra(EXTRA_AVALIA_RESULT);
                intent.removeExtra(EXTRA_AVALIA_RESULT_URI);
                intent.removeExtra("MOBIWAY_AVALIA_SOURCE");
            }
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureAvaliaResult(intent);
        triggerAvaliaImport();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
