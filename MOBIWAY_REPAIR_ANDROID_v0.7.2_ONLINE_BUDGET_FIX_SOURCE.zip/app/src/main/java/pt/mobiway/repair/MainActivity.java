package pt.mobiway.repair;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri cameraUri;
    private static final int FILE_CHOOSER = 1001;
    private static final int BACKUP_EXPORT = 3001;
    private static final int BACKUP_IMPORT = 3002;
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";
    private static final String EXTRA_REPAIR_PAYLOAD_URI = "MOBIWAY_REPAIR_PAYLOAD_URI";
    private static final String EXTRA_AVALIA_RESULT_URI = "MOBIWAY_AVALIA_RESULT_URI";
    private String pendingBackupJson = "{}";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                Intent camera = buildCameraIntent();
                if (params != null && params.isCaptureEnabled() && camera != null) {
                    startActivityForResult(camera, FILE_CHOOSER);
                    return true;
                }

                Intent chooser = Intent.createChooser(gallery, "Fotografias da viatura");
                if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                startActivityForResult(chooser, FILE_CHOOSER);
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Intent buildCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) return null;
        try {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MobiwayRepair");
            if (!dir.exists()) dir.mkdirs();
            File image = File.createTempFile("repair_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", image);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return camera;
        } catch (IOException e) {
            cameraUri = null;
            return null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == BACKUP_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out != null) out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode == BACKUP_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in != null) {
                        String json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                        String js = "if(window.receiveRepairBackup){window.receiveRepairBackup(" + JSONObject.quote(json) + ");}";
                        webView.post(() -> webView.evaluateJavascript(js, null));
                    }
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode != FILE_CHOOSER || uploadCallback == null) return;

        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                results = new Uri[n];
                for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                results = new Uri[]{cameraUri};
            }
        }
        uploadCallback.onReceiveValue(results);
        uploadCallback = null;
        cameraUri = null;
    }

    private Uri writeIntegrationPayload(String prefix, String payload) {
        try {
            File dir = new File(getCacheDir(), "integration");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile(prefix, ".json", dir);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write((payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8));
            }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readIntegrationPayload(Intent intent, String uriKey) {
        if (intent == null) return "";
        try {
            Uri uri = intent.getParcelableExtra(uriKey);
            if (uri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return "";
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            return "";
        }
    }

    public class Bridge {
        @JavascriptInterface public void printA4() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("MOBIWAY REPAIR - Folha de Obra");
                PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
                pm.print("MOBIWAY REPAIR - A4", adapter, attrs);
            });
        }

        @JavascriptInterface public void exportBackup(String fileName, String json) {
            pendingBackupJson = json == null ? "{}" : json;
            final String safeName = (fileName == null || fileName.trim().isEmpty()) ? "mobiway-repair-backup.json" : fileName;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(intent, BACKUP_EXPORT);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, BACKUP_IMPORT);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public boolean openAvalia(String vehicleJson) {
            final String payload = vehicleJson == null ? "{}" : vehicleJson;
            final Uri payloadUri = writeIntegrationPayload("repair_to_avalia_", payload);
            try {
                Intent launch = new Intent();
                launch.setClassName("pt.mobiway.avalia", "pt.mobiway.avalia.MainActivity");
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (payloadUri != null) {
                    launch.putExtra(EXTRA_REPAIR_PAYLOAD_URI, payloadUri);
                    launch.setClipData(ClipData.newRawUri("MOBIWAY REPAIR", payloadUri));
                    launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else if (payload.length() < 300000) {
                    launch.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                }
                launch.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                startActivity(launch);
                return true;
            } catch (Exception first) {
                try {
                    Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.avalia");
                    if (fallback == null) return false;
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (payloadUri != null) {
                        fallback.putExtra(EXTRA_REPAIR_PAYLOAD_URI, payloadUri);
                        fallback.setClipData(ClipData.newRawUri("MOBIWAY REPAIR", payloadUri));
                        fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else if (payload.length() < 300000) {
                        fallback.putExtra("MOBIWAY_REPAIR_VEHICLE_JSON", payload);
                    }
                    fallback.putExtra("MOBIWAY_REPAIR_SOURCE", "pt.mobiway.repair");
                    startActivity(fallback);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        }

        @JavascriptInterface public boolean isAvaliaInstalled() {
            try {
                getPackageManager().getPackageInfo("pt.mobiway.avalia", 0);
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface public String getAvaliaResultPayload() {
            Intent intent = getIntent();
            if (intent == null) return "";
            String payload = intent.getStringExtra(EXTRA_AVALIA_RESULT);
            if (payload != null && !payload.isEmpty()) return payload;
            return readIntegrationPayload(intent, EXTRA_AVALIA_RESULT_URI);
        }

        @JavascriptInterface public void clearAvaliaResultPayload() {
            Intent intent = getIntent();
            if (intent != null) {
                intent.removeExtra(EXTRA_AVALIA_RESULT);
                intent.removeExtra(EXTRA_AVALIA_RESULT_URI);
            }
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) webView.post(() -> webView.reload());
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
