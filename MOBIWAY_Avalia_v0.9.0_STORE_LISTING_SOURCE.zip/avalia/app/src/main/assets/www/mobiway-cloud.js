(()=>{
  'use strict';
  const bridge=()=>window.MobiwayCloud||null;
  let lastStatus={configured:false,signedIn:false,companyId:'mobiway',memberActive:false,role:'',deviceActive:false};
  let lastAdmin={requests:[],members:[],devices:[]};
  const emit=(name,detail)=>document.dispatchEvent(new CustomEvent(name,{detail}));
  const parse=(x,f={})=>{try{return typeof x==='string'?JSON.parse(x):x}catch{return f}};
  const esc=(s)=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const roleLabel=(r)=>({owner:'Proprietário',admin:'Administrador',buyer:'Compras / Avalia',workshop:'Oficina / Repair',sales:'Vendas',viewer:'Consulta'}[r]||'Sem perfil');
  const moduleLabel=(m)=>m==='repair'?'Repair':'Avalia';
  const roles=['admin','buyer','workshop','sales','viewer'];

  function status(){
    try{lastStatus=parse(bridge()?.getStatus?.()||'{}',{});return lastStatus}catch{return lastStatus}
  }
  function ready(){const s=status();return !!(s.signedIn&&s.memberActive&&s.deviceActive)}
  function canWrite(collection){
    const s=status(),r=s.role;
    if(!s.memberActive||!s.deviceActive)return false;
    if(r==='owner'||r==='admin')return true;
    if(collection==='evaluations')return r==='buyer';
    if(collection==='repairOrders')return r==='workshop';
    if(collection==='vehicles')return ['buyer','workshop','sales'].includes(r);
    return false;
  }
  function label(){
    const s=status();
    if(ready()) return s.moduleMode==='read'?'☁ CLOUD · R':'☁ CLOUD';
    if(s.signedIn&&s.memberExists&&!s.memberActive)return '☁ BLOQ';
    if(s.signedIn)return '☁ PEND';
    return '☁ OFF';
  }
  function updatePill(){
    const b=document.getElementById('mobiwayCloudPill');if(!b)return;
    const s=status();b.textContent=label();b.dataset.online=ready()?'1':'0';
    b.dataset.pending=(s.signedIn&&!ready())?'1':'0';
    b.title=ready()?`MOBIWAY Cloud · ${roleLabel(s.role)} · ${s.deviceLabel||''}`:(s.signedIn?'MOBIWAY Cloud · acesso pendente/bloqueado':'MOBIWAY Cloud · configurar');
  }
  function inject(){
    if(document.getElementById('mobiwayCloudPill'))return;
    const st=document.createElement('style');
    st.textContent=`
#mobiwayCloudPill{position:fixed;right:12px;bottom:78px;z-index:9998;border:1px solid #39414c;background:#15191f;color:#fff;border-radius:18px;padding:8px 11px;font:700 11px system-ui;box-shadow:0 6px 24px #0007}
#mobiwayCloudPill[data-online="1"]{border-color:#55a876}#mobiwayCloudPill[data-pending="1"]{border-color:#d59b37}
#mobiwayCloudModal{position:fixed;inset:0;z-index:9999;background:#000c;display:grid;place-items:center;padding:18px}
#mobiwayCloudModal .mwCloudBox{width:min(680px,100%);max-height:90vh;overflow:auto;background:#11161c;border:1px solid #343c47;border-radius:18px;padding:18px;color:#fff;font-family:system-ui;box-sizing:border-box}
#mobiwayCloudModal h2{margin:0 0 5px}#mobiwayCloudModal h3{margin:18px 0 8px;font-size:15px}#mobiwayCloudModal p{color:#aeb7c2;font-size:13px;line-height:1.4}
#mobiwayCloudModal label{display:block;font-size:12px;margin:10px 0}#mobiwayCloudModal input,#mobiwayCloudModal select{box-sizing:border-box;width:100%;margin-top:5px;padding:11px;border-radius:10px;border:1px solid #3b4653;background:#0b0f13;color:#fff}
#mobiwayCloudModal .mwRow{display:grid;grid-template-columns:1fr 1fr;gap:8px}#mobiwayCloudModal .mwRow3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
#mobiwayCloudModal button{padding:10px 12px;border-radius:10px;border:1px solid #4b5563;background:#202833;color:#fff;font-weight:700}#mobiwayCloudModal button.mwPrimary{background:#e98800;border-color:#e98800;color:#111}#mobiwayCloudModal button.mwDanger{border-color:#8b4242;background:#351d1d}
#mobiwayCloudModal .mwStatus{font-size:12px;padding:10px;border-radius:9px;background:#0b0f13;margin:8px 0;line-height:1.5}.mwBadge{display:inline-block;padding:3px 7px;border-radius:999px;background:#2b333e;font-size:10px;font-weight:800}.mwOk{background:#173522;color:#9ee5b2}.mwWarn{background:#3a2a11;color:#f0c276}
#mobiwayCloudModal .mwCard{border:1px solid #303945;background:#0d1217;border-radius:12px;padding:11px;margin:8px 0}.mwMeta{font-size:11px;color:#9fa9b5;line-height:1.45}.mwAdminGrid{display:grid;gap:8px}.mwAdminActions{display:grid;grid-template-columns:1fr auto;gap:7px;align-items:end}.mwAdminActions select{margin:0}.mwCheck{display:flex!important;align-items:center;gap:7px}.mwCheck input{width:auto!important;margin:0!important}.mwSmall{font-size:11px;color:#96a1ae}.mwDivider{border:0;border-top:1px solid #2c333d;margin:18px 0}details summary{cursor:pointer;color:#c7d0db;font-size:12px;margin:10px 0}`;
    document.head.appendChild(st);
    const b=document.createElement('button');b.id='mobiwayCloudPill';b.type='button';b.onclick=openSetup;document.body.appendChild(b);updatePill();
  }

  function firebaseFields(s){
    return `<details ${s.configured?'':'open'}><summary>Configuração Firebase</summary>
      <label>Empresa / código Cloud<input id="mwCompany" value="${esc(s.companyId||'mobiway')}"></label>
      <label>Firebase Project ID<input id="mwProject" value="${esc(s.projectId||'')}"></label>
      <label>Firebase API key<input id="mwApi" autocomplete="off"></label>
      <label>Firebase Application ID<input id="mwApp" autocomplete="off"></label>
      <label>Storage bucket<input id="mwBucket" value="${esc(s.storageBucket||'')}" placeholder="projeto.firebasestorage.app"></label>
      <button id="mwSave" class="mwPrimary" style="width:100%">Guardar configuração Cloud</button>
      <p class="mwSmall">As chaves de configuração identificam o projeto Firebase; o controlo de acesso é feito por Firebase Authentication e pelas regras da MOBIWAY Cloud.</p>
    </details>`;
  }

  function authFields(s){
    return `<label>Email<input id="mwEmail" type="email" value="${esc(s.email||'')}" autocomplete="username"></label>
      <label>Palavra-passe<input id="mwPass" type="password" autocomplete="current-password"></label>
      <div class="mwRow"><button id="mwLogin" class="mwPrimary">Entrar</button><button id="mwCreate">Criar conta</button></div>
      <button id="mwReset" style="margin-top:8px;width:100%">Recuperar palavra-passe</button>`;
  }

  function memberSection(s){
    const blocked=s.memberExists&&!s.memberActive;
    if(blocked){
      return `<div class="mwStatus"><span class="mwBadge mwWarn">ACESSO BLOQUEADO</span><br>A conta existe na MOBIWAY Cloud, mas está desativada. Contacta o Proprietário/Administrador.</div>`;
    }
    if(!s.memberExists){
      if(!s.companyExists){
        return `<div class="mwStatus"><span class="mwBadge mwWarn">PRIMEIRA CONFIGURAÇÃO</span><br>Esta Cloud ainda não tem proprietário. A primeira conta autorizada pode inicializar a empresa.</div>
          <label>Nome do utilizador<input id="mwDisplayName" value="${esc(s.displayName||'')}"></label>
          <label>Nome deste equipamento<input id="mwDeviceLabel" value="${esc(s.deviceLabel||'')}"></label>
          <button id="mwBootstrap" class="mwPrimary" style="width:100%">Inicializar MOBIWAY Cloud como Proprietário</button>`;
      }
      return `<div class="mwStatus"><span class="mwBadge mwWarn">AGUARDA AUTORIZAÇÃO</span><br>A empresa já está criada. Envia um pedido ao Proprietário/Administrador.</div>
        <label>Nome do utilizador<input id="mwDisplayName" value="${esc(s.displayName||'')}"></label>
        <label>Nome deste equipamento<input id="mwDeviceLabel" value="${esc(s.deviceLabel||'')}"></label>
        <button id="mwRequestAccess" class="mwPrimary" style="width:100%">Pedir acesso · perfil sugerido ${esc(roleLabel(s.module==='repair'?'workshop':'buyer'))}</button>`;
    }
    const mode=s.moduleMode==='read'?'Só leitura':'Edição';
    return `<div class="mwStatus"><span class="mwBadge mwOk">ACESSO ATIVO</span><br><b>${esc(s.displayName||s.email||'Utilizador')}</b> · ${esc(roleLabel(s.role))}<br>${esc(moduleLabel(s.module))}: <b>${esc(mode)}</b></div>
      <label>Nome deste equipamento<input id="mwDeviceLabel" value="${esc(s.deviceLabel||'')}"></label>
      <div class="mwRow"><button id="mwDeviceSave" class="mwPrimary">Guardar equipamento</button><button id="mwRefresh">Atualizar acesso</button></div>
      <div class="mwMeta" style="margin-top:8px">ID: ${esc(s.deviceId||'')} · App ${esc(s.appVersion||'')}</div>
      ${s.manager?'<button id="mwAdmin" style="margin-top:12px;width:100%">Gerir utilizadores e equipamentos</button><div id="mwAdminPanel"></div>':''}`;
  }

  function openSetup(){
    document.getElementById('mobiwayCloudModal')?.remove();
    const s=status();
    const m=document.createElement('div');m.id='mobiwayCloudModal';
    let body=`<div class="mwCloudBox"><h2>MOBIWAY Cloud</h2><p>Núcleo comum da Avalia, Repair e futuro Hub. Sincronização, utilizadores, equipamentos e permissões.</p>`;
    if(!s.configured){
      body+=`<div class="mwStatus">Cloud ainda não configurada neste equipamento.</div>${firebaseFields(s)}`;
    }else if(!s.signedIn){
      body+=`<div class="mwStatus">Projeto <b>${esc(s.projectId||'')}</b> configurado. Inicia sessão com uma conta individual.</div>${authFields(s)}<hr class="mwDivider">${firebaseFields(s)}`;
    }else{
      body+=memberSection(s);
      body+=`<hr class="mwDivider"><div class="mwRow"><button id="mwLogout">Terminar sessão</button><button id="mwClose">Fechar</button></div><details><summary>Alterar configuração Firebase</summary>${firebaseFields(s)}</details>`;
    }
    if(!s.signedIn) body+=`<div class="mwRow" style="margin-top:12px"><button id="mwClose">Fechar</button><button id="mwRefresh">Atualizar</button></div>`;
    body+='</div>';m.innerHTML=body;document.body.appendChild(m);bindModal(m);updatePill();
  }

  function bindModal(m){
    const s=status();
    m.querySelectorAll('#mwClose').forEach(x=>x.onclick=()=>m.remove());
    m.querySelector('#mwSave')?.addEventListener('click',()=>{
      const cfg={companyId:m.querySelector('#mwCompany')?.value.trim()||'mobiway',projectId:m.querySelector('#mwProject')?.value.trim()||'',apiKey:m.querySelector('#mwApi')?.value.trim()||'',applicationId:m.querySelector('#mwApp')?.value.trim()||'',storageBucket:m.querySelector('#mwBucket')?.value.trim()||''};
      if(!cfg.projectId||!cfg.apiKey||!cfg.applicationId){notify('Preenche Project ID, API key e Application ID.');return;}
      const ok=bridge()?.configure?.(JSON.stringify(cfg));if(!ok)notify('Não foi possível configurar a MOBIWAY Cloud.');setTimeout(()=>{updatePill();openSetup()},350);
    });
    const creds=()=>[m.querySelector('#mwEmail')?.value.trim()||'',m.querySelector('#mwPass')?.value||''];
    m.querySelector('#mwLogin')?.addEventListener('click',()=>{const[e,p]=creds();bridge()?.signIn?.(e,p)});
    m.querySelector('#mwCreate')?.addEventListener('click',()=>{const[e,p]=creds();bridge()?.createAccount?.(e,p)});
    m.querySelector('#mwReset')?.addEventListener('click',()=>{const[e]=creds();bridge()?.sendPasswordReset?.(e)});
    m.querySelector('#mwLogout')?.addEventListener('click',()=>bridge()?.signOut?.());
    m.querySelector('#mwRefresh')?.addEventListener('click',()=>bridge()?.refresh?.());
    m.querySelector('#mwBootstrap')?.addEventListener('click',()=>bridge()?.bootstrapCompany?.(m.querySelector('#mwDisplayName')?.value.trim()||'',m.querySelector('#mwDeviceLabel')?.value.trim()||''));
    m.querySelector('#mwRequestAccess')?.addEventListener('click',()=>bridge()?.requestAccess?.(m.querySelector('#mwDisplayName')?.value.trim()||'',m.querySelector('#mwDeviceLabel')?.value.trim()||''));
    m.querySelector('#mwDeviceSave')?.addEventListener('click',()=>bridge()?.setDeviceLabel?.(m.querySelector('#mwDeviceLabel')?.value.trim()||''));
    m.querySelector('#mwAdmin')?.addEventListener('click',()=>{const p=m.querySelector('#mwAdminPanel');if(p)p.innerHTML='<p>A carregar gestão Cloud…</p>';bridge()?.getAdminData?.()});
    if(s.manager&&lastAdmin.members?.length) renderAdminData(lastAdmin);
  }

  function roleOptions(selected){return roles.map(r=>`<option value="${r}" ${r===selected?'selected':''}>${esc(roleLabel(r))}</option>`).join('')}
  function renderAdminData(data){
    lastAdmin=data||{requests:[],members:[],devices:[]};
    const p=document.querySelector('#mobiwayCloudModal #mwAdminPanel');if(!p)return;
    const pending=(lastAdmin.requests||[]).filter(x=>x.status!=='approved');
    const reqHtml=pending.length?pending.map(x=>`<div class="mwCard mwReq" data-uid="${esc(x.uid)}"><b>${esc(x.displayName||x.email||'Novo utilizador')}</b><div class="mwMeta">${esc(x.email)} · ${esc(moduleLabel(x.module))} · ${esc(x.deviceLabel||'equipamento')}</div><div class="mwAdminActions" style="margin-top:8px"><select class="mwRole">${roleOptions(x.requestedRole||'viewer')}</select><button class="mwApprove mwPrimary">Aprovar</button></div></div>`).join(''):'<p class="mwSmall">Sem pedidos pendentes.</p>';
    const memHtml=(lastAdmin.members||[]).map(x=>{
      const owner=x.role==='owner';
      return `<div class="mwCard mwMember" data-uid="${esc(x.uid)}"><b>${esc(x.displayName||x.email||x.uid)}</b> ${owner?'<span class="mwBadge">PROPRIETÁRIO</span>':''}<div class="mwMeta">${esc(x.email)} · ${esc(x.uid)}</div>${owner?`<div class="mwMeta" style="margin-top:6px">${esc(roleLabel(x.role))} · ativo</div>`:`<div class="mwAdminActions" style="margin-top:8px"><select class="mwRole">${roleOptions(x.role||'viewer')}</select><label class="mwCheck"><input class="mwActive" type="checkbox" ${x.active?'checked':''}> Ativo</label><button class="mwMemberSave">Guardar</button></div>`}</div>`;
    }).join('');
    const devHtml=(lastAdmin.devices||[]).map(x=>`<div class="mwCard mwDevice" data-id="${esc(x.id)}"><b>${esc(x.label||'Equipamento')}</b> <span class="mwBadge ${x.active?'mwOk':'mwWarn'}">${x.active?'ATIVO':'INATIVO'}</span><div class="mwMeta">${esc(x.email)} · ${esc(moduleLabel(x.module))} ${x.appVersion?'· '+esc(x.appVersion):''}<br>${esc(x.id)}</div><button class="mwDeviceToggle ${x.active?'mwDanger':''}" style="margin-top:8px">${x.active?'Desativar equipamento':'Ativar equipamento'}</button></div>`).join('')||'<p class="mwSmall">Ainda não existem equipamentos registados.</p>';
    p.innerHTML=`<h3>Pedidos de acesso</h3>${reqHtml}<h3>Utilizadores</h3>${memHtml}<h3>Equipamentos</h3>${devHtml}<p class="mwSmall">Para bloqueio forte, desativa o utilizador. A desativação isolada de um equipamento é um controlo operacional da app; contas não devem ser partilhadas entre pessoas.</p>`;
    p.querySelectorAll('.mwReq').forEach(card=>card.querySelector('.mwApprove')?.addEventListener('click',()=>bridge()?.approveAccess?.(card.dataset.uid,card.querySelector('.mwRole')?.value||'viewer')));
    p.querySelectorAll('.mwMember').forEach(card=>card.querySelector('.mwMemberSave')?.addEventListener('click',()=>bridge()?.updateMember?.(card.dataset.uid,card.querySelector('.mwRole')?.value||'viewer',!!card.querySelector('.mwActive')?.checked)));
    p.querySelectorAll('.mwDevice').forEach(card=>card.querySelector('.mwDeviceToggle')?.addEventListener('click',()=>{const current=(lastAdmin.devices||[]).find(x=>x.id===card.dataset.id);bridge()?.setDeviceActive?.(card.dataset.id,!current?.active)}));
  }

  function notify(msg){
    if(typeof window.toast==='function'){try{window.toast(msg);return}catch{}}
    const m=document.querySelector('#mobiwayCloudModal .mwCloudBox');
    if(m){const n=document.createElement('div');n.className='mwStatus';n.textContent=msg;m.prepend(n);setTimeout(()=>n.remove(),3500);return}
    alert(msg);
  }

  window.MobiwayCloudEvents={
    onStatus(raw){
      lastStatus=parse(raw,{});updatePill();emit('mobiway-cloud-status',lastStatus);
      if(document.getElementById('mobiwayCloudModal')) setTimeout(openSetup,80);
    },
    onCollection(raw){const x=parse(raw,{});emit('mobiway-cloud-collection',x)},
    onAdminData(raw){const x=parse(raw,{requests:[],members:[],devices:[]});renderAdminData(x);emit('mobiway-cloud-admin',x)},
    onMessage(raw){const x=parse(raw,{});if(x.message)notify(x.message);emit('mobiway-cloud-message',x)},
    onError(raw){const e=parse(raw,{});console.warn('MOBIWAY Cloud',e);if(e.message)notify(e.message);emit('mobiway-cloud-error',e)}
  };

  window.MobiwayCloudClient={
    status,openSetup,ready,canWrite,
    signedIn(){return !!status().signedIn},
    upsert(collection,record){if(!record?.id||!ready()||!canWrite(collection))return;bridge()?.upsertRecord?.(collection,String(record.id),JSON.stringify(record))},
    remove(collection,id){if(!id||!ready()||!canWrite(collection))return;bridge()?.deleteRecord?.(collection,String(id))},
    listen(collection){if(ready())bridge()?.listen?.(collection)},
    migrate(collection,records){if(!ready()||!canWrite(collection))return;(records||[]).forEach(x=>x?.id&&bridge()?.upsertRecord?.(collection,String(x.id),JSON.stringify(x)))},
    refresh(){bridge()?.refresh?.()}
  };

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',inject);else inject();
  setTimeout(()=>{updatePill();const s=status();emit('mobiway-cloud-status',s);if(s.signedIn)bridge()?.refresh?.()},500);
})();
