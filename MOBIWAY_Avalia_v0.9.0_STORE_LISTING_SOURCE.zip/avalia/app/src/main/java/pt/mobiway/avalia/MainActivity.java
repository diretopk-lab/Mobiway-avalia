package pt.mobiway.avalia;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_PERMISSION = 2001;
    private static final int BACKUP_EXPORT = 3001;
    private static final int BACKUP_IMPORT = 3002;
    private static final int STORE_EXPORT = 3003;
    private static final String EXTRA_REPAIR_VEHICLE = "MOBIWAY_REPAIR_VEHICLE_JSON";
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";
    private static final String EXTRA_REPAIR_PAYLOAD_URI = "MOBIWAY_REPAIR_PAYLOAD_URI";
    private static final String EXTRA_AVALIA_RESULT_URI = "MOBIWAY_AVALIA_RESULT_URI";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean cameraRequest;
    private String pendingBackupJson = "{}";
    private String pendingBackupFileName = "mobiway-avalia-backup.json";
    private String pendingStorePackageJson = "{}";
    private String pendingStorePackageFileName = "mobiway-shopbuilder.zip";
    private String pendingStoreEditorUrl = "https://www.amen.pt/";

    private static String csvCell(String value) {
        String v = value == null ? "" : value.replace("\r", " ").replace("\n", " ");
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    private static void zipText(ZipOutputStream zip, String name, String text) throws Exception {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        zip.write((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static byte[] dataUrlBytes(String dataUrl) {
        if (dataUrl == null || dataUrl.trim().isEmpty()) return new byte[0];
        int comma = dataUrl.indexOf(',');
        String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
        return android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
    }

    private void writeStorePackage(OutputStream output, String rawJson) throws Exception {
        JSONObject root = new JSONObject(rawJson == null ? "{}" : rawJson);
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zipText(zip, "listing.json", root.toString(2));
            zipText(zip, "description.txt", root.optString("description", ""));
            zipText(zip, "short-description.txt", root.optString("shortDescription", ""));

            String header = "ProductNumber;Name;ListPrice/EUR/gross;ShortDescription;Description;Manufacturer;StockLevel;Visible;Category\n";
            String row = String.join(";",
                csvCell(root.optString("productNumber", "")),
                csvCell(root.optString("name", "")),
                csvCell(String.valueOf(root.optDouble("price", 0))),
                csvCell(root.optString("shortDescription", "")),
                csvCell(root.optString("description", "")),
                csvCell(root.optString("manufacturer", "")),
                csvCell(String.valueOf(root.optInt("stocklevel", 1))),
                csvCell(root.optBoolean("visible", true) ? "Yes" : "No"),
                csvCell(root.optString("category", "Viaturas"))
            ) + "\n";
            zipText(zip, "products.csv", header + row);

            org.json.JSONArray photos = root.optJSONArray("photos");
            if (photos != null) {
                for (int i = 0; i < photos.length(); i++) {
                    JSONObject ph = photos.optJSONObject(i);
                    if (ph == null) continue;
                    byte[] bytes = dataUrlBytes(ph.optString("data", ""));
                    if (bytes.length == 0) continue;
                    String name = ph.optString("name", "foto-" + (i + 1) + ".jpg").replaceAll("[^A-Za-z0-9._-]", "_");
                    if (!name.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(jpg|jpeg|png)$")) name += ".jpg";
                    ZipEntry entry = new ZipEntry(String.format(java.util.Locale.ROOT, "photos/%02d-%s", i + 1, name));
                    zip.putNextEntry(entry);
                    zip.write(bytes);
                    zip.closeEntry();
                }
            }

            String readme = "MOBIWAY · pacote de anúncio ShopBuilder\n\n" +
                "Conteúdo:\n- products.csv: dados do produto para importação\n- listing.json: cópia estruturada completa\n- description.txt: descrição longa\n- photos/: fotografias selecionadas\n\n" +
                "No ShopBuilder da Amen: Produtos > Importar/Exportar, ou crie um novo produto e use estes dados. Confirme preço, fotografias e visibilidade antes de Publicar.\n";
            zipText(zip, "README.txt", readme);
        }
    }

    private void publishStoreListingNative(String payload, String publisherUrl) {
        new Thread(() -> {
            JSONObject out = new JSONObject();
            try {
                URL url = new URL(publisherUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Accept", "application/json");
                byte[] body = (payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }
                int status = conn.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
                String response = stream == null ? "" : new String(stream.readAllBytes(), StandardCharsets.UTF_8);
                if (status >= 200 && status < 300) {
                    out.put("ok", true);
                    try {
                        JSONObject remote = new JSONObject(response);
                        if (remote.has("productId")) out.put("productId", remote.optString("productId"));
                        if (remote.has("productUrl")) out.put("productUrl", remote.optString("productUrl"));
                    } catch (Exception ignored) { }
                } else {
                    out.put("ok", false);
                    out.put("error", "Publisher respondeu HTTP " + status + (response.isEmpty() ? "" : ": " + response.substring(0, Math.min(240, response.length()))));
                }
                conn.disconnect();
            } catch (Exception e) {
                try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha na publicação." : e.getMessage()); } catch (Exception ignored) { }
            }
            evaluateJavascriptCallback("window.Mobiway.receiveStorePublish", out);
        }).start();
    }

    private Uri writeIntegrationPayload(String prefix, String payload) {
        try {
            File dir = new File(getCacheDir(), "integration");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile(prefix, ".json", dir);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write((payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8));
            }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readIntegrationPayload(Intent intent, String uriKey) {
        if (intent == null) return "";
        try {
            Uri uri = intent.getParcelableExtra(uriKey);
            if (uri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return "";
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            return "";
        }
    }


    private static class PlateCandidate {
        final String plate;
        final int corrections;
        PlateCandidate(String plate, int corrections) {
            this.plate = plate;
            this.corrections = corrections;
        }
    }

    private static Character asLetter(char c) {
        c = Character.toUpperCase(c);
        if (c >= 'A' && c <= 'Z') return c;
        switch (c) {
            case '0': return 'O';
            case '1': return 'I';
            case '2': return 'Z';
            case '4': return 'A';
            case '5': return 'S';
            case '6': return 'G';
            case '8': return 'B';
            default: return null;
        }
    }

    private static Character asDigit(char c) {
        c = Character.toUpperCase(c);
        if (c >= '0' && c <= '9') return c;
        switch (c) {
            case 'O': case 'Q': case 'D': return '0';
            case 'I': case 'L': return '1';
            case 'Z': return '2';
            case 'A': return '4';
            case 'S': return '5';
            case 'G': return '6';
            case 'B': return '8';
            default: return null;
        }
    }

    private static PlateCandidate applyPlateMask(String raw, String mask) {
        if (raw == null || raw.length() != 6 || mask.length() != 6) return null;
        StringBuilder out = new StringBuilder(6);
        int corrections = 0;
        for (int i = 0; i < 6; i++) {
            char source = Character.toUpperCase(raw.charAt(i));
            Character mapped;
            if (mask.charAt(i) == 'L') {
                mapped = asLetter(source);
                if (mapped == null) return null;
                if (!(source >= 'A' && source <= 'Z')) corrections++;
            } else {
                mapped = asDigit(source);
                if (mapped == null) return null;
                if (!(source >= '0' && source <= '9')) corrections++;
            }
            out.append(mapped);
        }
        if (corrections > 2) return null;
        String c = out.toString();
        return new PlateCandidate(c.substring(0,2) + "-" + c.substring(2,4) + "-" + c.substring(4,6), corrections);
    }

    private static PlateCandidate findPortugalPlate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        java.util.regex.Pattern token = java.util.regex.Pattern.compile(
            "(?i)(?<![A-Z0-9])([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})\\s*[-. ]?\\s*([A-Z0-9]{2})(?![A-Z0-9])"
        );
        java.util.regex.Matcher m = token.matcher(text.toUpperCase(java.util.Locale.ROOT));
        PlateCandidate best = null;
        String[] masks = {"LLDDLL", "LLDDDD", "DDLLDD", "DDDDLL"};
        while (m.find()) {
            String raw = (m.group(1) + m.group(2) + m.group(3)).replaceAll("[^A-Z0-9]", "");
            for (String mask : masks) {
                PlateCandidate c = applyPlateMask(raw, mask);
                if (c != null && (best == null || c.corrections < best.corrections)) best = c;
            }
        }
        return best;
    }

    private void evaluateJavascriptCallback(String functionName, JSONObject payload) {
        final String js = "if(typeof " + functionName + "==='function'){" + functionName + "(" + JSONObject.quote(payload.toString()) + ");}";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void recognizePlateNative(String dataUrl, String callbackFunction) {
        try {
            if (dataUrl == null || dataUrl.trim().isEmpty()) throw new IllegalArgumentException("Imagem vazia");
            int comma = dataUrl.indexOf(',');
            String b64 = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível abrir a fotografia");
            com.google.mlkit.vision.common.InputImage image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.TextRecognizer recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
            );
            recognizer.process(image)
                .addOnSuccessListener(result -> {
                    JSONObject out = new JSONObject();
                    try {
                        PlateCandidate candidate = findPortugalPlate(result.getText());
                        if (candidate == null) {
                            out.put("ok", false);
                            out.put("error", "Não foi possível reconhecer uma matrícula portuguesa na fotografia.");
                        } else {
                            out.put("ok", true);
                            out.put("plate", candidate.plate);
                            out.put("confidence", Math.max(75, 99 - candidate.corrections * 9));
                            out.put("corrections", candidate.corrections);
                        }
                    } catch (Exception e) {
                        try { out.put("ok", false); out.put("error", "Erro ao interpretar a matrícula."); } catch (Exception ignored) { }
                    }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                })
                .addOnFailureListener(e -> {
                    JSONObject out = new JSONObject();
                    try { out.put("ok", false); out.put("error", "Falha na leitura OCR: " + (e.getMessage() == null ? "erro desconhecido" : e.getMessage())); } catch (Exception ignored) { }
                    evaluateJavascriptCallback(callbackFunction, out);
                    recognizer.close();
                    bitmap.recycle();
                });
        } catch (Exception e) {
            JSONObject out = new JSONObject();
            try { out.put("ok", false); out.put("error", e.getMessage() == null ? "Falha ao preparar a fotografia." : e.getMessage()); } catch (Exception ignored) { }
            evaluateJavascriptCallback(callbackFunction, out);
        }
    }

    private static String nodeText(org.w3c.dom.Document doc, String localName) {
        org.w3c.dom.NodeList nodes = doc.getElementsByTagNameNS("*", localName);
        if (nodes.getLength() == 0) nodes = doc.getElementsByTagName(localName);
        if (nodes.getLength() == 0 || nodes.item(0) == null) return "";
        return nodes.item(0).getTextContent() == null ? "" : nodes.item(0).getTextContent().trim();
    }

    private void lookupPortugalVehicleNative(String plate, String username, String callbackFunction) {
        final String cleanPlate = plate == null ? "" : plate.trim().toUpperCase(java.util.Locale.ROOT);
        final String cleanUser = username == null ? "" : username.trim();
        new Thread(() -> {
            JSONObject out = new JSONObject();
            java.net.HttpURLConnection conn = null;
            try {
                if (cleanPlate.isEmpty()) throw new IllegalArgumentException("Indica uma matrícula.");
                if (cleanUser.isEmpty()) throw new IllegalArgumentException("Configura o utilizador Matricula/RegCheck nas definições.");
                java.net.URL url = new java.net.URL("https://www.matricula.co.pt/api/reg.asmx/CheckPortugal");
                conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(20000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                conn.setRequestProperty("Accept", "application/xml,text/xml,*/*");
                String body = "RegistrationNumber=" + java.net.URLEncoder.encode(cleanPlate.replace("-", ""), "UTF-8") +
                    "&username=" + java.net.URLEncoder.encode(cleanUser, "UTF-8");
                byte[] bodyBytes = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(bodyBytes.length);
                try (java.io.OutputStream os = conn.getOutputStream()) { os.write(bodyBytes); }
                int status = conn.getResponseCode();
                java.io.InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
                if (stream == null) throw new java.io.IOException("Resposta vazia do serviço de matrícula.");
                javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                factory.setNamespaceAware(true);
                try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) { }
                try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) { }
                try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) { }
                org.w3c.dom.Document doc = factory.newDocumentBuilder().parse(stream);
                String vehicleJson = nodeText(doc, "vehicleJson");
                if (status < 200 || status >= 300) throw new java.io.IOException("Serviço de matrícula respondeu HTTP " + status + ".");
                if (vehicleJson.isEmpty()) throw new java.io.IOException("O serviço não devolveu dados para esta matrícula.");
                JSONObject vehicle = new JSONObject(vehicleJson);
                String providerError = vehicle.optString("Error", vehicle.optString("error", "")).trim();
                if (!providerError.isEmpty()) throw new java.io.IOException(providerError);
                out.put("ok", true);
                out.put("plate", cleanPlate);
                out.put("provider", "Matricula.co.pt / RegCheck");
                out.put("data", vehicle);
            } catch (Exception e) {
                try {
                    out.put("ok", false);
                    out.put("plate", cleanPlate);
                    out.put("error", e.getMessage() == null ? "Falha na consulta da matrícula." : e.getMessage());
                } catch (Exception ignored) { }
            } finally {
                if (conn != null) conn.disconnect();
            }
            evaluateJavascriptCallback(callbackFunction, out);
        }, "MobiwayPlateLookup").start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(9, 10, 12));
        getWindow().setNavigationBarColor(Color.rgb(9, 10, 12));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 10, 12));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void recognizePlate(String dataUrl) {
                recognizePlateNative(dataUrl, "window.Mobiway.receivePlateScan");
            }

            @JavascriptInterface
            public void lookupPortugalVehicle(String plate, String username) {
                lookupPortugalVehicleNative(plate, username, "window.Mobiway.receiveVehicleLookup");
            }

            @JavascriptInterface
            public void printPdf() {
                runOnUiThread(() -> createPrintJob());
            }

            @JavascriptInterface
            public void exportBackup(String fileName, String json) {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupFileName = (fileName == null || fileName.trim().isEmpty())
                    ? "mobiway-avalia-backup.json" : fileName;
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFileName);
                        startActivityForResult(intent, BACKUP_EXPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void importBackup() {
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        startActivityForResult(intent, BACKUP_IMPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void exportStorePackage(String fileName, String json, String editorUrl) {
                pendingStorePackageJson = json == null ? "{}" : json;
                pendingStorePackageFileName = (fileName == null || fileName.trim().isEmpty()) ? "mobiway-shopbuilder.zip" : fileName;
                pendingStoreEditorUrl = (editorUrl == null || editorUrl.trim().isEmpty()) ? "https://www.amen.pt/" : editorUrl.trim();
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/zip");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingStorePackageFileName);
                        startActivityForResult(intent, STORE_EXPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void publishStoreListing(String json, String publisherUrl) {
                if (publisherUrl == null || publisherUrl.trim().isEmpty()) {
                    JSONObject out = new JSONObject();
                    try { out.put("ok", false); out.put("error", "Publisher/API não configurado."); } catch (Exception ignored) { }
                    evaluateJavascriptCallback("window.Mobiway.receiveStorePublish", out);
                    return;
                }
                publishStoreListingNative(json == null ? "{}" : json, publisherUrl.trim());
            }

            @JavascriptInterface
            public boolean openStoreEditor(String url) {
                try {
                    String target = (url == null || url.trim().isEmpty()) ? "https://www.amen.pt/" : url.trim();
                    openExternal(Uri.parse(target));
                    return true;
                } catch (Exception ignored) { return false; }
            }

            @JavascriptInterface
            public String getRepairPayload() {
                Intent intent = getIntent();
                if (intent == null) return "";
                String payload = intent.getStringExtra(EXTRA_REPAIR_VEHICLE);
                if (payload != null && !payload.isEmpty()) return payload;
                return readIntegrationPayload(intent, EXTRA_REPAIR_PAYLOAD_URI);
            }

            @JavascriptInterface
            public void clearRepairPayload() {
                Intent intent = getIntent();
                if (intent != null) {
                    intent.removeExtra(EXTRA_REPAIR_VEHICLE);
                    intent.removeExtra(EXTRA_REPAIR_PAYLOAD_URI);
                }
            }

            @JavascriptInterface
            public boolean openRepair() {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                    if (launch == null) return false;
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }

            @JavascriptInterface
            public boolean returnToRepair(String resultJson) {
                final String payload = resultJson == null ? "{}" : resultJson;
                final Uri payloadUri = writeIntegrationPayload("avalia_to_repair_", payload);
                try {
                    Intent launch = new Intent();
                    launch.setClassName("pt.mobiway.repair", "pt.mobiway.repair.MainActivity");
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (payloadUri != null) {
                        launch.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                        launch.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                        launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else if (payload.length() < 300000) {
                        launch.putExtra(EXTRA_AVALIA_RESULT, payload);
                    }
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                        if (fallback == null) return false;
                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        if (payloadUri != null) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                            fallback.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } else if (payload.length() < 300000) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT, payload);
                        }
                        fallback.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                        startActivity(fallback);
                        return true;
                    } catch (Exception ignored) {
                        return false;
                    }
                }
            }
        }, "AndroidBridge");
        webView.addJavascriptInterface(new MobiwayCloudBridge(this, webView, "avalia"), "MobiwayCloud");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                    "window.print=function(){if(window.AndroidBridge&&AndroidBridge.printPdf){AndroidBridge.printPdf();}};",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }

                fileCallback = callback;

                boolean capturePreferred =
                    params != null && params.isCaptureEnabled();

                launchChooser(capturePreferred);
                return true;
            }

            @Override
            public boolean onCreateWindow(
                    WebView view,
                    boolean isDialog,
                    boolean isUserGesture,
                    android.os.Message resultMsg) {

                WebView temp = new WebView(MainActivity.this);

                temp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView v,
                            WebResourceRequest req) {
                        openExternal(req.getUrl());
                        return true;
                    }
                });

                WebView.WebViewTransport transport =
                    (WebView.WebViewTransport) resultMsg.obj;

                transport.setWebView(temp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                new String[]{Manifest.permission.CAMERA},
                CAMERA_PERMISSION
            );
        }

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void launchChooser(boolean capturePreferred) {
        cameraRequest = capturePreferred;

        if (capturePreferred) {
            launchCamera();
            return;
        }

        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        gallery.addCategory(Intent.CATEGORY_OPENABLE);
        gallery.setType("image/*");
        gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        gallery.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(gallery, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {

            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType("image/*");
            fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

            try {
                startActivityForResult(
                    Intent.createChooser(
                        fallback,
                        "Fotografias da viatura"
                    ),
                    FILE_CHOOSER
                );

            } catch (ActivityNotFoundException ignored) {
                finishFileChooser(null);
            }
        }
    }

    private void launchCamera() {
        Intent camera =
            new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        ContentValues values = new ContentValues();

        values.put(
            MediaStore.Images.Media.DISPLAY_NAME,
            "mobiway_" + System.currentTimeMillis() + ".jpg"
        );

        values.put(
            MediaStore.Images.Media.MIME_TYPE,
            "image/jpeg"
        );

        cameraUri =
            getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            );

        if (cameraUri != null) {
            camera.putExtra(
                MediaStore.EXTRA_OUTPUT,
                cameraUri
            );

            camera.addFlags(
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        }

        try {
            startActivityForResult(camera, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {
            finishFileChooser(null);
        }
    }

    private void createPrintJob() {
        if (webView == null) return;

        PrintManager printManager =
            (PrintManager) getSystemService(PRINT_SERVICE);

        if (printManager == null) return;

        PrintDocumentAdapter adapter =
            webView.createPrintDocumentAdapter(
                "MOBIWAY Avalia"
            );

        printManager.print(
            "MOBIWAY Avalia",
            adapter,
            new PrintAttributes.Builder().build()
        );
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(
                new Intent(Intent.ACTION_VIEW, uri)
            );
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
            requestCode,
            resultCode,
            data
        );

        if (requestCode == STORE_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out != null) writeStorePackage(out, pendingStorePackageJson);
                } catch (Exception ignored) { }
                final String editor = pendingStoreEditorUrl;
                if (editor != null && !editor.trim().isEmpty()) runOnUiThread(() -> openExternal(Uri.parse(editor)));
            }
            return;
        }

        if (requestCode == BACKUP_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out != null) out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode == BACKUP_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in != null) {
                        byte[] bytes = in.readAllBytes();
                        String json = new String(bytes, StandardCharsets.UTF_8);
                        String js = "if(window.Mobiway&&Mobiway.receiveNativeBackup){Mobiway.receiveNativeBackup(" + JSONObject.quote(json) + ");}";
                        webView.post(() -> webView.evaluateJavascript(js, null));
                    }
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode != FILE_CHOOSER ||
                fileCallback == null) {
            return;
        }

        if (resultCode != RESULT_OK) {
            finishFileChooser(null);
            return;
        }

        List<Uri> uris = new ArrayList<>();

        if (data != null) {

            ClipData clipData = data.getClipData();

            if (clipData != null) {

                for (int i = 0;
                     i < clipData.getItemCount();
                     i++) {

                    Uri uri =
                        clipData.getItemAt(i).getUri();

                    if (uri != null) {
                        uris.add(uri);
                    }
                }

            } else if (data.getData() != null) {

                uris.add(data.getData());
            }
        }

        if (uris.isEmpty() &&
                cameraRequest &&
                cameraUri != null) {

            uris.add(cameraUri);
        }

        finishFileChooser(
            uris.isEmpty()
                ? null
                : uris.toArray(new Uri[0])
        );
    }

    private void finishFileChooser(Uri[] result) {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }

        cameraUri = null;
        cameraRequest = false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        if (webView != null) {
            webView.post(() -> webView.reload());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null &&
                webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
