# Ativação rápida — MOBIWAY Cloud v0.2

## 1. Criar/usar o projeto Firebase

Usar um único projeto para Avalia, Repair e Hub.

Código de empresa recomendado: `mobiway`

## 2. Authentication

Firebase Console > Authentication > Sign-in method > Email/Password > Enable.

Não criar uma conta partilhada. Cada colaborador deve ter a sua conta.

## 3. Firestore

Criar Cloud Firestore e substituir as regras pelo conteúdo de `FIRESTORE.rules`.

Não criar manualmente a coleção `companies`: a primeira app autenticada faz o bootstrap e cria o proprietário.

## 4. Storage

Criar Cloud Storage e substituir as regras pelo conteúdo de `STORAGE.rules`.

As regras de Storage consultam `companies/{companyId}/members/{uid}` no Firestore. A primeira publicação pode pedir autorização para permitir essa integração.

## 5. Dados que a app pede

No ecrã MOBIWAY Cloud indicar:

- Empresa: `mobiway`
- Project ID
- API Key
- Application ID
- Storage Bucket

## 6. Primeiro equipamento

1. Abrir MOBIWAY Cloud.
2. Criar conta com o email do Proprietário.
3. Indicar nome e nome do equipamento.
4. Tocar em **Inicializar MOBIWAY Cloud como Proprietário**.
5. Confirmar estado `☁ CLOUD`.

## 7. Equipamentos seguintes

1. Configurar o mesmo Firebase.
2. Criar conta individual.
3. Tocar em **Pedir acesso**.
4. No equipamento do Proprietário: MOBIWAY Cloud > Gerir utilizadores e equipamentos.
5. Atribuir perfil e aprovar.

## 8. Perfis

- Proprietário: tudo.
- Administrador: tudo exceto substituir/desativar o Proprietário.
- Compras/Avalia: escrita em Avalia e viaturas.
- Oficina/Repair: escrita em Repair e viaturas.
- Vendas: escrita em viaturas; consulta das restantes coleções.
- Consulta: leitura.

## 9. Revogação

Desativar **Utilizador** = bloqueio Cloud efetivo da conta.
Desativar **Equipamento** = bloqueio operacional na app oficial; não deve substituir a desativação do utilizador quando é necessário revogar acesso de segurança.
