package pt.mobiway.repair;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MobiwayCloudBridge {
    private static final String PREFS = "mobiway_cloud";

    private final Activity activity;
    private final WebView webView;
    private final String module;
    private final SharedPreferences prefs;
    private final Map<String, ListenerRegistration> listeners = new HashMap<>();

    private FirebaseApp firebaseApp;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private String companyId = "mobiway";

    // Cached access state. Firestore Security Rules remain the source of truth.
    private boolean companyExists = false;
    private String companyName = "MOBIWAY";
    private String companyOwnerUid = "";
    private boolean memberExists = false;
    private boolean memberActive = false;
    private String memberRole = "";
    private String memberDisplayName = "";
    private boolean deviceActive = false;

    public MobiwayCloudBridge(Activity activity, WebView webView, String module) {
        this.activity = activity;
        this.webView = webView;
        this.module = module;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        ensureDeviceLabel();
        initFromPreferences();
    }

    private void ensureDeviceLabel() {
        if (prefs.getString("deviceLabel", "").trim().isEmpty()) {
            String manufacturer = Build.MANUFACTURER == null ? "Android" : Build.MANUFACTURER.trim();
            String modelName = Build.MODEL == null ? "Equipamento" : Build.MODEL.trim();
            String label = (manufacturer + " " + modelName).trim();
            prefs.edit().putString("deviceLabel", label.isEmpty() ? "Equipamento Android" : label).apply();
        }
    }

    private void initFromPreferences() {
        companyId = safeCompany(prefs.getString("companyId", "mobiway"));
        // Firebase configuration is bundled with the APK via google-services.json.
        // Remove legacy manual keys so an old device configuration cannot override this build.
        prefs.edit().remove("apiKey").remove("applicationId").remove("projectId").remove("storageBucket").apply();
        initializeFromResources();
    }

    private boolean initializeFromResources() {
        try {
            firebaseApp = FirebaseApp.initializeApp(activity);
            if (firebaseApp == null) firebaseApp = FirebaseApp.getInstance();
            auth = FirebaseAuth.getInstance(firebaseApp);
            db = FirebaseFirestore.getInstance(firebaseApp);
            storage = null;
            String bucket = firebaseApp.getOptions().getStorageBucket();
            if (bucket != null && !bucket.trim().isEmpty()) storage = FirebaseStorage.getInstance(firebaseApp);
            if (auth.getCurrentUser() != null) refreshAccessState();
            return true;
        } catch (Exception e) {
            fireError("CONFIG", "Configuração Firebase incorporada não disponível: " + e.getMessage());
            return false;
        }
    }

    private String safeCompany(String v) {
        String x = v == null ? "mobiway" : v.trim().toLowerCase().replaceAll("[^a-z0-9_-]", "-");
        return x.isEmpty() ? "mobiway" : x;
    }

    private String safeRole(String role) {
        String r = role == null ? "viewer" : role.trim().toLowerCase();
        if ("admin".equals(r) || "buyer".equals(r) || "workshop".equals(r) || "sales".equals(r) || "viewer".equals(r)) return r;
        return "viewer";
    }

    private String suggestedRole() {
        return "repair".equals(module) ? "workshop" : "buyer";
    }

    private String getAppVersion() {
        try {
            return activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionName;
        } catch (Exception ignored) { return ""; }
    }

    @JavascriptInterface
    public boolean configure(String json) {
        // Kept for backwards compatibility with older web assets.
        // Firebase project credentials are bundled in the APK and are no longer entered by the user.
        try {
            JSONObject c = new JSONObject(json == null ? "{}" : json);
            companyId = safeCompany(c.optString("companyId", companyId));
            prefs.edit().putString("companyId", companyId).apply();
            boolean ok = initializeFromResources();
            fireStatus();
            return ok;
        } catch (Exception e) {
            fireError("CONFIG", e.getMessage());
            return false;
        }
    }

    @JavascriptInterface
    public String getStatus() {
        JSONObject o = new JSONObject();
        try {
            FirebaseUser u = auth == null ? null : auth.getCurrentUser();
            o.put("configured", db != null && auth != null);
            o.put("signedIn", u != null);
            o.put("email", u != null && u.getEmail() != null ? u.getEmail() : "");
            o.put("uid", u != null ? u.getUid() : "");
            o.put("companyId", companyId);
            o.put("companyExists", companyExists);
            o.put("companyName", companyName);
            o.put("companyOwnerUid", companyOwnerUid);
            o.put("memberExists", memberExists);
            o.put("memberActive", memberActive);
            o.put("role", memberRole);
            o.put("displayName", memberDisplayName);
            o.put("module", module);
            o.put("moduleMode", moduleMode());
            o.put("deviceId", getDeviceId());
            o.put("deviceLabel", prefs.getString("deviceLabel", "Equipamento Android"));
            o.put("deviceActive", deviceActive);
            o.put("appVersion", getAppVersion());
            o.put("projectId", firebaseApp != null && firebaseApp.getOptions().getProjectId() != null ? firebaseApp.getOptions().getProjectId() : "");
            o.put("storageBucket", firebaseApp != null && firebaseApp.getOptions().getStorageBucket() != null ? firebaseApp.getOptions().getStorageBucket() : "");
            o.put("manager", isManager());
        } catch (Exception ignored) {}
        return o.toString();
    }

    @JavascriptInterface
    public void refresh() { refreshAccessState(); }

    @JavascriptInterface
    public void signIn(String email, String password) {
        if (auth == null) { fireError("AUTH", "MOBIWAY Cloud ainda não configurada."); return; }
        auth.signInWithEmailAndPassword(email == null ? "" : email.trim(), password == null ? "" : password)
            .addOnSuccessListener(r -> refreshAccessState())
            .addOnFailureListener(e -> fireError("AUTH", e.getMessage()));
    }

    @JavascriptInterface
    public void createAccount(String email, String password) {
        if (auth == null) { fireError("AUTH", "MOBIWAY Cloud ainda não configurada."); return; }
        auth.createUserWithEmailAndPassword(email == null ? "" : email.trim(), password == null ? "" : password)
            .addOnSuccessListener(r -> refreshAccessState())
            .addOnFailureListener(e -> fireError("AUTH", e.getMessage()));
    }

    @JavascriptInterface
    public void sendPasswordReset(String email) {
        if (auth == null) { fireError("AUTH", "MOBIWAY Cloud ainda não configurada."); return; }
        String e = email == null ? "" : email.trim();
        if (e.isEmpty()) { fireError("AUTH", "Indica o email da conta."); return; }
        auth.sendPasswordResetEmail(e)
            .addOnSuccessListener(v -> fireMessage("RESET_SENT", "Email de recuperação enviado."))
            .addOnFailureListener(err -> fireError("AUTH", err.getMessage()));
    }

    @JavascriptInterface
    public void signOut() {
        if (auth != null) auth.signOut();
        stopAllListeners();
        resetAccessState();
        fireStatus();
    }

    @JavascriptInterface
    public void bootstrapCompany(String displayName, String deviceLabel) {
        FirebaseUser u = currentUserOrError();
        if (u == null || db == null) return;
        saveDeviceLabel(deviceLabel);
        DocumentReference company = companyRef();
        company.get().addOnSuccessListener(doc -> {
            if (doc.exists()) {
                String owner = doc.getString("ownerUid");
                if (!u.getUid().equals(owner)) {
                    fireError("ACCESS", "A MOBIWAY Cloud já está inicializada. Pede acesso ao administrador.");
                    refreshAccessState();
                    return;
                }
                ensureOwnerMember(displayName);
                return;
            }
            Map<String, Object> c = new HashMap<>();
            c.put("name", "MOBIWAY");
            c.put("ownerUid", u.getUid());
            c.put("schemaVersion", 2);
            c.put("createdAt", FieldValue.serverTimestamp());
            c.put("updatedAt", FieldValue.serverTimestamp());
            company.set(c).addOnSuccessListener(v -> ensureOwnerMember(displayName))
                .addOnFailureListener(e -> fireError("ACCESS", e.getMessage()));
        }).addOnFailureListener(e -> fireError("ACCESS", e.getMessage()));
    }

    private void ensureOwnerMember(String displayName) {
        FirebaseUser u = auth == null ? null : auth.getCurrentUser();
        if (u == null) return;
        Map<String, Object> m = new HashMap<>();
        m.put("uid", u.getUid());
        m.put("email", u.getEmail() == null ? "" : u.getEmail());
        m.put("displayName", cleanName(displayName));
        m.put("role", "owner");
        m.put("active", true);
        m.put("createdAt", FieldValue.serverTimestamp());
        m.put("updatedAt", FieldValue.serverTimestamp());
        memberRef(u.getUid()).set(m, SetOptions.merge()).addOnSuccessListener(v -> {
            refreshAccessState();
            appendAudit("company_bootstrap", "company", companyId, "Primeiro proprietário configurado");
        }).addOnFailureListener(e -> fireError("ACCESS", e.getMessage()));
    }

    @JavascriptInterface
    public void requestAccess(String displayName, String deviceLabel) {
        FirebaseUser u = currentUserOrError();
        if (u == null || db == null) return;
        saveDeviceLabel(deviceLabel);
        Map<String, Object> r = new HashMap<>();
        r.put("uid", u.getUid());
        r.put("email", u.getEmail() == null ? "" : u.getEmail());
        r.put("displayName", cleanName(displayName));
        r.put("module", module);
        r.put("requestedRole", suggestedRole());
        r.put("deviceId", getDeviceId());
        r.put("deviceLabel", prefs.getString("deviceLabel", "Equipamento Android"));
        r.put("appVersion", getAppVersion());
        r.put("status", "pending");
        r.put("requestedAt", FieldValue.serverTimestamp());
        r.put("updatedAt", FieldValue.serverTimestamp());
        accessRequestRef(u.getUid()).set(r, SetOptions.merge())
            .addOnSuccessListener(v -> { fireMessage("ACCESS_REQUESTED", "Pedido de acesso enviado."); refreshAccessState(); })
            .addOnFailureListener(e -> fireError("ACCESS", e.getMessage()));
    }

    @JavascriptInterface
    public void setDeviceLabel(String label) {
        saveDeviceLabel(label);
        if (memberActive) registerDeviceInternal(true);
        else fireStatus();
    }

    private void saveDeviceLabel(String label) {
        String x = label == null ? "" : label.trim();
        if (!x.isEmpty()) prefs.edit().putString("deviceLabel", x).apply();
    }

    private String cleanName(String name) {
        String x = name == null ? "" : name.trim();
        if (x.length() > 80) x = x.substring(0, 80);
        return x;
    }

    @JavascriptInterface
    public void getAdminData() {
        if (!isManager() || db == null) { fireError("ACCESS", "Apenas Proprietário ou Administrador."); return; }
        db.collection("companies").document(companyId).collection("accessRequests").get()
            .addOnSuccessListener(reqs -> db.collection("companies").document(companyId).collection("members").get()
                .addOnSuccessListener(members -> db.collection("companies").document(companyId).collection("devices").get()
                    .addOnSuccessListener(devices -> {
                        JSONObject out = new JSONObject();
                        JSONArray aReq = new JSONArray();
                        JSONArray aMem = new JSONArray();
                        JSONArray aDev = new JSONArray();
                        try {
                            for (DocumentSnapshot d : reqs.getDocuments()) aReq.put(requestJson(d));
                            for (DocumentSnapshot d : members.getDocuments()) aMem.put(memberJson(d));
                            for (DocumentSnapshot d : devices.getDocuments()) aDev.put(deviceJson(d));
                            out.put("requests", aReq); out.put("members", aMem); out.put("devices", aDev);
                        } catch (Exception ignored) {}
                        callJs("window.MobiwayCloudEvents&&MobiwayCloudEvents.onAdminData(" + JSONObject.quote(out.toString()) + ");");
                    }).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()))
                ).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()))
            ).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()));
    }

    private JSONObject requestJson(DocumentSnapshot d) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("uid", d.getId());
        o.put("email", nvl(d.getString("email")));
        o.put("displayName", nvl(d.getString("displayName")));
        o.put("module", nvl(d.getString("module")));
        o.put("requestedRole", nvl(d.getString("requestedRole")));
        o.put("deviceLabel", nvl(d.getString("deviceLabel")));
        o.put("status", nvl(d.getString("status")));
        return o;
    }

    private JSONObject memberJson(DocumentSnapshot d) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("uid", d.getId());
        o.put("email", nvl(d.getString("email")));
        o.put("displayName", nvl(d.getString("displayName")));
        o.put("role", nvl(d.getString("role")));
        o.put("active", Boolean.TRUE.equals(d.getBoolean("active")));
        return o;
    }

    private JSONObject deviceJson(DocumentSnapshot d) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", d.getId());
        o.put("uid", nvl(d.getString("uid")));
        o.put("email", nvl(d.getString("email")));
        o.put("label", nvl(d.getString("label")));
        o.put("module", nvl(d.getString("module")));
        o.put("appVersion", nvl(d.getString("appVersion")));
        o.put("active", !Boolean.FALSE.equals(d.getBoolean("active")));
        Object t = d.get("lastSeenAt");
        o.put("lastSeenAt", t == null ? "" : String.valueOf(t));
        return o;
    }

    private String nvl(String s) { return s == null ? "" : s; }

    @JavascriptInterface
    public void approveAccess(String targetUid, String role) {
        FirebaseUser u = currentUserOrError();
        if (u == null || !isManager() || db == null) { fireError("ACCESS", "Apenas Proprietário ou Administrador."); return; }
        final String uid = targetUid == null ? "" : targetUid.trim();
        if (uid.isEmpty()) return;
        final String safe = safeRole(role);
        accessRequestRef(uid).get().addOnSuccessListener(req -> {
            if (!req.exists()) { fireError("ADMIN", "Pedido de acesso não encontrado."); return; }
            Map<String, Object> m = new HashMap<>();
            m.put("uid", uid);
            m.put("email", nvl(req.getString("email")));
            m.put("displayName", nvl(req.getString("displayName")));
            m.put("role", safe);
            m.put("active", true);
            m.put("approvedBy", u.getUid());
            m.put("createdAt", FieldValue.serverTimestamp());
            m.put("updatedAt", FieldValue.serverTimestamp());
            WriteBatch batch = db.batch();
            batch.set(memberRef(uid), m, SetOptions.merge());
            Map<String, Object> rq = new HashMap<>();
            rq.put("status", "approved");
            rq.put("approvedRole", safe);
            rq.put("approvedBy", u.getUid());
            rq.put("updatedAt", FieldValue.serverTimestamp());
            batch.set(accessRequestRef(uid), rq, SetOptions.merge());
            batch.commit().addOnSuccessListener(v -> {
                appendAudit("access_approved", "member", uid, safe);
                fireMessage("ACCESS_APPROVED", "Acesso aprovado.");
                getAdminData();
            }).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()));
        }).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()));
    }

    @JavascriptInterface
    public void updateMember(String targetUid, String role, boolean active) {
        FirebaseUser u = currentUserOrError();
        if (u == null || !isManager() || db == null) { fireError("ACCESS", "Apenas Proprietário ou Administrador."); return; }
        String uid = targetUid == null ? "" : targetUid.trim();
        if (uid.isEmpty()) return;
        if (uid.equals(companyOwnerUid)) { fireError("ADMIN", "O Proprietário não pode ser desativado por aqui."); return; }
        Map<String, Object> m = new HashMap<>();
        m.put("role", safeRole(role));
        m.put("active", active);
        m.put("updatedAt", FieldValue.serverTimestamp());
        m.put("updatedBy", u.getUid());
        memberRef(uid).set(m, SetOptions.merge()).addOnSuccessListener(v -> {
            appendAudit("member_updated", "member", uid, safeRole(role) + ":" + active);
            getAdminData();
        }).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()));
    }

    @JavascriptInterface
    public void setDeviceActive(String deviceId, boolean active) {
        FirebaseUser u = currentUserOrError();
        if (u == null || !isManager() || db == null) { fireError("ACCESS", "Apenas Proprietário ou Administrador."); return; }
        String id = deviceId == null ? "" : deviceId.trim();
        if (id.isEmpty()) return;
        Map<String, Object> d = new HashMap<>();
        d.put("active", active);
        d.put("updatedAt", FieldValue.serverTimestamp());
        d.put("updatedBy", u.getUid());
        deviceRef(id).set(d, SetOptions.merge()).addOnSuccessListener(v -> {
            appendAudit("device_updated", "device", id, String.valueOf(active));
            if (id.equals(getDeviceId())) refreshAccessState();
            getAdminData();
        }).addOnFailureListener(e -> fireError("ADMIN", e.getMessage()));
    }

    @JavascriptInterface
    public void upsertRecord(String collection, String id, String recordJson) {
        if (!ready()) return;
        if (!safeCollection(collection) || id == null || id.trim().isEmpty()) return;
        if (!canWriteCollection(collection)) { fireError("ACCESS", "O teu perfil tem acesso de leitura a este módulo."); return; }
        try {
            JSONObject payload = new JSONObject(recordJson == null ? "{}" : recordJson);
            List<MediaRef> media = new ArrayList<>();
            collectMedia(payload, media);
            uploadMediaSequential(collection, id, payload, media, 0);
        } catch (Exception e) {
            fireError("SYNC", e.getMessage());
        }
    }

    private void uploadMediaSequential(String collection, String id, JSONObject payload, List<MediaRef> media, int index) {
        if (index >= media.size()) { writeDocument(collection, id, payload); return; }
        MediaRef ref = media.get(index);
        if (storage == null) { fireError("MEDIA", "Cloud Storage não configurado."); return; }
        try {
            String dataUri = ref.value;
            int comma = dataUri.indexOf(',');
            if (comma < 0) { uploadMediaSequential(collection, id, payload, media, index + 1); return; }
            String header = dataUri.substring(0, comma).toLowerCase();
            String mime = header.contains("image/png") ? "image/png" : "image/jpeg";
            String ext = mime.equals("image/png") ? "png" : "jpg";
            byte[] bytes = Base64.decode(dataUri.substring(comma + 1), Base64.DEFAULT);
            String path = "companies/" + companyId + "/" + collection + "/" + id + "/media/" + index + "." + ext;
            StorageReference sr = storage.getReference().child(path);
            StorageMetadata md = new StorageMetadata.Builder().setContentType(mime).build();
            sr.putBytes(bytes, md)
                .continueWithTask(t -> {
                    if (!t.isSuccessful()) throw t.getException() == null ? new RuntimeException("Upload falhou") : t.getException();
                    return sr.getDownloadUrl();
                })
                .addOnSuccessListener(uri -> {
                    try { ref.set(uri.toString()); } catch (Exception ignored) {}
                    uploadMediaSequential(collection, id, payload, media, index + 1);
                })
                .addOnFailureListener(e -> fireError("MEDIA", e.getMessage()));
        } catch (Exception e) {
            fireError("MEDIA", e.getMessage());
        }
    }

    private void writeDocument(String collection, String id, JSONObject payload) {
        FirebaseUser u = auth == null ? null : auth.getCurrentUser();
        if (u == null) return;
        Map<String, Object> doc = new HashMap<>();
        doc.put("payload", payload.toString());
        doc.put("module", module);
        doc.put("deviceId", getDeviceId());
        doc.put("appVersion", getAppVersion());
        doc.put("updatedBy", u.getUid());
        doc.put("updatedAt", FieldValue.serverTimestamp());
        db.collection("companies").document(companyId).collection(collection).document(id).set(doc)
            .addOnFailureListener(e -> fireError("SYNC", e.getMessage()));
    }

    @JavascriptInterface
    public void deleteRecord(String collection, String id) {
        if (!ready() || !safeCollection(collection) || id == null || id.trim().isEmpty()) return;
        if (!canWriteCollection(collection)) { fireError("ACCESS", "O teu perfil tem acesso de leitura a este módulo."); return; }
        db.collection("companies").document(companyId).collection(collection).document(id).delete()
            .addOnSuccessListener(v -> appendAudit("record_deleted", collection, id, module))
            .addOnFailureListener(e -> fireError("DELETE", e.getMessage()));
    }

    @JavascriptInterface
    public void listen(String collection) {
        if (!ready() || !safeCollection(collection)) return;
        ListenerRegistration old = listeners.remove(collection);
        if (old != null) old.remove();
        ListenerRegistration reg = db.collection("companies").document(companyId).collection(collection)
            .addSnapshotListener((snapshot, error) -> {
                if (error != null) { fireError("LISTEN", error.getMessage()); return; }
                JSONArray rows = new JSONArray();
                if (snapshot != null) {
                    for (DocumentSnapshot d : snapshot.getDocuments()) {
                        String p = d.getString("payload");
                        if (p == null || p.isEmpty()) continue;
                        try {
                            JSONObject obj = new JSONObject(p);
                            if (!obj.has("id")) obj.put("id", d.getId());
                            rows.put(obj);
                        } catch (Exception ignored) {}
                    }
                }
                JSONObject result = new JSONObject();
                try {
                    result.put("collection", collection);
                    result.put("records", rows);
                    result.put("fromCache", snapshot != null && snapshot.getMetadata().isFromCache());
                } catch (JSONException ignored) {}
                callJs("window.MobiwayCloudEvents&&MobiwayCloudEvents.onCollection(" + JSONObject.quote(result.toString()) + ");");
            });
        listeners.put(collection, reg);
    }

    @JavascriptInterface
    public void stopAllListeners() {
        for (ListenerRegistration r : listeners.values()) if (r != null) r.remove();
        listeners.clear();
    }

    private void refreshAccessState() {
        if (db == null || auth == null || auth.getCurrentUser() == null) {
            resetAccessState(); fireStatus(); return;
        }
        FirebaseUser u = auth.getCurrentUser();
        companyRef().get().addOnSuccessListener(c -> {
            companyExists = c.exists();
            companyName = c.exists() ? nvl(c.getString("name")) : "MOBIWAY";
            if (companyName.isEmpty()) companyName = "MOBIWAY";
            companyOwnerUid = c.exists() ? nvl(c.getString("ownerUid")) : "";
            memberRef(u.getUid()).get().addOnSuccessListener(m -> {
                memberExists = m.exists();
                memberActive = m.exists() && Boolean.TRUE.equals(m.getBoolean("active"));
                memberRole = m.exists() ? nvl(m.getString("role")) : "";
                memberDisplayName = m.exists() ? nvl(m.getString("displayName")) : "";
                if (memberActive) registerDeviceInternal(false);
                else { deviceActive = false; stopAllListeners(); fireStatus(); }
            }).addOnFailureListener(e -> { resetMemberState(); fireStatus(); fireError("ACCESS", e.getMessage()); });
        }).addOnFailureListener(e -> {
            // A signed-in user may only be able to access their own access request until rules are deployed.
            companyExists = false; resetMemberState(); fireStatus(); fireError("ACCESS", e.getMessage());
        });
    }

    private void registerDeviceInternal(boolean fireAfter) {
        FirebaseUser u = auth == null ? null : auth.getCurrentUser();
        if (u == null || db == null || !memberActive) { deviceActive = false; if (fireAfter) fireStatus(); return; }
        DocumentReference ref = deviceRef(getDeviceId());
        ref.get().addOnSuccessListener(existing -> {
            if (existing.exists() && Boolean.FALSE.equals(existing.getBoolean("active"))) {
                deviceActive = false;
                stopAllListeners();
                fireStatus();
                return;
            }
            Map<String, Object> d = new HashMap<>();
            d.put("id", getDeviceId());
            d.put("uid", u.getUid());
            d.put("email", u.getEmail() == null ? "" : u.getEmail());
            d.put("label", prefs.getString("deviceLabel", "Equipamento Android"));
            d.put("module", module);
            d.put("platform", "android");
            d.put("appVersion", getAppVersion());
            d.put("active", true);
            d.put("lastSeenAt", FieldValue.serverTimestamp());
            if (!existing.exists()) d.put("createdAt", FieldValue.serverTimestamp());
            ref.set(d, SetOptions.merge()).addOnSuccessListener(v -> { deviceActive = true; fireStatus(); })
                .addOnFailureListener(e -> { deviceActive = false; fireStatus(); fireError("DEVICE", e.getMessage()); });
        }).addOnFailureListener(e -> { deviceActive = false; fireStatus(); fireError("DEVICE", e.getMessage()); });
    }

    private void resetAccessState() {
        companyExists = false; companyName = "MOBIWAY"; companyOwnerUid = ""; resetMemberState();
    }

    private void resetMemberState() {
        memberExists = false; memberActive = false; memberRole = ""; memberDisplayName = ""; deviceActive = false;
    }

    private boolean ready() {
        if (db == null || auth == null) { fireError("CONFIG", "MOBIWAY Cloud não configurada."); return false; }
        if (auth.getCurrentUser() == null) { fireError("AUTH", "Inicia sessão na MOBIWAY Cloud."); return false; }
        if (!memberActive) { fireError("ACCESS", "A tua conta ainda não tem acesso ativo à MOBIWAY Cloud."); return false; }
        if (!deviceActive) { fireError("DEVICE", "Este equipamento está desativado ou ainda não foi registado."); return false; }
        return true;
    }

    private boolean safeCollection(String v) {
        return "evaluations".equals(v) || "repairOrders".equals(v) || "vehicles".equals(v);
    }

    private boolean canWriteCollection(String collection) {
        if (!memberActive) return false;
        if ("owner".equals(memberRole) || "admin".equals(memberRole)) return true;
        if ("evaluations".equals(collection)) return "buyer".equals(memberRole);
        if ("repairOrders".equals(collection)) return "workshop".equals(memberRole);
        if ("vehicles".equals(collection)) return "buyer".equals(memberRole) || "workshop".equals(memberRole) || "sales".equals(memberRole);
        return false;
    }

    private String moduleMode() {
        if (!memberActive) return "blocked";
        String c = "repair".equals(module) ? "repairOrders" : "evaluations";
        return canWriteCollection(c) ? "edit" : "read";
    }

    private boolean isManager() {
        return memberActive && ("owner".equals(memberRole) || "admin".equals(memberRole));
    }

    private FirebaseUser currentUserOrError() {
        if (auth == null || auth.getCurrentUser() == null) { fireError("AUTH", "Inicia sessão na MOBIWAY Cloud."); return null; }
        return auth.getCurrentUser();
    }

    private DocumentReference companyRef() { return db.collection("companies").document(companyId); }
    private DocumentReference memberRef(String uid) { return companyRef().collection("members").document(uid); }
    private DocumentReference accessRequestRef(String uid) { return companyRef().collection("accessRequests").document(uid); }
    private DocumentReference deviceRef(String id) { return companyRef().collection("devices").document(id); }

    private String getDeviceId() {
        String id = prefs.getString("deviceId", "");
        if (id.isEmpty()) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString("deviceId", id).apply();
        }
        return id;
    }

    private void appendAudit(String action, String entityType, String entityId, String detail) {
        if (db == null || auth == null || auth.getCurrentUser() == null || !memberActive) return;
        Map<String, Object> a = new HashMap<>();
        a.put("action", action);
        a.put("entityType", entityType);
        a.put("entityId", entityId == null ? "" : entityId);
        a.put("detail", detail == null ? "" : detail);
        a.put("uid", auth.getCurrentUser().getUid());
        a.put("email", auth.getCurrentUser().getEmail() == null ? "" : auth.getCurrentUser().getEmail());
        a.put("role", memberRole);
        a.put("module", module);
        a.put("deviceId", getDeviceId());
        a.put("createdAt", FieldValue.serverTimestamp());
        companyRef().collection("audit").add(a);
    }

    private void fireStatus() {
        callJs("window.MobiwayCloudEvents&&MobiwayCloudEvents.onStatus(" + JSONObject.quote(getStatus()) + ");");
    }

    private void fireError(String code, String message) {
        JSONObject o = new JSONObject();
        try { o.put("code", code); o.put("message", message == null ? "Erro desconhecido" : message); } catch (Exception ignored) {}
        callJs("window.MobiwayCloudEvents&&MobiwayCloudEvents.onError(" + JSONObject.quote(o.toString()) + ");");
    }

    private void fireMessage(String code, String message) {
        JSONObject o = new JSONObject();
        try { o.put("code", code); o.put("message", message == null ? "" : message); } catch (Exception ignored) {}
        callJs("window.MobiwayCloudEvents&&MobiwayCloudEvents.onMessage(" + JSONObject.quote(o.toString()) + ");");
    }

    private void callJs(String js) { webView.post(() -> webView.evaluateJavascript(js, null)); }

    private void collectMedia(Object node, List<MediaRef> out) throws JSONException {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONArray names = o.names();
            if (names == null) return;
            for (int i = 0; i < names.length(); i++) {
                String key = names.getString(i);
                Object v = o.opt(key);
                if (v instanceof String && ((String)v).startsWith("data:image/")) out.add(new MediaRef(o, key, (String)v));
                else if (v instanceof JSONObject || v instanceof JSONArray) collectMedia(v, out);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                Object v = a.opt(i);
                if (v instanceof String && ((String)v).startsWith("data:image/")) out.add(new MediaRef(a, i, (String)v));
                else if (v instanceof JSONObject || v instanceof JSONArray) collectMedia(v, out);
            }
        }
    }

    private static class MediaRef {
        final JSONObject object; final JSONArray array; final String key; final int index; final String value;
        MediaRef(JSONObject o, String k, String v) { object=o; key=k; value=v; array=null; index=-1; }
        MediaRef(JSONArray a, int i, String v) { array=a; index=i; value=v; object=null; key=null; }
        void set(String value) throws JSONException { if (object != null) object.put(key, value); else array.put(index, value); }
    }
}
