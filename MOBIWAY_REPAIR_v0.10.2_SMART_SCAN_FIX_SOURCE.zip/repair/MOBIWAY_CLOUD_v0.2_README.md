# MOBIWAY Cloud v0.2 — Access & Devices

Base Cloud comum para MOBIWAY Avalia, MOBIWAY Repair e futuro MOBIWAY Hub.

## Apps base

- Avalia: `0.7.1-cloud-access`
- Repair: `0.8.1-cloud-access`
- Firebase Android BoM: `34.19.0`
- Android: minSdk 26 / targetSdk 35

## O que foi acrescentado na v0.2

1. **Conta individual por colaborador** através de Firebase Authentication (email + palavra-passe).
2. **Bootstrap seguro do primeiro proprietário**: se a empresa ainda não existir, a primeira conta autenticada cria `companies/mobiway` e fica com o perfil `owner`.
3. **Pedidos de acesso** para novos colaboradores/equipamentos.
4. **Aprovação pelo Proprietário/Administrador** sem partilha da conta principal.
5. **Perfis fixos**:
   - `owner` — Proprietário; acesso integral.
   - `admin` — Administrador; gestão e acesso integral aos módulos.
   - `buyer` — Compras/Avalia; edita Avalia e viaturas.
   - `workshop` — Oficina/Repair; edita Repair e viaturas.
   - `sales` — Vendas; edita viaturas e consulta os restantes dados.
   - `viewer` — Consulta; sem escrita Cloud.
6. **Registo automático de equipamentos** com ID único, nome, utilizador, módulo e versão da app.
7. **Gestão de equipamentos**: ativo/inativo e última utilização.
8. **Desativação de utilizadores**: bloqueia o acesso Cloud dessa conta em todos os equipamentos.
9. **Modo só de leitura** quando o perfil pode consultar um módulo, mas não alterá-lo.
10. **Auditoria** de aprovações, alterações de membros, equipamentos e eliminações.
11. **Recuperação de palavra-passe** por email.
12. **Security Rules por função**, com bloqueio por defeito de coleções não previstas.
13. **Cloud Storage protegido pelos perfis Firestore**, com limite de 15 MB por imagem.

## Estrutura Firestore

```text
companies/{companyId}
  ownerUid
  name
  schemaVersion

  members/{uid}
    email
    displayName
    role
    active

  accessRequests/{uid}
    email
    displayName
    module
    requestedRole
    deviceId
    deviceLabel
    status

  devices/{deviceId}
    uid
    email
    label
    module
    platform
    appVersion
    active
    lastSeenAt

  evaluations/{evaluationId}
  repairOrders/{repairOrderId}
  vehicles/{vehicleId}
  audit/{eventId}
```

## Fluxo de entrada de um novo equipamento

1. Instalar Avalia ou Repair Cloud.
2. Configurar o mesmo projeto Firebase/empresa `mobiway`.
3. Criar uma conta individual ou iniciar sessão.
4. Se for a primeira conta, escolher **Inicializar MOBIWAY Cloud como Proprietário**.
5. Nos equipamentos seguintes, escolher **Pedir acesso**.
6. No equipamento do Proprietário/Administrador, abrir **MOBIWAY Cloud > Gerir utilizadores e equipamentos**.
7. Selecionar o perfil e aprovar.
8. O novo equipamento carrega o perfil e começa a sincronizar.

## Regra operacional importante

Não partilhar a mesma conta entre colaboradores. O registo de equipamento permite gestão operacional, mas o bloqueio de segurança forte é feito ao nível do utilizador. Para cortar imediatamente o acesso de uma pessoa em todos os seus equipamentos, desativar o respetivo membro.

## Firebase necessário

No projeto Firebase:

1. Authentication > Sign-in method > ativar **Email/Password**.
2. Criar **Cloud Firestore**.
3. Publicar `FIRESTORE.rules`.
4. Criar **Cloud Storage**.
5. Publicar `STORAGE.rules`.
6. Ao usar regras de Storage que consultam Firestore, aceitar a autorização/IAM pedida pela consola Firebase.
7. Copiar para a app: Project ID, API Key, Application ID e Storage Bucket.

## Segurança

As chaves de configuração Firebase identificam o projeto e não substituem autenticação. A autorização efetiva é aplicada no servidor pelas Firebase Security Rules. Uma app modificada não consegue ultrapassar as regras para escrever em coleções sem o perfil correto.

### Próximo hardening recomendado

Depois de validar o fluxo multiutilizador real, ativar Firebase App Check para reduzir chamadas vindas de clientes não autorizados/clonados.
