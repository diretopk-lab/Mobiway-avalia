# MOBIWAY Cloud v0.1 — Cloud Core

Base integrada para MOBIWAY Avalia v0.7.0-cloud e MOBIWAY Repair v0.8.0-cloud.

## Incluído
- Firebase Authentication por email/password.
- Cloud Firestore para avaliações e ordens de reparação.
- Cloud Storage para fotografias, assinaturas e outras imagens embebidas.
- Sincronização em tempo real entre dispositivos autenticados na mesma empresa.
- Firestore offline cache no Android; o armazenamento local atual das apps continua ativo.
- Migração inicial dos registos já existentes no dispositivo após login.
- Identificador único por dispositivo.
- Botão flutuante `CLOUD` em ambas as apps para configuração e login.
- Sem `google-services.json`: o Firebase é inicializado programaticamente a partir da configuração introduzida na app.

## Configuração Firebase necessária
1. Criar um projeto Firebase.
2. Ativar Authentication > Email/Password.
3. Criar a base Cloud Firestore.
4. Ativar Cloud Storage. Em 2026, o Firebase exige plano Blaze (pay-as-you-go) para usar Storage; continua a existir utilização sem custo dentro dos limites aplicáveis.
5. Publicar `FIRESTORE.rules` e `STORAGE.rules` deste pacote.
6. No Firebase Project settings, registar uma app Android e recolher: Project ID, API key, Application ID e Storage bucket.
7. Abrir Avalia ou Repair, tocar em `CLOUD`, preencher os quatro valores e criar/entrar na conta MOBIWAY.
8. Repetir apenas o login nos restantes equipamentos com a mesma configuração.

## Estrutura de dados
- `/companies/mobiway/evaluations/{evaluationId}`
- `/companies/mobiway/repairOrders/{orderId}`
- Storage: `/companies/mobiway/<collection>/<recordId>/media/*`

## Próxima evolução
A v0.2 deverá acrescentar perfis individuais, funções e permissões (Admin, Oficina, Compras, Vendas, Consulta), registo de auditoria e gestão remota de equipamentos. Essa camada será a base do MOBIWAY Hub.
