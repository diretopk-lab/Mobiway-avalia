package pt.mobiway.avalia;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_PERMISSION = 2001;
    private static final int BACKUP_EXPORT = 3001;
    private static final int BACKUP_IMPORT = 3002;
    private static final String EXTRA_REPAIR_VEHICLE = "MOBIWAY_REPAIR_VEHICLE_JSON";
    private static final String EXTRA_AVALIA_RESULT = "MOBIWAY_AVALIA_RESULT_JSON";
    private static final String EXTRA_REPAIR_PAYLOAD_URI = "MOBIWAY_REPAIR_PAYLOAD_URI";
    private static final String EXTRA_AVALIA_RESULT_URI = "MOBIWAY_AVALIA_RESULT_URI";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean cameraRequest;
    private String pendingBackupJson = "{}";
    private String pendingBackupFileName = "mobiway-avalia-backup.json";

    private Uri writeIntegrationPayload(String prefix, String payload) {
        try {
            File dir = new File(getCacheDir(), "integration");
            if (!dir.exists()) dir.mkdirs();
            File file = File.createTempFile(prefix, ".json", dir);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write((payload == null ? "{}" : payload).getBytes(StandardCharsets.UTF_8));
            }
            return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readIntegrationPayload(Intent intent, String uriKey) {
        if (intent == null) return "";
        try {
            Uri uri = intent.getParcelableExtra(uriKey);
            if (uri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return "";
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception ignored) {
            return "";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(9, 10, 12));
        getWindow().setNavigationBarColor(Color.rgb(9, 10, 12));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 10, 12));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void printPdf() {
                runOnUiThread(() -> createPrintJob());
            }

            @JavascriptInterface
            public void exportBackup(String fileName, String json) {
                pendingBackupJson = json == null ? "{}" : json;
                pendingBackupFileName = (fileName == null || fileName.trim().isEmpty())
                    ? "mobiway-avalia-backup.json" : fileName;
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFileName);
                        startActivityForResult(intent, BACKUP_EXPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public void importBackup() {
                runOnUiThread(() -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/json");
                        startActivityForResult(intent, BACKUP_IMPORT);
                    } catch (Exception ignored) { }
                });
            }

            @JavascriptInterface
            public String getRepairPayload() {
                Intent intent = getIntent();
                if (intent == null) return "";
                String payload = intent.getStringExtra(EXTRA_REPAIR_VEHICLE);
                if (payload != null && !payload.isEmpty()) return payload;
                return readIntegrationPayload(intent, EXTRA_REPAIR_PAYLOAD_URI);
            }

            @JavascriptInterface
            public void clearRepairPayload() {
                Intent intent = getIntent();
                if (intent != null) {
                    intent.removeExtra(EXTRA_REPAIR_VEHICLE);
                    intent.removeExtra(EXTRA_REPAIR_PAYLOAD_URI);
                }
            }

            @JavascriptInterface
            public boolean openRepair() {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                    if (launch == null) return false;
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }

            @JavascriptInterface
            public boolean returnToRepair(String resultJson) {
                final String payload = resultJson == null ? "{}" : resultJson;
                final Uri payloadUri = writeIntegrationPayload("avalia_to_repair_", payload);
                try {
                    Intent launch = new Intent();
                    launch.setClassName("pt.mobiway.repair", "pt.mobiway.repair.MainActivity");
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (payloadUri != null) {
                        launch.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                        launch.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                        launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else if (payload.length() < 300000) {
                        launch.putExtra(EXTRA_AVALIA_RESULT, payload);
                    }
                    launch.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                    startActivity(launch);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent fallback = getPackageManager().getLaunchIntentForPackage("pt.mobiway.repair");
                        if (fallback == null) return false;
                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        if (payloadUri != null) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT_URI, payloadUri);
                            fallback.setClipData(ClipData.newRawUri("MOBIWAY AVALIA", payloadUri));
                            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } else if (payload.length() < 300000) {
                            fallback.putExtra(EXTRA_AVALIA_RESULT, payload);
                        }
                        fallback.putExtra("MOBIWAY_AVALIA_SOURCE", "pt.mobiway.avalia");
                        startActivity(fallback);
                        return true;
                    } catch (Exception ignored) {
                        return false;
                    }
                }
            }
        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                    "window.print=function(){if(window.AndroidBridge&&AndroidBridge.printPdf){AndroidBridge.printPdf();}};",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }

                fileCallback = callback;

                boolean capturePreferred =
                    params != null && params.isCaptureEnabled();

                launchChooser(capturePreferred);
                return true;
            }

            @Override
            public boolean onCreateWindow(
                    WebView view,
                    boolean isDialog,
                    boolean isUserGesture,
                    android.os.Message resultMsg) {

                WebView temp = new WebView(MainActivity.this);

                temp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView v,
                            WebResourceRequest req) {
                        openExternal(req.getUrl());
                        return true;
                    }
                });

                WebView.WebViewTransport transport =
                    (WebView.WebViewTransport) resultMsg.obj;

                transport.setWebView(temp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                new String[]{Manifest.permission.CAMERA},
                CAMERA_PERMISSION
            );
        }

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void launchChooser(boolean capturePreferred) {
        cameraRequest = capturePreferred;

        if (capturePreferred) {
            launchCamera();
            return;
        }

        Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        gallery.addCategory(Intent.CATEGORY_OPENABLE);
        gallery.setType("image/*");
        gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        gallery.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(gallery, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {

            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType("image/*");
            fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

            try {
                startActivityForResult(
                    Intent.createChooser(
                        fallback,
                        "Fotografias da viatura"
                    ),
                    FILE_CHOOSER
                );

            } catch (ActivityNotFoundException ignored) {
                finishFileChooser(null);
            }
        }
    }

    private void launchCamera() {
        Intent camera =
            new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        ContentValues values = new ContentValues();

        values.put(
            MediaStore.Images.Media.DISPLAY_NAME,
            "mobiway_" + System.currentTimeMillis() + ".jpg"
        );

        values.put(
            MediaStore.Images.Media.MIME_TYPE,
            "image/jpeg"
        );

        cameraUri =
            getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            );

        if (cameraUri != null) {
            camera.putExtra(
                MediaStore.EXTRA_OUTPUT,
                cameraUri
            );

            camera.addFlags(
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        }

        try {
            startActivityForResult(camera, FILE_CHOOSER);

        } catch (ActivityNotFoundException ex) {
            finishFileChooser(null);
        }
    }

    private void createPrintJob() {
        if (webView == null) return;

        PrintManager printManager =
            (PrintManager) getSystemService(PRINT_SERVICE);

        if (printManager == null) return;

        PrintDocumentAdapter adapter =
            webView.createPrintDocumentAdapter(
                "MOBIWAY Avalia"
            );

        printManager.print(
            "MOBIWAY Avalia",
            adapter,
            new PrintAttributes.Builder().build()
        );
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(
                new Intent(Intent.ACTION_VIEW, uri)
            );
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
            requestCode,
            resultCode,
            data
        );

        if (requestCode == BACKUP_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out != null) out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode == BACKUP_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    if (in != null) {
                        byte[] bytes = in.readAllBytes();
                        String json = new String(bytes, StandardCharsets.UTF_8);
                        String js = "if(window.Mobiway&&Mobiway.receiveNativeBackup){Mobiway.receiveNativeBackup(" + JSONObject.quote(json) + ");}";
                        webView.post(() -> webView.evaluateJavascript(js, null));
                    }
                } catch (Exception ignored) { }
            }
            return;
        }

        if (requestCode != FILE_CHOOSER ||
                fileCallback == null) {
            return;
        }

        if (resultCode != RESULT_OK) {
            finishFileChooser(null);
            return;
        }

        List<Uri> uris = new ArrayList<>();

        if (data != null) {

            ClipData clipData = data.getClipData();

            if (clipData != null) {

                for (int i = 0;
                     i < clipData.getItemCount();
                     i++) {

                    Uri uri =
                        clipData.getItemAt(i).getUri();

                    if (uri != null) {
                        uris.add(uri);
                    }
                }

            } else if (data.getData() != null) {

                uris.add(data.getData());
            }
        }

        if (uris.isEmpty() &&
                cameraRequest &&
                cameraUri != null) {

            uris.add(cameraUri);
        }

        finishFileChooser(
            uris.isEmpty()
                ? null
                : uris.toArray(new Uri[0])
        );
    }

    private void finishFileChooser(Uri[] result) {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }

        cameraUri = null;
        cameraRequest = false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        if (webView != null) {
            webView.post(() -> webView.reload());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null &&
                webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
