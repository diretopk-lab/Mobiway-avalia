(() => {
  'use strict';

  const $ = s => document.querySelector(s);
  const app = $('#app');
  const fmt = new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const num = v => Number(String(v ?? '').replace(',', '.')) || 0;
  const clamp = (v,min,max) => Math.min(max,Math.max(min,v));
  const median = a => { const x=a.filter(Number.isFinite).sort((a,b)=>a-b); if(!x.length)return 0; const m=Math.floor(x.length/2); return x.length%2?x[m]:(x[m-1]+x[m])/2; };
  const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
  const esc = v => String(v ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

  const DEFAULTS = {
    targetProfitPct: 16,
    targetProfitMin: 1500,
    minimumProfit: 1000,
    negotiationBufferPct: 5,
    warrantyReserve: 650,
    stockMonthly: 180,
    expectedStockDays: 45,
    adminCost: 180,
    defaultService: 250,
    defaultDetailing: 120,
    unknownHistoryRisk: 450,
    automaticGearboxRisk: 300,
    highKmRisk: 300,
    dieselRisk: 180,
    storeEditorUrl: 'https://www.amen.pt/',
    storeCategory: 'Viaturas',
    storePublisherUrl: ''
  };

  let settings = load('mobiway_settings', DEFAULTS);
  // v0.9.1 privacy migration: remove any legacy RegCheck/Matricula credentials from local storage.
  ['vehicleLookupUser','regCheckUser','regCheckUsername','matriculaUser'].forEach(k=>{ if(Object.prototype.hasOwnProperty.call(settings,k)) delete settings[k]; });
  save('mobiway_settings', settings);
  let evaluations = load('mobiway_evaluations', []);
  let state = { view:'home', step:1, draft:null, editingId:null };

  function load(k, fallback){ try { const x=JSON.parse(localStorage.getItem(k)); return x ?? structuredClone(fallback); } catch { return structuredClone(fallback); } }
  function save(k,v){ localStorage.setItem(k,JSON.stringify(v)); }
  function toast(msg){ const old=$('.toast'); if(old)old.remove(); const e=document.createElement('div'); e.className='toast'; e.textContent=msg; document.body.appendChild(e); setTimeout(()=>e.remove(),2200); }

  function newDraft(){
    return {
      id:uid(), createdAt:new Date().toISOString(), updatedAt:new Date().toISOString(), status:'avaliacao',
      vehicle:{plate:'',vin:'',brand:'',model:'',version:'',year:new Date().getFullYear()-5,month:'',fuel:'Diesel',engine:'',engineCc:'',power:'',co2:'',color:'',seats:'',gearbox:'Manual',km:'',origin:'Nacional',owners:'',askingPrice:'',notes:''},
      photos:[],
      smartScan:{status:'idle',message:'Pronto para leitura.',confidence:0,plate:'',provider:'OCR local',lastAt:''},
      duaScan:{status:'idle',message:'Fotografa o DUA para preencher automaticamente os dados técnicos.',lastAt:'',confidence:0},
      condition:{body:'mid',interior:'mid',tyres:'mid',engine:'mid',gearbox:'mid',brakes:'mid',history:'unknown',warningLights:'none',keys:'2',accidents:'unknown',knownFaults:'',mechanicalCost:0,bodyCost:0,tyresCost:0,otherRepairCost:0},
      comps:[], marketOverride:'', marketAI:null, marketAILoading:false, marketAIError:'',
      integration:null,
      finance:{service:settings.defaultService,detailing:settings.defaultDetailing,warranty:settings.warrantyReserve,admin:settings.adminCost,stockDays:settings.expectedStockDays,stockMonthly:settings.stockMonthly,other:0,customRisk:0},
      purchase:{decision:'',actualPurchasePrice:'',actualRepairCost:'',actualSalePrice:'',saleDate:'',warrantyActual:'',notes:''},
      listing:null
    };
  }

  function ensureDraft(){ if(!state.draft) state.draft=newDraft(); return state.draft; }

  function shell(content, tab='home'){
    return `<div class="shell">
      <header class="topbar">
        <div class="brand suiteBrand"><img class="moduleIcon" src="avalia_icon_3d.png" alt="MOBIWAY Avalia"><div class="brandTitle"><strong>AVALIA</strong><span>MOBIWAY SUITE · decisão de compra</span></div></div>
        <div class="topActions noPrint"><button class="repairLinkBtn suiteSwitch" onclick="Mobiway.openRepair()">↗ REPAIR</button><button class="iconBtn internalBtn" onclick="Mobiway.backHome()">INTERNO</button></div>
      </header>
      ${content}
    </div>${tabs(tab)}`;
  }
  function tabs(active){
    return `<nav class="tabs noPrint"><div class="inner">
      ${tabBtn('home','⌂','Início',active)}${tabBtn('history','◷','Histórico',active)}${tabBtn('analytics','◈','Resultados',active)}${tabBtn('settings','⚙','Definições',active)}<button class="tab suiteExternal" onclick="Mobiway.openRepair()"><b>↗</b>REPAIR</button>
    </div></nav>`;
  }
  function tabBtn(view,icon,label,active){return `<button class="tab ${view===active?'active':''}" onclick="Mobiway.go('${view}')"><b>${icon}</b>${label}</button>`}

  function render(){
    if(state.view==='wizard') return renderWizard();
    if(state.view==='detail') return renderDetail();
    if(state.view==='history') return renderHistory();
    if(state.view==='settings') return renderSettings();
    if(state.view==='analytics') return renderAnalytics();
    if(state.view==='listing') return renderListing();
    renderHome();
  }

  function renderHome(){
    const completed=evaluations.filter(e=>e.result);
    const buys=evaluations.filter(e=>e.purchase?.decision==='bought');
    const avgMargin=completed.length?completed.reduce((s,e)=>s+(e.result?.targetProfit||0),0)/completed.length:0;
    const actualSold=buys.filter(e=>num(e.purchase.actualSalePrice)>0);
    const realized=actualSold.reduce((s,e)=>s+(num(e.purchase.actualSalePrice)-num(e.purchase.actualPurchasePrice)-num(e.purchase.actualRepairCost)-num(e.purchase.warrantyActual)),0);
    app.innerHTML=shell(`
      <section class="hero suiteHero">
        <div class="suiteKicker"><span class="suiteDot"></span>MOBIWAY SUITE · AVALIA</div>
        <span class="eyebrow">● MOBIWAY intelligence</span>
        <h1>Comprar melhor.<br><em>Vender com margem.</em></h1>
        <p>Avaliação profissional de usados com fotografias, comparáveis de mercado, custos de preparação, risco de garantia e margem Mobiway — numa única decisão.</p>
        <div class="heroActions"><button class="primaryBtn" onclick="Mobiway.newEvaluation()">＋ NOVA AVALIAÇÃO</button><button class="repairLinkBtn large" onclick="Mobiway.openRepair()">↗ ABRIR MOBIWAY REPAIR</button><button class="ghostBtn" onclick="Mobiway.go('history')">VER HISTÓRICO</button><button class="ghostBtn" onclick="Mobiway.loadDemo()">CARREGAR DEMO</button></div>
      </section>
      <div class="grid">
        <div class="card"><span class="badge orange">AVALIAÇÕES</span><div class="metric">${evaluations.length}</div><p>registos guardados neste dispositivo</p></div>
        <div class="card"><span class="badge green">MARGEM ALVO</span><div class="metric">${fmt.format(avgMargin)}</div><p>média calculada nas avaliações</p></div>
        <div class="card"><span class="badge">RESULTADO REAL</span><div class="metric">${fmt.format(realized)}</div><p>lucro registado em viaturas já vendidas</p></div>
      </div>
      <div class="sectionHead"><div><h2>Avaliações recentes</h2><p>Continua ou consulta decisões anteriores.</p></div></div>
      ${recentList()}
    `,'home');
  }

  function recentList(){
    if(!evaluations.length) return `<div class="empty">Ainda não existem avaliações. Cria a primeira e testa o motor de decisão.</div>`;
    return `<div class="list">${[...evaluations].sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt)).slice(0,5).map(e=>{
      const r=e.result||calculate(e); const name=[e.vehicle.brand,e.vehicle.model,e.vehicle.version].filter(Boolean).join(' ')||'Viatura sem identificação';
      return `<div class="rowCard" onclick="Mobiway.openDetail('${e.id}')"><div class="main"><strong>${esc(name)}</strong><small>${esc(e.vehicle.year)} · ${Number(e.vehicle.km||0).toLocaleString('pt-PT')} km · ${statusText(e)}</small></div><div><div class="money">${fmt.format(r.recommendedBuy)}</div><small>compra aconselhada</small></div></div>`;
    }).join('')}</div>`;
  }

  function statusText(e){
    if(e.purchase?.decision==='bought') return 'Comprado';
    if(e.purchase?.decision==='passed') return 'Não comprado';
    return 'Avaliado';
  }

  function renderWizard(){
    const d=ensureDraft(); const s=state.step;
    const titles={1:['Identificação','Começa pelos dados essenciais da viatura.'],2:['Fotografias','Regista o estado visual com uma sequência consistente.'],3:['Estado e risco','Transforma observações em custos e risco financeiro.'],4:['Mercado','Compara anúncios equivalentes e elimina valores fora do padrão.'],5:['Custos e margem','Configura preparação, garantia, stock e margem.'],6:['Resultado','Decisão calculada para esta viatura.']};
    app.innerHTML=`<div class="shell wizard">
      <header class="topbar"><div class="brand suiteBrand"><img class="moduleIcon" src="avalia_icon_3d.png" alt="MOBIWAY Avalia"><div class="brandTitle"><strong>AVALIA</strong><span>MOBIWAY SUITE · nova avaliação</span></div></div><div class="topActions noPrint"><button class="repairLinkBtn suiteSwitch" onclick="Mobiway.openRepair()">↗ REPAIR</button><button class="iconBtn closeBtn" onclick="Mobiway.cancelWizard()">×</button></div></header>
      <div class="progress">${[1,2,3,4,5,6].map(i=>`<i class="${i<=s?'on':''}"></i>`).join('')}</div>
      ${wizardVehicleContext(d)}
      <span class="stepLabel">Passo ${s} de 6</span><h1>${titles[s][0]}</h1><p class="intro">${titles[s][1]}</p>
      ${stepHtml(s,d)}
    </div>${wizardNav(s)}`;
    bindWizardInputs();
  }

  function wizardNav(s){const backToRepair=s===6&&state.draft?.integration?.repairOrderNo;return `<div class="wizardNav noPrint"><div class="inner"><button class="ghostBtn" onclick="Mobiway.prevStep()">${s===1?'Cancelar':'← Anterior'}</button><button class="primaryBtn" onclick="Mobiway.nextStep()">${s===6?(backToRepair?'GUARDAR E VOLTAR À REPAIR':'GUARDAR AVALIAÇÃO'):'Continuar →'}</button></div></div>`}

  function wizardVehicleContext(d){
    const v=d?.vehicle||{};
    const name=[v.brand,v.model,v.version].filter(Boolean).join(' ')||'Viatura por identificar';
    const meta=[v.plate||'',v.year||'',v.km?`${Number(v.km).toLocaleString('pt-PT')} km`:'' ].filter(Boolean).join(' · ')||'Preenche os dados essenciais';
    const linked=d?.integration?.repairOrderNo?`<span class="linkedChip">REPAIR · ${esc(d.integration.repairOrderNo)}</span>`:'<span class="linkedChip neutral">AVALIA</span>';
    return `<div class="vehicleContext"><div><small>VIATURA EM ANÁLISE</small><strong>${esc(name)}</strong><span>${esc(meta)}</span></div>${linked}</div>`;
  }

  function stepHtml(s,d){
    if(s===1) return stepVehicle(d);
    if(s===2) return stepPhotos(d);
    if(s===3) return stepCondition(d);
    if(s===4) return stepMarket(d);
    if(s===5) return stepFinance(d);
    return stepResult(d);
  }

  function field(label,key,value,type='text',extra=''){return `<div class="field ${extra}"><label>${label}</label><input data-path="${key}" type="${type}" value="${esc(value)}"></div>`}
  function sel(label,key,value,opts){return `<div class="field"><label>${label}</label><select data-path="${key}">${opts.map(o=>`<option ${o===value?'selected':''}>${esc(o)}</option>`).join('')}</select></div>`}
  function euroField(label,key,value,extra=''){return `<div class="field ${extra}"><label>${label}</label><div class="suffix"><input data-path="${key}" type="number" inputmode="decimal" value="${esc(value)}"><span>€</span></div></div>`}

  function stepVehicle(d){ const v=d.vehicle; const ss=d.smartScan||{status:'idle',message:'Pronto para leitura.'}; const ds=d.duaScan||{status:'idle',message:'Fotografa o DUA para preencher automaticamente os dados técnicos.'}; const statusClass=ss.status==='ok'?'ok':ss.status==='error'?'error':ss.status==='working'?'working':''; const duaClass=ds.status==='ok'?'ok':ds.status==='error'?'error':ds.status==='working'?'working':''; return `<div class="panel">
    <div class="smartScanCard">
      <div class="smartScanCopy"><span>MOBIWAY SMART SCAN</span><strong>1 · Fotografa a matrícula</strong><small>OCR local no Android. A matrícula fica imediatamente associada à avaliação.</small></div>
      <div class="smartScanActions"><button class="primaryBtn" onclick="Mobiway.smartScanPlate()">📷 LER MATRÍCULA</button><button class="ghostBtn" onclick="Mobiway.lookupPlate(false)">↗ CHECKVIATURA OPCIONAL</button></div>
      <div class="smartScanStatus ${statusClass}">${esc(ss.message||'Pronto para leitura.')}${ss.confidence?` <b>${esc(ss.confidence)}%</b>`:''}</div>
    </div>
    <div class="smartScanCard" style="margin-top:12px">
      <div class="smartScanCopy"><span>SMART DUA</span><strong>2 · Fotografa o Documento Único Automóvel</strong><small>Lê matrícula, VIN, marca, modelo, versão, data, cilindrada, potência, combustível, cor, lugares e CO₂. Dados pessoais do titular não são recolhidos.</small></div>
      <div class="smartScanActions"><button class="primaryBtn" onclick="Mobiway.smartScanDua()">📄 LER DUA</button></div>
      <div class="smartScanStatus ${duaClass}">${esc(ds.message||'Pronto para leitura do DUA.')}${ds.confidence?` <b>${esc(ds.confidence)}%</b>`:''}</div>
    </div>
    <div class="formGrid" style="margin-top:14px">
    ${field('Matrícula','vehicle.plate',v.plate)}${field('VIN / Chassis','vehicle.vin',v.vin)}
    ${field('Marca *','vehicle.brand',v.brand)}${field('Modelo *','vehicle.model',v.model)}
    ${field('Versão / nível de equipamento','vehicle.version',v.version)}${field('Ano *','vehicle.year',v.year,'number')}
    ${sel('Combustível','vehicle.fuel',v.fuel,['Diesel','Gasolina','Híbrido','Híbrido Plug-in','Elétrico','GPL'])}${sel('Caixa','vehicle.gearbox',v.gearbox,['Manual','Automática','Automática DCT/DSG','CVT'])}
    ${field('Motor / designação','vehicle.engine',v.engine)}${field('Cilindrada (cc)','vehicle.engineCc',v.engineCc,'number')}
    ${field('Potência (cv)','vehicle.power',v.power,'number')}${field('CO₂ (g/km)','vehicle.co2',v.co2,'number')}
    ${field('Cor','vehicle.color',v.color)}${field('Lugares','vehicle.seats',v.seats,'number')}
    ${field('Quilómetros *','vehicle.km',v.km,'number')}${sel('Origem','vehicle.origin',v.origin,['Nacional','Importado','Desconhecido'])}
    ${field('N.º proprietários','vehicle.owners',v.owners,'number')}${euroField('Preço pedido pelo vendedor','vehicle.askingPrice',v.askingPrice)}
    <div class="field full"><label>Notas / equipamento relevante</label><textarea data-path="vehicle.notes">${esc(v.notes)}</textarea></div>
  </div></div>`}

  const photoLabels=['Frente ¾','Traseira ¾','Lateral esquerda','Lateral direita','Interior','Quadrante / km','Motor','Mala','Danos / detalhes'];
  function stepPhotos(d){return `<div class="panel"><div class="panelTitle"><div><h3>Inspeção fotográfica</h3><div class="hint">Ideal: 8–12 fotografias, boa luz e todos os danos visíveis.</div></div><span class="badge orange">${d.photos.length} fotos</span></div>
    <div class="photoGrid">${d.photos.map((p,i)=>`<div class="photoSlot"><img src="${p.data}" alt="foto"><button onclick="Mobiway.removePhoto(${i})">×</button></div>`).join('')}
      <button class="photoAdd" onclick="Mobiway.takePhoto()"><b>＋</b>Tirar fotografia</button><button class="photoAdd" onclick="Mobiway.pickPhotos()"><b>▧</b>Galeria</button>
    </div></div><div class="panel"><h3>Sequência recomendada</h3><p class="hint">${photoLabels.join(' · ')}</p><p class="hint" style="margin-top:10px">Na versão com análise visual online, estas imagens poderão alimentar deteção de danos, desgaste e leitura assistida de quilometragem. Nesta versão são anexadas ao processo e entram na revisão humana.</p></div>`}

  function stepCondition(d){const c=d.condition;return `<div class="panel"><div class="panelTitle"><div><h3>Estado observado</h3><div class="hint">Bom = sem intervenção relevante · Médio = desgaste normal/preparação · Mau = reparação provável.</div></div></div>
    ${rating('Carroçaria / pintura','condition.body',c.body,'riscos, mossas, pintura')}
    ${rating('Interior','condition.interior',c.interior,'bancos, plásticos, forros')}
    ${rating('Pneus / jantes','condition.tyres',c.tyres,'desgaste e danos')}
    ${rating('Motor','condition.engine',c.engine,'ruído, fugas, fumo, funcionamento')}
    ${rating('Caixa / embraiagem','condition.gearbox',c.gearbox,'engrenamento e anomalias')}
    ${rating('Travões / suspensão','condition.brakes',c.brakes,'ruídos, folgas, discos/pastilhas')}
  </div><div class="panel"><div class="formGrid">
    ${sel('Histórico de manutenção','condition.history',c.history,['complete','partial','unknown'].map(x=>x))}
    ${sel('Luzes de avaria','condition.warningLights',c.warningLights,['none','minor','major'])}
    ${sel('Acidentes conhecidos','condition.accidents',c.accidents,['no','yes','unknown'])}
    ${sel('Chaves','condition.keys',String(c.keys),['2','1','0'])}
    ${euroField('Mecânica estimada','condition.mechanicalCost',c.mechanicalCost)}${euroField('Chapa / pintura','condition.bodyCost',c.bodyCost)}
    ${euroField('Pneus / jantes','condition.tyresCost',c.tyresCost)}${euroField('Outras reparações','condition.otherRepairCost',c.otherRepairCost)}
    <div class="field full"><label>Avarias / observações conhecidas</label><textarea data-path="condition.knownFaults">${esc(c.knownFaults)}</textarea></div>
  </div></div>`}

  function rating(label,path,value,sub){return `<div class="rangeRow"><div><strong>${label}</strong><small>${sub}</small></div><div class="ratingBtns">${[['good','Bom'],['mid','Médio'],['bad','Mau']].map(([v,l])=>`<button class="${value===v?`sel ${v}`:''}" onclick="Mobiway.setRating('${path}','${v}')">${l}</button>`).join('')}</div></div>`}

  function stepMarket(d){ const ai=d.marketAI||null; const loading=!!d.marketAILoading; const err=d.marketAIError||''; const comps=(ai&&Array.isArray(ai.comparables))?ai.comparables:[]; return `<div class="panel marketAuto"><div class="panelTitle"><div><h3>Pesquisa automática de mercado</h3><div class="hint">A TransparentCars é a fonte principal de valorização: mercado português, API pública e sem chave. A MOBIWAY usa o valor mediano e a faixa de comparáveis.</div></div><span class="badge ${ai?'green':'orange'}">${ai?'TRANSPARENTCARS':'TRANSPARENTCARS'}</span></div>
    ${loading?`<div class="marketLoading"><div class="spinner"></div><div><strong>A consultar a TransparentCars…</strong><p>A comparar marca, modelo, ano, quilometragem, combustível, caixa e potência no mercado português.</p></div></div>`:''}
    ${err?`<div class="callout dangerish"><strong>Não foi possível concluir a pesquisa</strong><p>${esc(err)}</p><button class="ghostBtn" onclick="Mobiway.autoMarket(true)">Tentar novamente</button></div>`:''}
    ${ai?`<div class="grid"><div class="card"><span class="badge green">VALOR DE MERCADO</span><div class="metric">${fmt.format(ai.marketValue||0)}</div><p>estimativa central de venda a retalho</p></div><div class="card"><span class="badge">INTERVALO</span><div class="metric smallMetric">${fmt.format(ai.low||0)} – ${fmt.format(ai.high||0)}</div><p>faixa observada/ajustada</p></div><div class="card"><span class="badge ${Number(ai.confidence)>=75?'green':'orange'}">CONFIANÇA</span><div class="metric">${Number(ai.confidence)||0}%</div><p>${Number(ai.comparablesCount)||comps.length} comparáveis</p></div></div><div class="marketSummary"><strong>Leitura MOBIWAY</strong><p>${esc(ai.summary||'Pesquisa concluída.')}</p>${ai.iucAnnual?`<p><b>IUC estimado:</b> ${fmt.format(ai.iucAnnual)}/ano</p>`:''}<small>Fonte: ${esc(ai.provider||'TransparentCars')} · Atualizado: ${ai.researchedAt?new Date(ai.researchedAt).toLocaleString('pt-PT'):'agora'}</small></div>`:`${!loading&&!err?`<div class="empty">A pesquisa inicia automaticamente ao entrar neste passo.</div>`:''}`}
    ${comps.length?`<div style="overflow:auto;margin-top:14px"><table class="compTable"><thead><tr><th>Anúncio</th><th>Ano</th><th>Km</th><th>Preço</th></tr></thead><tbody>${comps.slice(0,8).map(c=>`<tr><td>${c.url?`<a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.title||'Comparável')} ↗</a>`:esc(c.title||'Comparável')}</td><td>${esc(c.year||'—')}</td><td>${c.km?Number(c.km).toLocaleString('pt-PT'):'—'}</td><td>${c.price?fmt.format(c.price):'—'}</td></tr>`).join('')}</tbody></table></div>`:''}
    <div class="heroActions" style="margin-top:14px"><button class="primaryBtn" onclick="Mobiway.autoMarket(true)">↻ ATUALIZAR PESQUISA</button><button class="ghostBtn" onclick="Mobiway.marketSearch()">Ver pesquisa no Google ↗</button></div>
  </div>
  <details class="panel advancedMarket" style="margin-top:14px"><summary>Opções avançadas / correção manual</summary><div class="formGrid" style="margin-top:14px">${euroField('Valor manual de exceção','marketOverride',d.marketOverride,'full')}</div><p class="hint" style="margin-top:10px">Só usar quando existir informação comercial concreta que justifique substituir a pesquisa automática.</p></details>`}

  function stepFinance(d){ const f=d.finance, risk=calcRisk(d), m=effectiveMarket(d); return `<div class="grid"><div class="card wide"><h3>Preparação prevista</h3><div class="formGrid" style="margin-top:12px">
    ${euroField('Revisão / manutenção','finance.service',f.service)}${euroField('Detailing','finance.detailing',f.detailing)}
    ${euroField('Reserva garantia','finance.warranty',f.warranty)}${euroField('Administrativo / comercial','finance.admin',f.admin)}
    ${field('Dias previstos em stock','finance.stockDays',f.stockDays,'number')}${euroField('Custo mensal de stock','finance.stockMonthly',f.stockMonthly)}
    ${euroField('Outros custos','finance.other',f.other)}${euroField('Ajuste manual de risco','finance.customRisk',f.customRisk)}
  </div></div><div class="card"><span class="badge orange">RISCO CALCULADO</span><div class="metric">${fmt.format(risk.amount)}</div><p>${risk.label} · score ${risk.score}/100</p></div></div>
  <div class="panel" style="margin-top:14px"><h3>Política Mobiway aplicada</h3><div class="breakdown">
    <div class="breakRow"><span>Mercado corrigido</span><strong>${fmt.format(m.value)}</strong></div>
    <div class="breakRow"><span>Margem alvo</span><strong>máx. ${settings.targetProfitPct}% / mínimo ${fmt.format(settings.targetProfitMin)}</strong></div>
    <div class="breakRow"><span>Margem mínima absoluta</span><strong>${fmt.format(settings.minimumProfit)}</strong></div>
    <div class="breakRow"><span>Buffer de negociação</span><strong>${settings.negotiationBufferPct}%</strong></div>
  </div></div>`}

  function stepResult(d){ const r=calculate(d); d.result=r; return resultHtml(d,r,true); }

  function resultHtml(d,r,inWizard=false){ const v=d.vehicle; return `<div class="resultHero"><span class="badge orange">MOBIWAY · AVALIAÇÃO</span><div class="car" style="margin-top:12px">${esc(v.year)} · ${Number(v.km||0).toLocaleString('pt-PT')} km · ${esc(v.fuel)} · ${esc(v.gearbox)}</div><h2>${esc([v.brand,v.model,v.version].filter(Boolean).join(' ')||'Viatura')}</h2>
    <div class="resultBand"><div class="band green"><small>Compra aconselhada</small><strong>${fmt.format(r.recommendedBuy)}</strong></div><div class="band orange"><small>Máximo absoluto</small><strong>${fmt.format(r.maximumBuy)}</strong></div><div class="band red"><small>Acima de</small><strong>${fmt.format(r.maximumBuy)}</strong></div></div>
  </div>
  <div class="grid" style="margin-top:14px"><div class="card wide"><h3>Economia do negócio</h3><div class="breakdown">
    <div class="breakRow"><span>Venda provável</span><strong>${fmt.format(r.expectedSale)}</strong></div>
    <div class="breakRow"><span>Reparações observadas</span><strong>− ${fmt.format(r.observedRepairs)}</strong></div>
    <div class="breakRow"><span>Preparação + stock</span><strong>− ${fmt.format(r.prepAndStock)}</strong></div>
    <div class="breakRow"><span>Reserva de risco</span><strong>− ${fmt.format(r.riskAmount)}</strong></div>
    <div class="breakRow"><span>Margem alvo Mobiway</span><strong>− ${fmt.format(r.targetProfit)}</strong></div>
    <div class="breakRow total"><span>Compra aconselhada</span><strong>${fmt.format(r.recommendedBuy)}</strong></div>
  </div></div><div class="card"><div class="scoreWrap"><div class="score" style="--score:${r.confidence*3.6}deg"><b>${r.confidence}%</b></div><div class="scoreText"><strong>Confiança</strong><small>${r.confidenceLabel}</small></div></div><hr style="border:0;border-top:1px solid #282d35;margin:18px 0"><span class="badge ${r.riskScore<40?'green':r.riskScore<70?'orange':'red'}">RISCO ${r.riskLabel.toUpperCase()}</span><div class="metric">${r.riskScore}<small>/100</small></div></div></div>
  <div class="callout" style="margin-top:14px"><strong>FAIXA DE NEGOCIAÇÃO</strong><div class="big">Abrir em ${fmt.format(r.openingOffer)}</div><p>Objetivo: fechar até ${fmt.format(r.recommendedBuy)}. Não ultrapassar ${fmt.format(r.maximumBuy)} sem rever preço de venda, custos ou margem.</p></div>
  ${!inWizard?decisionPanel(d):''}`; }

  function decisionPanel(d){
    const p=d.purchase||{};
    const repairAction=d.integration?.repairOrderNo
      ? `<button class="primaryBtn repairReturnBtn" onclick="Mobiway.sendToRepair('${d.id}')">↩ DEVOLVER À REPAIR</button>`
      : (p.decision==='bought'
          ? `<button class="primaryBtn repairReturnBtn" onclick="Mobiway.sendToRepair('${d.id}')">→ CRIAR ORDEM NA REPAIR</button>`
          : '');
    const storeAction=p.decision==='bought'?`<button class="primaryBtn storePublishBtn" onclick="Mobiway.openListing('${d.id}')">▣ ANÚNCIO MOBIWAY.STORE</button>`:'';
    return `<div class="panel" style="margin-top:14px"><div class="panelTitle"><div><h3>Decisão real</h3><div class="hint">Regista o resultado para o sistema comparar previsão vs. realidade.</div></div></div><div class="heroActions noPrint"><button class="successBtn" onclick="Mobiway.markDecision('${d.id}','bought')">✓ COMPRÁMOS</button><button class="dangerBtn" onclick="Mobiway.markDecision('${d.id}','passed')">× NÃO COMPRÁMOS</button><button class="ghostBtn" onclick="window.print()">Imprimir / PDF</button>${storeAction}${repairAction}</div>
  ${p.decision==='bought'?`<div class="formGrid" style="margin-top:16px">${euroField('Preço real de compra','purchase.actualPurchasePrice',p.actualPurchasePrice)}${euroField('Reparação real','purchase.actualRepairCost',p.actualRepairCost)}${euroField('Preço real de venda','purchase.actualSalePrice',p.actualSalePrice)}${euroField('Garantia / pós-venda real','purchase.warrantyActual',p.warrantyActual)}${field('Data de venda','purchase.saleDate',p.saleDate,'date')}<div class="field full"><label>Notas finais</label><textarea data-path="purchase.notes">${esc(p.notes||'')}</textarea></div></div><button class="primaryBtn noPrint" style="margin-top:12px" onclick="Mobiway.saveDetail()">Guardar resultado real</button>`:''}</div>`;
  }

  function riskFactor(v){ return ({good:0,mid:1,bad:2})[v] ?? 1; }
  function calcRisk(d){
    const c=d.condition,v=d.vehicle; let score=0, amount=0;
    score += riskFactor(c.engine)*11 + riskFactor(c.gearbox)*11 + riskFactor(c.body)*6 + riskFactor(c.interior)*4 + riskFactor(c.tyres)*4 + riskFactor(c.brakes)*6;
    if(c.history==='unknown'){score+=12;amount+=settings.unknownHistoryRisk}else if(c.history==='partial'){score+=5;amount+=Math.round(settings.unknownHistoryRisk*.4)}
    if(c.warningLights==='major'){score+=18;amount+=500}else if(c.warningLights==='minor'){score+=7;amount+=180}
    if(c.accidents==='yes'){score+=12;amount+=350}else if(c.accidents==='unknown')score+=4;
    if(String(v.gearbox).toLowerCase().includes('autom')){score+=5;amount+=settings.automaticGearboxRisk}
    if(num(v.km)>=200000){score+=10;amount+=settings.highKmRisk}else if(num(v.km)>=150000){score+=5;amount+=Math.round(settings.highKmRisk*.5)}
    if(v.fuel==='Diesel' && num(v.km)>=140000){score+=4;amount+=settings.dieselRisk}
    if(v.origin==='Importado'){score+=3;amount+=100}
    if(num(c.keys)<2){score+=2;amount+=120}
    score=clamp(Math.round(score),0,100); amount += num(d.finance.customRisk);
    return {score,amount,label:score<35?'Baixo':score<65?'Médio':'Elevado'};
  }

  function marketStats(d){
    const targetYear=num(d.vehicle.year), targetKm=num(d.vehicle.km);
    let rows=d.comps.map(c=>({year:num(c.year),km:num(c.km),price:num(c.price)})).filter(c=>c.price>500);
    if(!rows.length)return {count:0,median:0,adjusted:0,confidence:15};
    const prices=rows.map(x=>x.price); const med=median(prices);
    // robust outlier filter around median ±35%
    const clean=rows.filter(x=>x.price>=med*.65 && x.price<=med*1.35);
    const use=clean.length>=2?clean:rows;
    const adjusted=use.map(c=>{
      const ageAdj=(targetYear-c.year)*350; // newer target => higher than older comp
      const kmDelta=(targetKm-c.km)/10000;
      const kmAdj=kmDelta*-180; // more km on target => lower value
      return c.price + ageAdj + kmAdj;
    });
    const adj=median(adjusted);
    const count=use.length;
    const spread=median(use.map(x=>Math.abs(x.price-med)))/(med||1);
    let confidence=35+count*10 - spread*80;
    if(count>=5)confidence+=8;if(count>=8)confidence+=5;
    confidence=clamp(Math.round(confidence),20,95);
    return {count,median:Math.round(med),adjusted:Math.round(adj),confidence};
  }

  function effectiveMarket(d){const s=marketStats(d); const ov=num(d.marketOverride); const ai=d.marketAI||{}; const av=num(ai.marketValue); return {value:ov||av||s.adjusted||s.median||num(d.vehicle.askingPrice),confidence:ov?78:(av?clamp(num(ai.confidence)||70,35,97):s.confidence),source:ov?'manual':(av?'ai-web':'comparables')};}

  function calculate(d){
    const market=effectiveMarket(d), risk=calcRisk(d), c=d.condition, f=d.finance;
    const observedRepairs=num(c.mechanicalCost)+num(c.bodyCost)+num(c.tyresCost)+num(c.otherRepairCost);
    const stockCost=num(f.stockMonthly)*(num(f.stockDays)/30);
    const prepAndStock=num(f.service)+num(f.detailing)+num(f.warranty)+num(f.admin)+num(f.other)+stockCost;
    const expectedSale=market.value;
    const targetProfit=Math.max(settings.targetProfitMin, expectedSale*(settings.targetProfitPct/100));
    const totalBeforeProfit=observedRepairs+prepAndStock+risk.amount;
    const recommendedBuy=Math.max(0,Math.round(expectedSale-totalBeforeProfit-targetProfit));
    const maximumBuy=Math.max(recommendedBuy,Math.round(expectedSale-totalBeforeProfit-settings.minimumProfit));
    const openingOffer=Math.max(0,Math.round(recommendedBuy*(1-settings.negotiationBufferPct/100)/50)*50);
    let confidence=market.confidence;
    if(d.photos.length>=6)confidence+=5;if(d.vehicle.vin)confidence+=3;if(c.history==='complete')confidence+=4;if(c.history==='unknown')confidence-=5;
    confidence=clamp(Math.round(confidence),15,97);
    return {expectedSale,observedRepairs,prepAndStock,riskAmount:risk.amount,riskScore:risk.score,riskLabel:risk.label,targetProfit,recommendedBuy,maximumBuy,openingOffer,confidence,confidenceLabel:confidence>=80?'Alta':confidence>=60?'Média':'Baixa',marketSource:market.source};
  }

  function bindWizardInputs(){
    document.querySelectorAll('[data-path]').forEach(el=>el.addEventListener('input',()=>{setPath(state.draft,el.dataset.path,el.value); state.draft.updatedAt=new Date().toISOString(); if(state.step===6) renderWizard();}));
    document.querySelectorAll('[data-comp]').forEach(el=>el.addEventListener('change',()=>{const [i,k]=el.dataset.comp.split('.'); state.draft.comps[Number(i)][k]=el.value; state.draft.updatedAt=new Date().toISOString(); renderWizard();}));
  }
  function setPath(obj,path,val){const parts=path.split('.');let cur=obj;parts.slice(0,-1).forEach(p=>{if(!cur[p])cur[p]={};cur=cur[p]});cur[parts.at(-1)]=val;}

  function renderDetail(){
    const d=evaluations.find(x=>x.id===state.editingId); if(!d){state.view='home';return render();}
    d.result=calculate(d); state.draft=d;
    const ref=String(d.id||'').replace(/[^A-Za-z0-9]/g,'').slice(-10).toUpperCase()||'AVALIA';
    const reportHead=`<div class="reportDocHead"><img src="mobiway_logo.png"><div><span>RELATÓRIO DE AVALIAÇÃO E COMPRA DE USADOS</span><strong>Ref. ${esc(ref)}</strong><small>${new Date(d.createdAt).toLocaleString('pt-PT')} · ${esc(d.vehicle.plate||'Sem matrícula')}${d.vehicle.vin?` · VIN ${esc(d.vehicle.vin)}`:''}</small></div></div>`;
    const reportFoot=`<div class="reportDocFooter"><b>MOBIWAY Avalia</b><span>Documento interno de apoio à decisão de compra. Valores indicativos sujeitos a confirmação do estado real da viatura e das condições de mercado.</span></div>`;
    app.innerHTML=shell(`${reportHead}<div class="sectionHead"><div><h2>Relatório de avaliação</h2><p>${new Date(d.createdAt).toLocaleString('pt-PT')}</p></div><div class="heroActions noPrint"><button class="ghostBtn" onclick="Mobiway.editEvaluation('${d.id}')">Editar avaliação</button></div></div>${resultHtml(d,d.result,false)}${d.photos.length?`<div class="sectionHead"><div><h2>Fotografias</h2></div></div><div class="photoGrid">${d.photos.map(p=>`<div class="photoSlot"><img src="${p.data}"></div>`).join('')}</div>`:''}${reportFoot}`,'history');
    bindWizardInputs();
  }

  function listingSku(d){
    const plate=String(d.vehicle?.plate||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
    return `MW-${plate||String(d.id||'').replace(/[^A-Za-z0-9]/g,'').slice(-8).toUpperCase()}`;
  }

  function cleanPublicNote(s){
    return String(s||'').split(/\n+/).map(x=>x.trim()).filter(Boolean).filter(x=>!/^Smart Scan:/i.test(x)).join(' · ');
  }

  function generateListing(d, force=false){
    const v=d.vehicle||{},r=d.result||calculate(d),p=d.purchase||{};
    const old=d.listing||{};
    if(old.generated && !force) return old;
    const car=[v.brand,v.model,v.version].filter(Boolean).join(' ').trim()||'Viatura';
    const price=num(old.price)||num(p.actualSalePrice)||Math.round(num(r.expectedSale)/100)*100;
    const km=num(v.km); const year=v.year||'';
    const essentials=[year?`Ano ${year}`:'',km?`${km.toLocaleString('pt-PT')} km`:'',v.fuel||'',v.gearbox||'',v.engine||''].filter(Boolean);
    const shortDescription=`${car}${essentials.length?' · '+essentials.join(' · '):''}`;
    const lines=[];
    lines.push(`MOBIWAY apresenta este ${car}, selecionado através do processo interno MOBIWAY Avalia.`);
    lines.push('');
    lines.push('DADOS PRINCIPAIS');
    if(year) lines.push(`• Ano: ${year}${v.month?` / ${v.month}`:''}`);
    if(km) lines.push(`• Quilometragem: ${km.toLocaleString('pt-PT')} km`);
    if(v.fuel) lines.push(`• Combustível: ${v.fuel}`);
    if(v.engine||v.engineCc) lines.push(`• Motorização: ${v.engine||`${v.engineCc} cc`}${v.power?` · ${v.power} cv`:''}`);
    if(v.color) lines.push(`• Cor: ${v.color}`);
    if(v.gearbox) lines.push(`• Caixa: ${v.gearbox}`);
    if(v.origin) lines.push(`• Origem: ${v.origin}`);
    const note=cleanPublicNote(v.notes);
    if(note){lines.push('');lines.push('DESTAQUES');lines.push(note);}
    lines.push('');
    lines.push(`Estado do anúncio: ${old.preparationStatus||'Em preparação MOBIWAY'}.`);
    lines.push('Informação sujeita a confirmação. Visita e test-drive mediante marcação.');
    const photos=(d.photos||[]).map((ph,i)=>({
      index:i,
      name:ph?.name||`Foto ${i+1}`,
      data:typeof ph==='string'?ph:(ph?.data||''),
      source:ph?.source||'',
      included:ph?.source==='plate-scan'?false:true,
      cover:false
    })).filter(x=>x.data);
    const first=photos.find(x=>x.included); if(first) first.cover=true;
    return {
      generated:true,generatedAt:new Date().toISOString(),status:old.status||'draft',publishedAt:old.publishedAt||'',productId:old.productId||'',productUrl:old.productUrl||'',
      sku:old.sku||listingSku(d),title:old.title||car,shortDescription:old.shortDescription||shortDescription,
      description:old.description||lines.join('\n'),price:price||'',category:old.category||settings.storeCategory||'Viaturas',stock:1,visible:true,
      preparationStatus:old.preparationStatus||'Em preparação MOBIWAY',photos:old.photos?.length?old.photos:photos
    };
  }

  function listingPayload(d){
    const l=generateListing(d); const v=d.vehicle||{};
    return {
      source:'MOBIWAY Avalia',version:1,evaluationId:d.id,createdAt:new Date().toISOString(),
      productNumber:l.sku,name:l.title,price:num(l.price),currency:'EUR',shortDescription:l.shortDescription,description:l.description,
      manufacturer:v.brand||'',category:l.category||'Viaturas',stocklevel:1,visible:true,
      searchKeywords:[v.brand,v.model,v.version,v.engine,v.fuel,v.gearbox,'MOBIWAY','usado','automóvel'].filter(Boolean),
      vehicle:{plate:v.plate||'',vin:v.vin||'',year:v.year||'',month:v.month||'',km:num(v.km),fuel:v.fuel||'',engine:v.engine||'',engineCc:num(v.engineCc),power:num(v.power),co2:num(v.co2),color:v.color||'',seats:num(v.seats),gearbox:v.gearbox||'',origin:v.origin||''},
      photos:(l.photos||[]).filter(x=>x.included&&x.data).sort((a,b)=>(b.cover?1:0)-(a.cover?1:0)).map((x,i)=>({name:x.name||`foto-${i+1}.jpg`,data:x.data,cover:!!x.cover})),
      preparationStatus:l.preparationStatus||''
    };
  }

  function bindListingInputs(){
    const d=evaluations.find(x=>x.id===state.editingId); if(!d)return;
    d.listing=generateListing(d);
    document.querySelectorAll('[data-listing]').forEach(el=>el.addEventListener('input',()=>{d.listing[el.dataset.listing]=el.value;d.listing.updatedAt=new Date().toISOString();}));
  }

  function renderListing(){
    const d=evaluations.find(x=>x.id===state.editingId); if(!d){state.view='history';return render();}
    d.result=calculate(d); d.listing=generateListing(d); const l=d.listing,v=d.vehicle||{};
    const publicPhotos=(l.photos||[]).filter(x=>x.included).length;
    app.innerHTML=shell(`<div class="sectionHead"><div><span class="badge orange">MOBIWAY.STORE</span><h2 style="margin-top:10px">Pré-publicação da viatura</h2><p>Edita o preço, texto e fotografias antes de publicar.</p></div><button class="ghostBtn" onclick="Mobiway.openDetail('${d.id}')">← Avaliação</button></div>
    <div class="listingStatus"><div><small>ESTADO</small><strong>${l.status==='published'?'PUBLICADO':l.status==='ready'?'PRONTO A PUBLICAR':'RASCUNHO'}</strong></div><div><small>SKU</small><strong>${esc(l.sku)}</strong></div><div><small>FOTOS</small><strong>${publicPhotos}</strong></div></div>
    <div class="panel listingEditor"><div class="formGrid">
      <div class="field full"><label>Título do anúncio</label><input data-listing="title" value="${esc(l.title)}"></div>
      <div class="field"><label>Preço de venda</label><div class="suffix"><input data-listing="price" type="number" inputmode="decimal" value="${esc(l.price)}"><span>€</span></div></div>
      <div class="field"><label>Categoria</label><input data-listing="category" value="${esc(l.category)}"></div>
      <div class="field full"><label>Descrição curta</label><textarea data-listing="shortDescription" rows="3">${esc(l.shortDescription)}</textarea></div>
      <div class="field full"><label>Descrição completa</label><textarea data-listing="description" rows="14">${esc(l.description)}</textarea></div>
      <div class="field"><label>Estado de preparação</label><select data-listing="preparationStatus"><option ${l.preparationStatus==='Disponível'?'selected':''}>Disponível</option><option ${l.preparationStatus==='Em preparação MOBIWAY'?'selected':''}>Em preparação MOBIWAY</option><option ${l.preparationStatus==='Reservado'?'selected':''}>Reservado</option></select></div>
      <div class="field"><label>Referência</label><input value="${esc(l.sku)}" disabled></div>
    </div>
    <div class="heroActions" style="margin-top:14px"><button class="ghostBtn" onclick="Mobiway.regenerateListing('${d.id}')">↻ Refazer texto MOBIWAY</button><button class="ghostBtn" onclick="Mobiway.saveListing('${d.id}')">Guardar rascunho</button><button class="ghostBtn" onclick="Mobiway.markListingPublished('${d.id}')">✓ Marcar publicado</button><button class="primaryBtn" onclick="Mobiway.publishListing('${d.id}')">PUBLICAR AGORA →</button></div></div>
    <div class="sectionHead"><div><h2>Fotografias do anúncio</h2><p>A fotografia usada pelo Smart Scan fica excluída por defeito. Podes incluí-la manualmente.</p></div></div>
    ${l.photos?.length?`<div class="listingPhotoGrid">${l.photos.map((ph,i)=>`<div class="listingPhoto ${ph.included?'selected':''} ${ph.cover?'cover':''}"><img src="${ph.data}"><div class="listingPhotoBar"><button onclick="Mobiway.toggleListingPhoto('${d.id}',${i})">${ph.included?'✓ Incluída':'＋ Incluir'}</button><button ${!ph.included?'disabled':''} onclick="Mobiway.setListingCover('${d.id}',${i})">${ph.cover?'★ Capa':'☆ Capa'}</button></div><small>${esc(ph.name||`Foto ${i+1}`)}</small></div>`).join('')}</div>`:`<div class="empty">Esta avaliação ainda não tem fotografias.</div>`}
    <div class="panel" style="margin-top:18px"><h3>Publicação ShopBuilder</h3><p class="hint">Se estiver configurado um Publisher/API, PUBLICAR AGORA envia diretamente o produto. Sem API, a app cria um pacote com CSV, descrições e fotografias e abre o editor Amen para importação/publicação.</p>${l.productUrl?`<p><a href="${esc(l.productUrl)}" target="_blank">Abrir anúncio publicado ↗</a></p>`:''}</div>`,'history');
    bindListingInputs();
  }

  function renderHistory(){
    app.innerHTML=shell(`<div class="sectionHead"><div><h2>Histórico</h2><p>${evaluations.length} avaliações guardadas localmente.</p></div><button class="primaryBtn" onclick="Mobiway.newEvaluation()">＋ Nova</button></div>
    ${evaluations.length?`<div class="list">${[...evaluations].sort((a,b)=>new Date(b.updatedAt)-new Date(a.updatedAt)).map(e=>{const r=calculate(e);const name=[e.vehicle.brand,e.vehicle.model,e.vehicle.version].filter(Boolean).join(' ')||'Viatura';return `<div class="rowCard"><div class="main" onclick="Mobiway.openDetail('${e.id}')"><strong>${esc(name)}</strong><small>${esc(e.vehicle.plate||'sem matrícula')} · ${e.vehicle.year} · ${Number(e.vehicle.km||0).toLocaleString('pt-PT')} km · ${statusText(e)}</small></div><div style="text-align:right"><div class="money">${fmt.format(r.recommendedBuy)}</div><small>aconselhado</small><button class="dangerBtn" style="margin-top:7px;padding:6px 9px" onclick="Mobiway.deleteEvaluation('${e.id}')">Eliminar</button></div></div>`}).join('')}</div>`:`<div class="empty">Sem avaliações.</div>`}
    <div class="panel" style="margin-top:18px"><h3>Backup</h3><p class="hint">Cria uma cópia completa das avaliações e definições num ficheiro JSON. Guarda-a no telemóvel, Drive ou outro destino Android e importa-a quando precisares.</p><div class="heroActions"><button class="ghostBtn" onclick="Mobiway.exportData()">Exportar dados</button><button class="ghostBtn" onclick="Mobiway.importData()">Importar backup</button><input type="file" id="backupInput" accept="application/json" hidden></div></div>`,'history');
  }

  function renderAnalytics(){
    const bought=evaluations.filter(e=>e.purchase?.decision==='bought'); const sold=bought.filter(e=>num(e.purchase.actualSalePrice)>0);
    const spent=bought.reduce((s,e)=>s+num(e.purchase.actualPurchasePrice)+num(e.purchase.actualRepairCost)+num(e.purchase.warrantyActual),0);
    const revenue=sold.reduce((s,e)=>s+num(e.purchase.actualSalePrice),0); const profit=sold.reduce((s,e)=>s+num(e.purchase.actualSalePrice)-num(e.purchase.actualPurchasePrice)-num(e.purchase.actualRepairCost)-num(e.purchase.warrantyActual),0);
    const forecast=sold.reduce((s,e)=>s+(e.result?.targetProfit||calculate(e).targetProfit),0); const variance=profit-forecast;
    app.innerHTML=shell(`<div class="sectionHead"><div><h2>Resultados Mobiway</h2><p>O ciclo de aprendizagem começa quando registas compra, reparação e venda reais.</p></div></div>
    <div class="grid"><div class="card"><span class="badge green">COMPRADAS</span><div class="metric">${bought.length}</div><p>viaturas marcadas como compradas</p></div><div class="card"><span class="badge">CAPITAL</span><div class="metric">${fmt.format(spent)}</div><p>compra + reparação + garantia registada</p></div><div class="card"><span class="badge orange">LUCRO REAL</span><div class="metric">${fmt.format(profit)}</div><p>${sold.length} negócios com venda fechada</p></div></div>
    <div class="panel" style="margin-top:14px"><h3>Previsão vs. realidade</h3><div class="breakdown"><div class="breakRow"><span>Receita de vendas registada</span><strong>${fmt.format(revenue)}</strong></div><div class="breakRow"><span>Margem prevista nesses negócios</span><strong>${fmt.format(forecast)}</strong></div><div class="breakRow"><span>Lucro real</span><strong>${fmt.format(profit)}</strong></div><div class="breakRow total"><span>Desvio do modelo</span><strong>${variance>=0?'+':''}${fmt.format(variance)}</strong></div></div></div>
    <div class="callout"><strong>APRENDIZAGEM MOBIWAY</strong><div class="big">Dados próprios > tabelas genéricas</div><p>Ao acumular negócios fechados, estes dados permitem calibrar reservas de risco, custos de preparação e margens por marca, motor, caixa e faixa de quilometragem.</p></div>`,'analytics');
  }

  function renderSettings(){
    const rows=[
      ['Margem alvo (%)','targetProfitPct','Percentagem aplicada sobre a venda provável.'],['Margem alvo mínima (€)','targetProfitMin','Nunca procurar menos margem do que este valor.'],['Margem mínima absoluta (€)','minimumProfit','Usada para definir o máximo que se pode pagar.'],['Buffer de negociação (%)','negotiationBufferPct','Desconto sobre a compra aconselhada para a oferta inicial.'],['Reserva base de garantia (€)','warrantyReserve','Valor comercial reservado por negócio.'],['Custo mensal de stock (€)','stockMonthly','Capital, espaço, seguro e custo de imobilização.'],['Dias padrão em stock','expectedStockDays','Previsão inicial até à venda.'],['Administrativo/comercial (€)','adminCost','Documentação, anúncio e operação.'],['Revisão padrão (€)','defaultService','Preparação mecânica inicial.'],['Detailing padrão (€)','defaultDetailing','Lavagem, higienização e preparação.'],['Risco histórico desconhecido (€)','unknownHistoryRisk','Reserva automática quando não existe histórico.'],['Risco caixa automática (€)','automaticGearboxRisk','Reserva adicional base para automáticas.'],['Risco km elevado (€)','highKmRisk','Reserva para ≥200.000 km.'],['Risco diesel elevado (€)','dieselRisk','Reserva diesel/antipoluição em km elevados.']
    ];
    app.innerHTML=shell(`<div class="sectionHead"><div><h2>Política de compra</h2><p>Estes valores alimentam todas as novas avaliações.</p></div></div><div class="panel">${rows.map(([l,k,h])=>`<div class="settingRow"><div><strong>${l}</strong><small>${h}</small></div><input type="number" data-setting="${k}" value="${settings[k]}"></div>`).join('')}</div><div class="panel smartSettings"><h3>MOBIWAY Smart Scan · DUA + TransparentCars</h3><p class="hint">Sem conta nem credenciais: OCR local para matrícula/DUA, VIN complementar via vPIC e valorização do mercado português pela API pública TransparentCars.</p><div class="settingRow"><div><strong>Valorização principal</strong><small>TransparentCars · API pública, sem chave e sem registo. Atribuição incluída na própria avaliação.</small></div><strong>TransparentCars</strong></div><div class="settingRow"><div><strong>Dados técnicos</strong><small>DUA lido localmente; os campos pessoais do titular não são guardados.</small></div><strong>Smart DUA</strong></div></div><div class="panel smartSettings"><h3>MOBIWAY.store · ShopBuilder</h3><p class="hint">Configura o editor Amen. O Publisher/API é opcional: se ficar vazio, a app exporta o pacote do anúncio e abre o editor.</p><div class="settingRow"><div><strong>URL do editor ShopBuilder</strong><small>Endereço que deve abrir quando for necessário publicar/importar.</small></div><input type="url" data-setting="storeEditorUrl" data-setting-type="text" value="${esc(settings.storeEditorUrl||'')}"></div><div class="settingRow"><div><strong>Categoria padrão</strong><small>Categoria usada nos novos anúncios.</small></div><input type="text" data-setting="storeCategory" data-setting-type="text" value="${esc(settings.storeCategory||'Viaturas')}"></div><div class="settingRow"><div><strong>Publisher/API (opcional)</strong><small>Endpoint MOBIWAY que recebe o JSON e publica no ShopBuilder. Deixa vazio enquanto não estiver configurado.</small></div><input type="url" data-setting="storePublisherUrl" data-setting-type="text" value="${esc(settings.storePublisherUrl||'')}"></div></div><div class="heroActions"><button class="primaryBtn" onclick="Mobiway.saveSettings()">Guardar definições</button><button class="ghostBtn" onclick="Mobiway.resetSettings()">Repor valores iniciais</button></div>`,'settings');
  }

  function repairResultPayload(d){
    const r=calculate(d),v=d.vehicle||{},i=d.integration||{},c=d.condition||{},p=d.purchase||{};
    const linkedToRepair=!!(i.repairOrderId||i.repairOrderNo);
    return {
      source:'MOBIWAY AVALIA',sourcePackage:'pt.mobiway.avalia',
      transferMode:linkedToRepair?'update_repair_order':'create_repair_order',
      repairOrderId:i.repairOrderId||'',orderNo:i.repairOrderNo||'',
      evaluationId:d.id||'',evaluatedAt:d.updatedAt||new Date().toISOString(),
      plate:v.plate||'',vin:v.vin||'',make:v.brand||'',model:v.model||'',year:v.year||'',engine:v.engine||'',engineCc:v.engineCc||'',power:v.power||'',co2:v.co2||'',color:v.color||'',seats:v.seats||'',fuel:v.fuel||'',transmission:v.gearbox||'',mileage:v.km||'',
      vehicleNotes:v.notes||'',knownFaults:c.knownFaults||'',
      bodyCondition:c.body||'',interiorCondition:c.interior||'',tyresCondition:c.tyres||'',engineCondition:c.engine||'',gearboxCondition:c.gearbox||'',brakesCondition:c.brakes||'',
      mechanicalCost:num(c.mechanicalCost),bodyCost:num(c.bodyCost),tyresCost:num(c.tyresCost),otherRepairCost:num(c.otherRepairCost),
      expectedSale:r.expectedSale,recommendedBuy:r.recommendedBuy,maximumBuy:r.maximumBuy,openingOffer:r.openingOffer,
      targetProfit:r.targetProfit,observedRepairs:r.observedRepairs,repairEstimateGross:r.observedRepairs,prepAndStock:r.prepAndStock,riskAmount:r.riskAmount,
      riskScore:r.riskScore,riskLabel:r.riskLabel,confidence:r.confidence,confidenceLabel:r.confidenceLabel,
      marketSource:r.marketSource,purchaseDecision:p.decision||'',purchasePrice:num(p.actualPurchasePrice),purchaseNotes:p.notes||'',
      photos:(d.photos||[]).map(p=>typeof p==='string'?p:(p?.data||'')).filter(Boolean),
      photoCount:(d.photos||[]).length
    };
  }

  function launchRepairWithResult(d){
    try{
      if(!window.AndroidBridge || typeof AndroidBridge.returnToRepair!=='function'){toast('Integração com REPAIR disponível na app Android.');return false;}
      const ok=AndroidBridge.returnToRepair(JSON.stringify(repairResultPayload(d)));
      if(!ok) toast('MOBIWAY REPAIR não está instalada neste equipamento.');
      return !!ok;
    }catch(e){toast('Não foi possível enviar a avaliação à MOBIWAY REPAIR.');return false;}
  }

  function persistEvaluation(d){ d.updatedAt=new Date().toISOString(); d.result=calculate(d); const i=evaluations.findIndex(x=>x.id===d.id); if(i>=0)evaluations[i]=d; else evaluations.push(d); save('mobiway_evaluations',evaluations); try{window.MobiwayCloudClient?.upsert('evaluations',d)}catch{} }


  function smartScanState(d){if(!d.smartScan)d.smartScan={status:'idle',message:'Pronto para leitura.',confidence:0,plate:'',provider:'OCR local',lastAt:''};return d.smartScan}
  function duaScanState(d){if(!d.duaScan)d.duaScan={status:'idle',message:'Fotografa o DUA para preencher automaticamente os dados técnicos.',lastAt:'',confidence:0};return d.duaScan}
  function normalizeFuel(v){const x=String(v||'').toLowerCase();if(x.includes('gasol')||x.includes('petrol'))return 'Gasolina';if(x.includes('gasó')||x.includes('gasole')||x.includes('diesel'))return 'Diesel';if(x.includes('plug'))return 'Híbrido Plug-in';if(x.includes('híbr')||x.includes('hybrid'))return 'Híbrido';if(x.includes('elétr')||x.includes('electric'))return 'Elétrico';if(x.includes('gpl')||x.includes('lpg'))return 'GPL';return v||'Diesel'}

  const Mobiway={
    go(view){state.view=view;state.step=1;state.draft=null;render();window.scrollTo(0,0)},
    backHome(){this.go('home')},
    openRepair(){
      try{
        if(!window.AndroidBridge || typeof AndroidBridge.openRepair!=='function'){toast('Atalho REPAIR disponível na aplicação Android.');return;}
        if(!AndroidBridge.openRepair()) toast('MOBIWAY REPAIR não está instalada neste equipamento.');
      }catch(e){toast('Não foi possível abrir a MOBIWAY REPAIR.');}
    },
    newEvaluation(){state.draft=newDraft();state.view='wizard';state.step=1;state.editingId=null;render();window.scrollTo(0,0)},
    loadDemo(){const d=newDraft();Object.assign(d.vehicle,{plate:'00-AA-00',brand:'MOBIWAY DEMO',model:'Crossover 1.5',version:'Executive',year:2021,fuel:'Diesel',gearbox:'Automática',km:98000,origin:'Nacional',askingPrice:14500});d.comps=[{source:'Exemplo A',year:2021,km:92000,price:14900},{source:'Exemplo B',year:2020,km:110000,price:13500},{source:'Exemplo C',year:2021,km:101000,price:14250},{source:'Exemplo D',year:2022,km:85000,price:15800}];Object.assign(d.condition,{body:'mid',interior:'good',tyres:'mid',engine:'good',gearbox:'good',brakes:'mid',history:'partial',warningLights:'none',accidents:'no',mechanicalCost:350,bodyCost:250,tyresCost:320});state.draft=d;state.view='wizard';state.step=6;render();window.scrollTo(0,0);toast('Demonstração carregada — valores ilustrativos.');},
    cancelWizard(){state.draft=null;this.go('home')},
    prevStep(){if(state.step===1)return this.cancelWizard();state.step--;render();window.scrollTo(0,0)},
    nextStep(){
      if(state.step===1){const v=state.draft.vehicle;if(!v.brand||!v.model||!v.year||!v.km){toast('Preenche marca, modelo, ano e quilómetros.');return;}}
      if(state.step<6){state.step++;render();window.scrollTo(0,0);if(state.step===4 && !state.draft.marketAI && !state.draft.marketAILoading)setTimeout(()=>this.autoMarket(false),120);return;}
      const saved=state.draft; persistEvaluation(saved); state.editingId=saved.id;
      if(saved.integration?.repairOrderNo && launchRepairWithResult(saved)){ state.draft=null; return; }
      state.view='detail'; state.draft=null; render(); window.scrollTo(0,0); toast('Avaliação guardada.');
    },
    setRating(path,v){setPath(state.draft,path,v);renderWizard()},
    addComp(){state.draft.comps.push({source:'',year:state.draft.vehicle.year,km:state.draft.vehicle.km,price:''});renderWizard()},
    removeComp(i){state.draft.comps.splice(i,1);renderWizard()},
    async autoMarket(force=false){
  const d=state.draft;
  if(!d)return;
  if(d.marketAILoading)return;
  if(d.marketAI&&!force)return;

  const v=d.vehicle;
  if(!v.brand||!v.model||!v.year||!v.km){d.marketAIError='Faltam marca, modelo, ano ou quilómetros para consultar a TransparentCars.';renderWizard();return;}
  d.marketAILoading=true;
  d.marketAIError='';
  renderWizard();

  if(window.AndroidBridge&&typeof AndroidBridge.lookupTransparentCars==='function'){
    try{AndroidBridge.lookupTransparentCars(String(v.brand||''),String(v.model||''),String(v.year||''),String(v.km||''),String(v.fuel||''),String(v.gearbox||''),String(v.power||''),String(v.engineCc||''),String(v.co2||''),String(v.month||''));return;}
    catch(e){d.marketAILoading=false;d.marketAIError='Falha ao iniciar a consulta TransparentCars.';renderWizard();return;}
  }

  try{
    const form=new URLSearchParams();
    const payload={
      make:v.brand,
      model:v.model,
      version:v.version,
      engine:v.engine,
      fuel:v.fuel,
      transmission:v.gearbox,
      year:v.year,
      mileage:v.km,
      power:v.power,
      notes:v.notes
    };

    Object.entries(payload).forEach(([k,val])=>
      form.append(k,val==null?'':String(val))
    );

    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),45000);

    let r;
    try{
      r=await fetch(
        'https://mobiway-avalia-api.vercel.app/api/market',
        {
          method:'POST',
          body:form,
          signal:controller.signal
        }
      );
    }finally{
      clearTimeout(timer);
    }

    const data=await r.json().catch(()=>({}));

    if(!r.ok)
      throw new Error(data.error||`Erro de pesquisa (${r.status})`);

    if(!data.marketValue)
      throw new Error('A pesquisa não devolveu um valor de mercado utilizável.');

    d.marketAI=data;
    d.marketAIError='';
    toast('Mercado atualizado automaticamente.');

  }catch(e){
    const msg=
      e&&e.name==='AbortError'
        ? 'A pesquisa demorou demasiado. Tenta novamente.'
        : (e&&e.message
            ? e.message
            : 'Falha na pesquisa automática de mercado.');

    d.marketAIError=msg;
  }finally{
    d.marketAILoading=false;
    d.updatedAt=new Date().toISOString();
    renderWizard();
  }
},
    smartScanPlate(){
      const d=ensureDraft(),ss=smartScanState(d),x=document.getElementById('plateScanInput');
      if(!window.AndroidBridge||typeof AndroidBridge.recognizePlate!=='function'){ss.status='error';ss.message='Smart Scan requer a app Android.';renderWizard();return;}
      ss.status='working';ss.message='Abre a câmara e enquadra a matrícula.';ss.confidence=0;renderWizard();
      x.value='';x.click();
    },
    smartScanDua(){
      const d=ensureDraft(),ds=duaScanState(d),x=document.getElementById('duaScanInput');
      if(!window.AndroidBridge||typeof AndroidBridge.recognizeDua!=='function'){ds.status='error';ds.message='Smart DUA requer a app Android.';renderWizard();return;}
      ds.status='working';ds.message='Abre a câmara e fotografa o DUA completo, com boa luz.';ds.confidence=0;renderWizard();x.value='';x.click();
    },
    receiveDuaScan(raw){
      const d=ensureDraft(),ds=duaScanState(d);let r={};try{r=typeof raw==='string'?JSON.parse(raw):raw||{}}catch{}
      if(!r.ok){ds.status='error';ds.message=r.error||'Não foi possível ler o DUA. Tenta outra fotografia.';renderWizard();return;}
      const v=d.vehicle;
      if(r.plate)v.plate=String(r.plate).toUpperCase();if(r.vin)v.vin=String(r.vin).toUpperCase();if(r.brand)v.brand=r.brand;if(r.model)v.model=r.model;if(r.version)v.version=r.version;
      if(r.year)v.year=Number(r.year)||v.year;if(r.month)v.month=String(r.month);if(r.fuel)v.fuel=normalizeFuel(r.fuel);if(r.engineCc){v.engineCc=Number(r.engineCc)||r.engineCc;if(!v.engine)v.engine=`${v.engineCc} cc`;}
      if(r.powerHp)v.power=Math.round(Number(r.powerHp)||0)||v.power;if(r.co2)v.co2=Number(r.co2)||r.co2;if(r.color)v.color=r.color;if(r.seats)v.seats=Number(r.seats)||r.seats;
      ds.status='ok';ds.confidence=Number(r.confidence||88);ds.lastAt=new Date().toISOString();ds.message=`DUA lido: ${[v.brand,v.model,v.year].filter(Boolean).join(' ')}${v.vin?' · VIN identificado':''}.`;d.updatedAt=ds.lastAt;
      renderWizard();toast('DUA lido e dados preenchidos automaticamente.');
      if(v.vin&&window.AndroidBridge&&typeof AndroidBridge.lookupVin==='function'){try{AndroidBridge.lookupVin(String(v.vin),String(v.year||''));}catch{}}
    },
    receiveVinLookup(raw){
      const d=ensureDraft(),v=d.vehicle;let r={};try{r=typeof raw==='string'?JSON.parse(raw):raw||{}}catch{}if(!r.ok)return;
      if(!v.brand&&r.make)v.brand=r.make;if(!v.model&&r.model)v.model=r.model;if((!v.year||Number(v.year)<1950)&&r.year)v.year=Number(r.year);if(!v.engineCc&&r.engineCc){v.engineCc=Number(r.engineCc);v.engine=`${v.engineCc} cc`;}
      if(!v.power&&r.powerHp)v.power=Math.round(Number(r.powerHp));if(r.fuel)v.fuel=normalizeFuel(r.fuel);if((!v.gearbox||v.gearbox==='Manual')&&r.transmission&&String(r.transmission).toLowerCase().includes('auto'))v.gearbox='Automática';
      if(r.bodyClass&&!String(v.notes||'').includes('vPIC'))v.notes=[v.notes,`vPIC: ${r.bodyClass}${r.plantCountry?' · fabrico '+r.plantCountry:''}`].filter(Boolean).join('\n');renderWizard();
    },
    receiveTransparentValuation(raw){
      const d=state.draft;if(!d)return;let r={};try{r=typeof raw==='string'?JSON.parse(raw):raw||{}}catch{}d.marketAILoading=false;
      if(!r.ok||!r.found){d.marketAIError=r.error||`TransparentCars: comparáveis insuficientes (${Number(r.comps||0)} encontrados).`;d.marketAI=null;renderWizard();return;}
      const comps=Number(r.comps||0), rough=!!r.rough;let confidence=Math.min(94,55+Math.min(30,comps*4)+(rough?0:8));
      d.marketAI={provider:'TransparentCars',marketValue:Number(r.median||0),low:Number(r.low||0),high:Number(r.high||0),confidence,comparablesCount:comps,comparables:[],daysSell:r.daysSell==null?null:Number(r.daysSell),rough,matchLevel:Number(r.matchLevel||0),iucAnnual:Number(r.iucAnnual||0),canonicalMake:r.make||d.vehicle.brand,canonicalModel:r.model||d.vehicle.model,summary:`${comps} comparáveis no mercado português${r.daysSell?` · cerca de ${r.daysSell} dias típicos de venda`:''}${rough?' · amostra alargada/indicativa':''}.`,researchedAt:new Date().toISOString()};
      d.marketAIError='';d.updatedAt=new Date().toISOString();renderWizard();toast('Valorização TransparentCars atualizada.');
    },
    lookupPlate(auto=false){
      const d=ensureDraft(),ss=smartScanState(d),plate=String(d.vehicle?.plate||'').trim();
      if(!plate){ss.status='error';ss.message='Indica ou fotografa primeiro a matrícula.';renderWizard();return;}
      if(!window.AndroidBridge||typeof AndroidBridge.openCheckViatura!=='function'){ss.status='error';ss.message='Consulta CheckViatura disponível na app Android.';renderWizard();return;}
      ss.status='ok';ss.message=`Matrícula ${plate} copiada. CheckViatura aberto — cola no campo e confirma a pesquisa.`;ss.provider='CheckViatura.pt';ss.lastAt=new Date().toISOString();d.updatedAt=ss.lastAt;renderWizard();
      try{const ok=AndroidBridge.openCheckViatura(plate);if(!ok){ss.status='error';ss.message='Não foi possível abrir o CheckViatura.';renderWizard();return;}toast(auto?'Matrícula reconhecida · CheckViatura aberto.':'CheckViatura aberto · matrícula copiada.');}catch(e){ss.status='error';ss.message='Não foi possível abrir o CheckViatura.';renderWizard();}
    },
    receivePlateScan(raw){
      const d=ensureDraft(),ss=smartScanState(d);let r={};try{r=typeof raw==='string'?JSON.parse(raw):raw||{}}catch{}
      if(!r.ok||!r.plate){ss.status='error';ss.message=r.error||'Não foi possível ler a matrícula. Tenta outra fotografia.';ss.confidence=0;renderWizard();return;}
      d.vehicle.plate=String(r.plate).toUpperCase();ss.status='ok';ss.message=`Matrícula reconhecida: ${d.vehicle.plate}`;ss.confidence=Number(r.confidence||0);ss.plate=d.vehicle.plate;ss.lastAt=new Date().toISOString();d.updatedAt=ss.lastAt;
      if(state.pendingSmartScanImage){d.photos=(d.photos||[]).filter(p=>p?.source!=='plate-scan');d.photos.unshift({name:`Matrícula ${d.vehicle.plate}`,data:state.pendingSmartScanImage,source:'plate-scan',addedAt:new Date().toISOString()});state.pendingSmartScanImage=null;}
      ss.message=`Matrícula reconhecida: ${d.vehicle.plate}. Agora fotografa o DUA para preencher os dados técnicos.`;renderWizard();toast(`Matrícula ${d.vehicle.plate} reconhecida.`);
    },
    marketSearch(){const v=state.draft.vehicle;const q=encodeURIComponent(`${v.brand} ${v.model} ${v.version||''} ${v.engine||''} ${v.year} ${v.km||''} usados Portugal`);window.open(`https://www.google.com/search?q=${q}`,'_blank')},
    takePhoto(){const x=document.getElementById('photoInput');x.value='';x.click()},
    pickPhotos(){const x=document.getElementById('galleryInput');x.value='';x.click()},
    removePhoto(i){state.draft.photos.splice(i,1);renderWizard()},
    openDetail(id){state.editingId=id;state.view='detail';render();window.scrollTo(0,0)},
    editEvaluation(id){const e=evaluations.find(x=>x.id===id); if(!e)return; state.draft=structuredClone(e);state.editingId=id;state.view='wizard';state.step=1;render();window.scrollTo(0,0)},
    deleteEvaluation(id){if(!confirm('Eliminar esta avaliação?'))return;evaluations=evaluations.filter(x=>x.id!==id);save('mobiway_evaluations',evaluations);try{window.MobiwayCloudClient?.remove('evaluations',id)}catch{}renderHistory();toast('Avaliação eliminada.')},
    markDecision(id,decision){const e=evaluations.find(x=>x.id===id);if(!e)return;e.purchase=e.purchase||{};e.purchase.decision=decision;if(decision==='bought'){e.listing=generateListing(e);persistEvaluation(e);state.editingId=id;state.view='listing';render();window.scrollTo(0,0);toast('Comprado · anúncio MOBIWAY preparado.');return;}persistEvaluation(e);renderDetail();toast('Marcado como não comprado.')},
    openListing(id){const d=evaluations.find(x=>x.id===id);if(!d)return;if(d.purchase?.decision!=='bought'){toast('Marca primeiro a viatura como COMPRÁMOS.');return;}d.listing=generateListing(d);persistEvaluation(d);state.editingId=id;state.view='listing';render();window.scrollTo(0,0)},
    regenerateListing(id){const d=evaluations.find(x=>x.id===id);if(!d)return;d.listing=null;d.listing=generateListing(d,true);persistEvaluation(d);renderListing();toast('Texto do anúncio recriado com o padrão MOBIWAY.')},
    saveListing(id){const d=evaluations.find(x=>x.id===id);if(!d)return;document.querySelectorAll('[data-listing]').forEach(el=>d.listing[el.dataset.listing]=el.value);d.listing.status='draft';persistEvaluation(d);renderListing();toast('Rascunho do anúncio guardado.')},
    toggleListingPhoto(id,i){const d=evaluations.find(x=>x.id===id);if(!d?.listing?.photos?.[i])return;const ph=d.listing.photos[i];ph.included=!ph.included;if(!ph.included&&ph.cover)ph.cover=false;if(ph.included&&!d.listing.photos.some(x=>x.cover))ph.cover=true;persistEvaluation(d);renderListing()},
    setListingCover(id,i){const d=evaluations.find(x=>x.id===id);if(!d?.listing?.photos?.[i]||!d.listing.photos[i].included)return;d.listing.photos.forEach((x,j)=>x.cover=j===i);persistEvaluation(d);renderListing()},
    publishListing(id){const d=evaluations.find(x=>x.id===id);if(!d)return;document.querySelectorAll('[data-listing]').forEach(el=>d.listing[el.dataset.listing]=el.value);const payload=listingPayload(d);if(!payload.name||num(payload.price)<=0){toast('Confirma o título e o preço de venda.');return;}if(!payload.photos.length&&!confirm('O anúncio não tem fotografias incluídas. Continuar?'))return;d.listing.status='ready';persistEvaluation(d);const publisher=String(settings.storePublisherUrl||'').trim();if(publisher&&window.AndroidBridge&&typeof AndroidBridge.publishStoreListing==='function'){toast('A publicar no MOBIWAY.store…');AndroidBridge.publishStoreListing(JSON.stringify(payload),publisher);return;}const file=`${payload.productNumber||'mobiway'}-shopbuilder.zip`;if(window.AndroidBridge&&typeof AndroidBridge.exportStorePackage==='function'){AndroidBridge.exportStorePackage(file,JSON.stringify(payload),String(settings.storeEditorUrl||'https://www.amen.pt/'));toast('Guarda o pacote ShopBuilder; o editor Amen abre de seguida.');return;}toast('Publicação ShopBuilder disponível na app Android.')},
    markListingPublished(id){const d=evaluations.find(x=>x.id===id);if(!d?.listing)return;d.listing.status='published';d.listing.publishedAt=new Date().toISOString();persistEvaluation(d);renderListing();toast('Anúncio marcado como publicado.')},
    receiveStorePublish(raw){let r={};try{r=typeof raw==='string'?JSON.parse(raw):raw||{}}catch{}const d=evaluations.find(x=>x.id===state.editingId);if(!d)return;if(r.ok){d.listing.status='published';d.listing.publishedAt=new Date().toISOString();d.listing.productId=r.productId||'';d.listing.productUrl=r.productUrl||'';persistEvaluation(d);renderListing();toast('Anúncio publicado no MOBIWAY.store.')}else{d.listing.status='ready';persistEvaluation(d);renderListing();toast(r.error||'Não foi possível publicar automaticamente.')}},
    saveDetail(){const d=evaluations.find(x=>x.id===state.editingId);if(!d)return;document.querySelectorAll('[data-path]').forEach(el=>setPath(d,el.dataset.path,el.value));persistEvaluation(d);renderDetail();toast('Resultado real guardado.')},
    sendToRepair(id){const d=evaluations.find(x=>x.id===id);if(!d)return;if(!d.integration?.repairOrderNo && d.purchase?.decision!=='bought'){toast('Marca primeiro a viatura como COMPRÁMOS para criar uma nova ordem na REPAIR.');return;}if(state.editingId===id)document.querySelectorAll('[data-path]').forEach(el=>setPath(d,el.dataset.path,el.value));persistEvaluation(d);if(!launchRepairWithResult(d))toast('Resultado guardado na AVALIA; não foi possível abrir a REPAIR.');},
    saveSettings(){document.querySelectorAll('[data-setting]').forEach(el=>settings[el.dataset.setting]=el.dataset.settingType==='text'?String(el.value||'').trim():num(el.value));save('mobiway_settings',settings);toast('Definições guardadas.');renderSettings()},
    resetSettings(){if(!confirm('Repor os valores iniciais?'))return;settings=structuredClone(DEFAULTS);save('mobiway_settings',settings);renderSettings()},
    exportData(){
      const fileName=`mobiway-avalia-backup-${new Date().toISOString().slice(0,10)}.json`;
      const payload=JSON.stringify({app:'MOBIWAY Avalia',version:2,exportedAt:new Date().toISOString(),settings,evaluations},null,2);
      if(window.AndroidBridge&&typeof AndroidBridge.exportBackup==='function'){AndroidBridge.exportBackup(fileName,payload);toast('Escolhe onde guardar o backup.');return;}
      const blob=new Blob([payload],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=fileName;a.click();URL.revokeObjectURL(a.href);
    },
    importData(){
      if(window.AndroidBridge&&typeof AndroidBridge.importBackup==='function'){AndroidBridge.importBackup();return;}
      const i=$('#backupInput');i.onchange=async()=>{try{this.receiveNativeBackup(await i.files[0].text())}catch{toast('Ficheiro de backup inválido.')}};i.click();
    },
    receiveNativeBackup(raw){
      try{
        const data=typeof raw==='string'?JSON.parse(raw):raw;
        if(!data||!Array.isArray(data.evaluations)) throw new Error('invalid');
        if(data.settings) settings={...DEFAULTS,...data.settings};
        evaluations=data.evaluations;
        save('mobiway_settings',settings);save('mobiway_evaluations',evaluations);
        state.view='history';state.draft=null;render();toast(`Backup importado · ${evaluations.length} avaliações.`);
      }catch(e){toast('Ficheiro de backup inválido ou incompatível.')}
    }
  };
  window.Mobiway=Mobiway;

  async function compressImage(file){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{const max=1280,scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.76))};img.onerror=reject;img.src=URL.createObjectURL(file)});}
  async function addFiles(files){for(const f of files){if(!f.type.startsWith('image/'))continue;try{const data=await compressImage(f);state.draft.photos.push({name:f.name,data,addedAt:new Date().toISOString()})}catch{}}renderWizard()}
  document.getElementById('photoInput').addEventListener('change',e=>addFiles(e.target.files));
  document.getElementById('galleryInput').addEventListener('change',e=>addFiles(e.target.files));

  async function compressSmartScanImage(file){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{const max=1600,scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.86))};img.onerror=reject;img.src=URL.createObjectURL(file)});}
  document.getElementById('plateScanInput')?.addEventListener('change',async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;const d=ensureDraft(),ss=smartScanState(d);try{ss.status='working';ss.message='A ler a matrícula no equipamento…';renderWizard();const data=await compressSmartScanImage(f);state.pendingSmartScanImage=data;AndroidBridge.recognizePlate(data);}catch(err){ss.status='error';ss.message='Não foi possível processar a fotografia.';state.pendingSmartScanImage=null;renderWizard();}});
  document.getElementById('duaScanInput')?.addEventListener('change',async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;const d=ensureDraft(),ds=duaScanState(d);try{ds.status='working';ds.message='A ler o DUA no equipamento…';renderWizard();const data=await compressSmartScanImage(f);AndroidBridge.recognizeDua(data);}catch(err){ds.status='error';ds.message='Não foi possível processar a fotografia do DUA.';renderWizard();}});

  function importRepairPayload(){
    try{
      if(!window.AndroidBridge || typeof AndroidBridge.getRepairPayload!=='function') return false;
      const raw=AndroidBridge.getRepairPayload();
      if(!raw) return false;
      const p=JSON.parse(raw);
      if(!p || (!p.plate && !p.vin && !p.make && !p.model)) return false;

      let existing=null;
      if(p.repairOrderId) existing=evaluations.find(e=>e.integration?.repairOrderId===p.repairOrderId)||null;
      if(!existing && p.orderNo) existing=evaluations.find(e=>e.integration?.repairOrderNo===p.orderNo)||null;
      if(!existing && p.evaluationId) existing=evaluations.find(e=>e.id===p.evaluationId)||null;
      if(!existing && p.vin) existing=evaluations.find(e=>String(e.vehicle?.vin||'').toUpperCase()===String(p.vin).toUpperCase())||null;
      if(!existing && p.plate) existing=evaluations.find(e=>String(e.vehicle?.plate||'').replace(/\s/g,'').toUpperCase()===String(p.plate).replace(/\s/g,'').toUpperCase())||null;
      const d=existing?structuredClone(existing):newDraft();
      Object.assign(d.vehicle,{
        plate:p.plate||d.vehicle.plate||'',
        vin:p.vin||d.vehicle.vin||'',
        brand:p.make||d.vehicle.brand||'',
        model:p.model||d.vehicle.model||'',
        year:p.year||d.vehicle.year,
        engine:p.engine||d.vehicle.engine||'',
        fuel:p.fuel||d.vehicle.fuel,
        gearbox:p.transmission||d.vehicle.gearbox,
        km:p.mileage||d.vehicle.km||'',
        notes:[
          p.orderNo ? `Ordem REPAIR: ${p.orderNo}` : '',
          p.customerRequest ? `Pedido do cliente: ${p.customerRequest}` : '',
          p.workshopNotes ? `Notas da oficina: ${p.workshopNotes}` : ''
        ].filter(Boolean).join('\n')
      });
      d.integration={
        source:'MOBIWAY REPAIR',
        repairOrderId:p.repairOrderId||d.integration?.repairOrderId||'',
        repairOrderNo:p.orderNo||d.integration?.repairOrderNo||'',
        sourcePackage:p.sourcePackage||'pt.mobiway.repair',
        importedAt:new Date().toISOString()
      };
      if(Array.isArray(p.photos) && p.photos.length){
        d.photos=Array.isArray(d.photos)?d.photos:[];
        const seen=new Set(d.photos.map(x=>typeof x==='string'?x:(x?.data||'')));
        let idx=1;
        for(const ph of p.photos){
          const data=typeof ph==='string'?ph:(ph?.data||'');
          if(data && !seen.has(data)){
            d.photos.push({name:`REPAIR-${String(idx++).padStart(2,'0')}.jpg`,data,addedAt:new Date().toISOString(),source:'MOBIWAY REPAIR'});
            seen.add(data);
          }
        }
      }
      if(num(p.repairEstimateGross)>0) d.condition.mechanicalCost=num(p.repairEstimateGross);
      state.draft=d;
      state.editingId=existing?d.id:null;
      state.view='wizard';
      state.step=existing?6:1;

      try{ if(typeof AndroidBridge.clearRepairPayload==='function') AndroidBridge.clearRepairPayload(); }catch{}
      setTimeout(()=>toast(existing?'Avaliação REPAIR existente aberta e atualizada.':'Dados importados da MOBIWAY REPAIR.'),180);
      return true;
    }catch(e){ return false; }
  }



  document.addEventListener('mobiway-cloud-status',e=>{
    if(!e.detail?.signedIn)return;
    try{ MobiwayCloudClient.migrate('evaluations',evaluations); MobiwayCloudClient.listen('evaluations'); }catch{}
  });
  document.addEventListener('mobiway-cloud-collection',e=>{
    if(e.detail?.collection!=='evaluations'||!Array.isArray(e.detail.records))return;
    let changed=false;
    for(const remote of e.detail.records){
      if(!remote?.id)continue;
      const i=evaluations.findIndex(x=>x.id===remote.id);
      if(i<0){evaluations.push(remote);changed=true;continue;}
      if(JSON.stringify(evaluations[i])!==JSON.stringify(remote)){evaluations[i]=remote;changed=true;}
    }
    if(changed){ save('mobiway_evaluations',evaluations); try{render()}catch{} }
  });

  if('serviceWorker' in navigator && location.protocol!=='file:') navigator.serviceWorker.register('./sw.js').catch(()=>{});
  importRepairPayload();
  render();
})();
